---
name: claim-validation-skill
description: "校验 Claim 的证据支持、时间一致性、事实依赖、推理完整性与语义范围。触发：这条结论站不站得住、检查时间口径与依赖是否自洽、找出语义过宽或越界。不适用：修改 Claim 文本、替冲突下结论。"
---

# Claim Validation Skill

## Skill ID
SK-12

## Purpose
验证 Claim 的证据支持、时间一致性、事实依赖、推理完整性和语义范围。

## 何时使用

- 调用条件：上游产物与 project_id / document_id / version_id 齐备
- 典型请求：这条结论站不站得住｜检查时间口径与依赖是否自洽｜找出语义过宽或越界
- 不要在此调用：修改 Claim 文本、替冲突下结论
## 边界与不适用

- 不做：只给问题与理由，不改写 Claim
- 不做：跨时点比较必须标注时间口径
- 缺输入：先有 Claim、证据与相关事实
