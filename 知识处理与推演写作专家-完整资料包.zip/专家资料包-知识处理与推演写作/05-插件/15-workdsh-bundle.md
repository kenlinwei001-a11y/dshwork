# 插件：workdsh-bundle

> 本文件由 `tools/expert-report/build.mjs` 从本机权威数据源自动构建，内容基准时间（UTC）：2026-10-22T05:53:59Z（= 源文件最新 mtime；构建器实际运行时间见 .state/manifest.json）。所有内容可凭 07-核对/ 下的清单与哈希复算；手工修改会在下次构建被覆盖。

| 字段 | 值 |
|---|---|
| 名称 | workdsh-bundle |
| 版本 | 0.1.0-alpha.53 |
| 类型 | WorkDSH 功能插件 |
| 是否在 bundles | 是 |
| 安装目录 | /Users/apple/workdsh/.test-runtime/preview/profiles/preview/node_modules/workdsh-bundle |

## 1. 职责

工作台导航与 WorkDSH 体验总装配。

## 2. 内置技能（0）

（该插件不携带内置技能）

## 3. 与本包范围专家的关系

- 其内置技能未被范围内专家引用。
- 决定左侧/右侧导航中专家、技能、项目、连接器入口是否出现。
