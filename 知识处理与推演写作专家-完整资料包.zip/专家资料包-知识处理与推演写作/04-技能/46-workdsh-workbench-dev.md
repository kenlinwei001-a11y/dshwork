# 技能：workdsh-workbench-dev

> 本文件由 `tools/expert-report/build.mjs` 从本机权威数据源自动构建，内容基准时间（UTC）：2026-11-02T13:31:19Z（= 源文件最新 mtime；构建器实际运行时间见 .state/manifest.json）。所有内容可凭 07-核对/ 下的清单与哈希复算；手工修改会在下次构建被覆盖。

## 1. 元数据

| 字段 | 值 |
|---|---|
| name | workdsh-workbench-dev |
| description | 在官方 Creator 插件开发流程上补充 WorkDSH 业务 SDK、对象协作、身份和数据保护规范。 |

## 2. 位置与来源

| 项 | 值 |
|---|---|
| 来源类型 | 插件内置（bundled） |
| 目录 | /Users/apple/workdsh/.test-runtime/preview/profiles/preview/node_modules/workdsh-plugin-skills/resources/skills/workdsh-workbench-dev |
| 所属插件 | workdsh-plugin-skills |
| 文件数 | 8 |
| 体积 | 46.9 KB |
| 被忽略文件 | 无 |

## 3. 引用关系

- 本次范围内专家配备：**未被范围内专家配备**
- 全部专家引用（含范围外）：无

## 4. SKILL.md 正文（全文）

~~~markdown
---
name: workdsh-workbench-dev
description: 在官方 Creator 插件开发流程上补充 WorkDSH 业务 SDK、对象协作、身份和数据保护规范。
---

# 工作台插件开发

先通过宿主技能工具加载官方 `cordis-plugin-development`，在官方 Creator（创造模式，`cordis`）中使用原生会话、权限与工具链。本 Skill 只补充 WorkDSH 的业务约束；Host、Client、Loader、Slots、插件包和安装流程遵循官方 Skill，不另造开发 Agent、会话界面或安装器。

再阅读 [需求定义](references/requirements.md) 和 [工作台产品体验](references/product-experience.md)，从一句想法开始时先阅读 [需求梳理](references/intake.md)，首次制作阅读 [首次开发](references/first-development.md)，修改已有插件阅读 [继续调整](references/iteration.md)。用户本轮的范围、布局选择和暂停要求优先；这些文档不代表能力已经实现。

## 共同规则

1. 从“和 AI 一起梳理”进入且尚未确认需求时，先调用 `workbench_read_creation_request`，阅读 [需求梳理](references/intake.md)，帮助用户明确目标并保存可编辑摘要，不生成源码、构建或安装。用户在左侧确认后，当前会话会关联正式需求与开发工程；已进入开发时先调用 `workbench_read_development_context`，读取当前原生会话实际关联的需求、源码、稳定插件身份、目标实例和候选包；不根据旧提示词猜测归属。先使用上下文 `sdk` 提供的已解析公开文档与类型；不要用 `Service.listService` 查询已知未收录的 WorkDSH 注册服务。官方 API 按官方 Skill 核对本轮用到的服务、事件、工具和 Slot，避免枚举无关接口。WorkDSH 扩展接口须按 [SDK 核验](references/sdk-verification.md) 单独核对：官方 Service 目录未收录不等于服务未运行，Config 的 `absent` 不等于插件未安装。WorkDSH 业务 SDK 和模板也以宿主实际交付的版本为准。不得猜测接口、复制私有实现或伪造回执；缺能力时保留源码和具体未完成项。
2. 先定义业务对象、状态、用户动作、AI 分工和成果落点，再安排模块。项目关联是可选的；项目、资料、技能、专家、连接器使用各自公开服务和授权，不复制管理系统。一个包只声明一个工作台，后续保持包名与工作台 ID；本地制作不要求公开 GitHub 仓库。
3. 保持用户已选布局，包括业务在左、原生会话在右的并排方式；不因套用模板强制重构。复用完整原生会话及其执行过程，不自制 Composer、聊天进度或工具轨迹。AI 通过真实业务工具读取当前对象、执行并写回候选或独立草稿，页面读取后供用户继续加工或采用；跳转聊天、复制提示词或回复结束都不等于完成业务协作。
4. Excel、CSV 等文件复用系统 Office 的公开预览、编辑、保存和导出能力，不另写电子表格编辑器。业务页面负责字段对应、核对和统计；资料引用准确的资产及版本，统计由代码对完整已授权输入的固定修订确定性计算，不能拿截断预览作统计源。保存新文件版本后明确采用，历史分析与报告保留原快照。
5. 对象、输入版本、会话和身份必须匹配；切换对象、账号或迭代后，旧回复不能写入新对象。保持现有源码、会话历史、用户草稿和业务数据，交接不能覆盖未发送的输入。企业请求只走 Host 已授权业务服务，不向页面提供通用带凭据代理；token、密码和密钥不进入页面、提示词、源码、日志、导出或插件包。
6. 工作台默认按可持续使用的软件交付：围绕业务记录组织首页、列表、详情与返回路径，复杂任务使用应用内导航或页签，不把全部功能纵向堆成无限长页；多记录和页面数量根据本轮业务决定，用户明确要求的一次性工具除外。具体执行 [软件形态要求](references/product-experience.md)。页面使用中文业务字段，说明当前任务、结果与下一步，呈现正常、异常、空数据和失败恢复状态。业务插件不自行增加宿主一级菜单；平台统一通过原生“工作台”入口提供已安装应用及开发记录，不生成平级菜单。只使用实际已声明的官方公开插槽；不修改官方侧栏包、注入私有 DOM 或用缩进伪造菜单分组。平台提供的返回工作台和常用应用设置不在业务页重复实现；业务内部仍需提供返回模块或记录列表的路径，不能用浏览器返回代替。具体记录直达需要稳定对象标识和访问核对，不能拿会话链接冒充。局部修改沿用同一源码和插件身份。
7. 通用安装使用官方 `plugin_manager install_bundle`，以已核实 tgz 绝对路径、`enabled:false` 安装；再用候选 version、sha256 调用 `workbench_verify_native_installation` 核对字节并登记。`activationVerified:false` 只表示本工具未核验启用，绝不表示停用或启用失败，不因此重复安装。用户已授权启用或打开试用时，按回执 `list_bundles`（沿 nextOffset 分页）找到实际包名并核对版本、error，再 `set_bundle`，target 为该包名、enabled 为 true；读取 application、warnings、nextStep。不能猜 entryId、拼 include: 前缀或用 `set_plugin` 代替 bundle 选择；不能手改 Profile。不具备启用授权时，由用户在工作台列表启用。安装结果未知先核对事实；restart-required 如实报告，不自行重启其他任务。安装、登记、活动版本和页面可用分别报告。
8. 依据用户本轮授权推进。要求先讨论时先明确工作路径；要求看效果时提供可交互效果并说明模拟范围；暂停打包时不自动构建或安装。生成代码、包检查通过、安装成功和页面可用分别报告；构建与 Slot 注册不能代替真实服务和用户操作验收。

页面验收在当前已认证的宿主应用页面操作工作台：Desktop 使用正在运行的 WebView；Web 使用当前已登录应用页面。独立任务浏览器不自动共享宿主登录态，其 401 不能证明工作台失败。此时停止独立浏览器验收路径，返回已认证宿主页面或保留“页面未验收”，不得查找、读取或复制 token、cookie、凭据文件，或添加认证请求头绕过访问控制。源码和静态检查仍可继续，但不能冒充宿主页面操作。

## 每轮交付

保存需求修订、源码关联和修订、当前迭代、候选版本及摘要、目标安装实例、官方安装与平台登记的实际结果、业务验收和未完成项。候选包存在、安装字节匹配不证明它由当前源码修订生成，构建来源仍需实际证据。源码和需求文件提供恢复上下文；事实以当前运行时及持久记录为准。中断后先核对结果，不自动重复安装或创建会话。

## 安装前的原生加载核对

Host 入口必须在 `inject` 中声明实际使用的每项宿主服务，包括通过 `ctx.get(...)` 和 `ctx.storageDomain` 等属性取得的服务；例如工作台注册、存储、连接与身份服务。不能只声明工作台注册服务。服务可选时使用官方可选生命周期注入，不用未声明的读取绕过依赖检查。

构建和 tgz 校验不证明插件可以启动。候选交付前，在隔离存储中通过官方 Cordis 插件生命周期加载 Host 入口，确认业务路由已注册、存储可打开、卸载可释放。直接调用 `apply(ctx)` 或仅导入模块不能代替这项检查，因为它们可能绕过官方注入约束。安装后分别检查真实字节、启用选择、Host 注册和 Client 页面；某组件失败时保留候选和数据，修正开发源码并增加版本号，再经正常更新流程验收，不修改已安装包文件。

交付前执行 [构建后的启动检查](references/startup-validation.md)，不要把打包成功视为应用启动成功。
~~~

## 5. 资源清单

| 文件 | 字节 | SHA-256（前 16） |
|---|---|---|
| SKILL.md | 8126 | faf4bfd81985e199 |
| references/first-development.md | 6117 | cb340b0e76f3a0c3 |
| references/intake.md | 2448 | c59d7d29dae499e3 |
| references/iteration.md | 6491 | 85fe6e9492b66486 |
| references/product-experience.md | 6844 | dbdde2b57f0423a2 |
| references/requirements.md | 6619 | 9aab1038d741a3a4 |
| references/sdk-verification.md | 4872 | 6c842a91a55ecf5b |
| references/startup-validation.md | 6509 | 7ac555b5e944b195 |

## 6. MCP 关联（文本取证）

未发现 mcp__<server>__ 或 kp_ 工具引用：只依赖自身脚本与工作区文件。

## 7. 副本

逐字节副本：`99-原件/skills/workdsh-workbench-dev/`（未改写；已用 SHA-256 复算校验）。
