# 技能：resanity

> 本文件由 `tools/expert-report/build.mjs` 从本机权威数据源自动构建，内容基准时间（UTC）：2026-11-02T13:31:19Z（= 源文件最新 mtime；构建器实际运行时间见 .state/manifest.json）。所有内容可凭 07-核对/ 下的清单与哈希复算；手工修改会在下次构建被覆盖。

## 1. 元数据

| 字段 | 值 |
|---|---|
| name | resanity |
| description | 用于投资研究中的可能性地图、承重主张审计和证据边界检查；投资研究可自动使用。请求涉及证券、上市公司、行业利润池、估值或市场定价时，即使对象尚未给全也应使用。非投资任务仅在用户明确要求使用 Resanity、绘制可能性地图、审计承重主张或更新认知锚时使用；不要用于普通总结、编码、改写或一般问答。以原子主张卡区分观察、推断边界和决策影响，并按需加载投资、锚或正式审计参考。 |

## 2. 位置与来源

| 项 | 值 |
|---|---|
| 来源类型 | 用户/共享技能根 |
| 目录 | /Users/apple/.agents/skills/resanity |
| 所属插件 | （非插件内置） |
| 文件数 | 77 |
| 体积 | 575.0 KB |
| 被忽略文件 | 无 |

## 3. 引用关系

- 本次范围内专家配备：**未被范围内专家配备**
- 全部专家引用（含范围外）：无

## 4. SKILL.md 正文（全文）

~~~markdown
---
name: resanity
description: 用于投资研究中的可能性地图、承重主张审计和证据边界检查；投资研究可自动使用。请求涉及证券、上市公司、行业利润池、估值或市场定价时，即使对象尚未给全也应使用。非投资任务仅在用户明确要求使用 Resanity、绘制可能性地图、审计承重主张或更新认知锚时使用；不要用于普通总结、编码、改写或一般问答。以原子主张卡区分观察、推断边界和决策影响，并按需加载投资、锚或正式审计参考。
---

# Resanity

把研究收敛为可检查的主张，不把流程本身当成答案。模型拥有问题定义、证据解释、结论、下一步和锚更新等全部研究语义；代码只做机械检查。用户可直接阅读的回答始终是第一交付物；保存的 `report.md` 只是它的持久化副本，机械审计不能成为报告交付的前置条件。

## 原子主张协议

先明确这次回答服务的决策、时间边界和 as-of。只在存在真实分叉时追问；否则声明合理假设并继续。

把根结论限制在 1–5 条真正承重的主张，并为每条写一张最小主张卡。没有进入主张卡的判断不得承重根结论：

```text
主张：<可证伪的一句话>
时态：EVENT_BY_DATE / STATE_AT_AS_OF / ABSENCE_BY_AS_OF / TIMELESS
观察到什么：<来源中直接出现的事实；注明来源、发布日期、对象和范围>
可以推出什么：<由观察支持到哪一级>
不能推出什么：<最容易被误推的更强结论>
对决策的影响：<支持、削弱、保持不确定，或改变哪个下一步>
证据边界（针对“主张”整句，不是其中的观察）：FACT / SINGLE_SOURCE / INFERENCE / HYPOTHESIS / NO_RESULT / INSUFFICIENT
来源属性（可选，不是证据边界）：USER_PROVIDED / SINGLE_UPSTREAM_SOURCE
```

遵守以下不变量：

- 每张主张卡都不得省略时态、观察、可推出、不可推出和决策影响；材料不足就明写未知。
- 证据边界标注整条主张；`FACT` 只用于直接复述来源观察。只要主张包含因果、归纳、外推、可能性、价值判断，或“X 说明 Y 尚未闭合”之类证据解释，就标为 `INFERENCE` 或更弱。`SINGLE_SOURCE` 只用于依赖单一上游来源的报告事实。
- 每张卡只给“主张”整句一个证据边界；若观察是事实而主张含推断，取更弱的 `INFERENCE`，不要在边界行拆成多个标签。若单一来源导致主张仍不足，边界写 `INSUFFICIENT`，并把 `SINGLE_UPSTREAM_SOURCE` 放入来源属性或观察。
- 形式逻辑裁决也属于推断：例如由一个反例否定“全部、全国、始终”等全称命题时，反例放观察栏，裁决主张仍标 `INFERENCE`。
- 只观察到原始数值差时，不写“统计显著”或“效果确立”；需要不确定性、显著性或稳健性材料才能升级。
- 断言来源“没有”某项数据前，先检查相关章节、表格和附件；已保存来源若含相反或限定性观察，必须纳入主张卡，不能用“未找到”跳过。
- 对每条承重主张先声明时态；默认用截止日前事件 `EVENT_BY_DATE`，只有来源明确支持状态覆盖至 as-of 才用 `STATE_AT_AS_OF`，只有具名语料库/官方索引及其覆盖区间完整时才用 `ABSENCE_BY_AS_OF`，与时间无关才用 `TIMELESS`。事件只能由截止日当日或之前的带日期原始发布、版本化原件或归档快照承重；规范、政策或产品状态逐字服从带日期原始文件，当前活页、无日期页、URL、文件名、版本号暗示或“早已公开/看起来稳定”都不能回填历史状态。找不到合格时态来源就把该维度标为 `INSUFFICIENT`。
- 让结论强度服从最弱承重主张，而不是最强的一条材料。
- 可能性地图先区分相容性证据与区分性证据。多个假设都能解释同一时间、区域或对象共现时，保持并列，不给伪精确权重；只有在某假设为假时应出现不同结果的观察或实验才可重排。回滚或阴性测试只有在动作已生效、覆盖范围已确认且指标对变化敏感时才足以明显降权。
- 按上游血缘判断独立性；转载数量不等于多源。
- 用户提供且要求接受的信息可作为 `USER_PROVIDED` 前提（来源属性，不是证据边界），但必须与外部可复核事实分开标明；它不能仅因用户确认而升级为公开来源的 `FACT`。
- 把任务声明的来源资格当作硬边界。若任务只允许一手、原始、监管、客户或交易所材料，二手报道、聚合页、搜索摘要和无日期当前页只能用于定位候选，不得承重、不得进入承重快照；找不到合格来源就保留 `INSUFFICIENT`。
- 若保存来源快照或证据表，必须收录报告中每个承重来源；链接仍在正文但未进入快照，不算引用闭合。
- 每个上游来源只保留一份规范原始快照；为检索产生的文本转换件只在确有必要时保留并标为派生件，不把 HTML/PDF/文本转换或搜索结果重复计数。
- 用来源公开时间和明示覆盖期执行 as-of；事后文件不得回填历史判断。
- 把“在声明范围内未找到”与“现实中不存在”分开；沉默不是否认。
- 只有用户或宿主明确给出工具、搜索或时间上限时才启用数字预算；不得猜测上限、已用次数或剩余次数。宿主计量与拒绝回执优先于模型估算；触及显式上限或收到一次预算拒绝就停止发现并用现有证据交付。调用前优先批量读取同一索引、文件或来源；只执行可能改变主张卡或决策的下一步，失败动作只降级，不换同义工具重试。
- 把自己的反例称为 self-countercase；没有独立上下文就不声称独立质证。

## 按问题路由

只加载本次需要的参考文件，并完整读取所选文件：

- 请求或既有上下文明示涉及证券、公司经济暴露、行业利润池、价格、估值或市场预期时，读取 [references/investing.md](references/investing.md)。不要仅因出现订单、合同、公告或验收等词加载投资 profile。
- 用户明确要求创建、读取、更新或复盘认知锚时，读取 [references/anchors.md](references/anchors.md)。普通研究不要默认写锚。
- 用户要求保存报告、生成审计收据、做验证或检查方法身份时，读取 [references/formal-audit.md](references/formal-audit.md)。用户只要求使用“最新/当前 Resanity”时也读取其中的身份部分，但这不自动要求生成完整收据。普通聊天不要生成收据。
- 用户限定封闭语料时，只使用给定材料，并把语料无法裁决之处保留为 `INSUFFICIENT`。

若同时命中多个条件，只加载对应组合；不要把投资术语带入非投资问题。

## 选择输出模块

按决策需要选择最小充分组合，不强制长报告：

- 根结论与条件；
- 1–5 张原子主张卡；
- 可能性地图与最弱环节；
- 反例或替代解释；
- 唯一最低成本下一验证；
- 认知锚更新；
- 正式证据表与机械收据。

普通问题可以只交付结论、关键主张卡和下一验证。缺口必须可见，不用篇幅、表格或术语伪装完整。
无论工具、写入或预算状态如何，最后都必须给用户一份可直接阅读的研究报告，至少包含根结论、证据边界和唯一下一验证。未知、未闭合或 `INSUFFICIENT` 是报告内容，不是阻止报告的状态；来源表、过程说明或工具调用协议不能替代报告，也不得以待执行的工具请求、协议标记或半截表格结束。
报告交付与机械审计是两条独立轴：先交付报告；用户要求保存时先写 `report.md`；随后才尝试来源快照、宿主收据和审计收据。文件写入或审计失败时，在最终回答中交付同一报告并披露“未保存”或“审计未闭合”，不得改写成“报告未完成”。
用户显式要求使用 Resanity、最新版或正式审计时，在报告末尾简短披露本次实际核验的方法身份，以及机械审计是未运行、未闭合还是通过；这些只是本次边界说明，不建立运行状态机。

## 交付编译（不得省略）

完成研究后、发出最终回答前，静默执行一次；它不是新状态，不输出检查过程：

1. 先组装根结论、1–5 张承重主张卡和唯一下一验证，再放入可选模块。
2. 扫描标题、根结论、摘要、表格和主张中的现实否定；没有具名合格来源明确否定时不得写“未形成、不成立、不存在、没有项目、闭环未闭、尚无收入”等同义结论。只要承重缺口为 `INSUFFICIENT`，根结论采用投资 profile 的固定证据语法，明确“公开证据支持什么、尚未闭合什么、现实状态未知、NOT_EVALUABLE”。
3. 逐卡确认一个时态和一个证据边界；含解释的整句不用 `FACT`，边界行不出现第二个标签。
4. 把“唯一下一验证”收敛为一个外部证据获取单元：只有一项具名证据对象，用它裁决一个承重分叉。“获取 X，用它核验 Y”是一个单元；同时索取合同、发票、结算单或访谈多个对象不是。
5. 任一项不通过就就地重写相应内容，然后直接交付报告；不启动新搜索、新工具或新审计。

## 边界

- 不替用户执行外部行动，不生成订单、仓位或回报承诺。
- 不建立研究状态机、候选晋级、固定多 Agent 编排或第二语义数据库。
- 不自动补证据、改写结论或重试研究；不得把工程测试、机械审计或有限评审升级成研究有效、Alpha 或 PMF。
~~~

## 5. 资源清单

| 文件 | 字节 | SHA-256（前 16） |
|---|---|---|
| .gitignore | 106 | 0d06a6c4b63e5057 |
| ARCHITECTURE.md | 7527 | 1d101be75ed5c0fe |
| LICENSE | 1078 | 9461be74c2f55ec9 |
| README.md | 18195 | feeb10b6f523be52 |
| SKILL.md | 9845 | f55a77f8f9f9d0d2 |
| agents/openai.yaml | 344 | 20b26429cc3c3d6b |
| anchors/_example.md | 469 | ae8461ec7daf3825 |
| anchors/index.md | 306 | 1fd6475a396e5e19 |
| assets/logo.svg | 701 | 796add41b57c655f |
| cordis.patch.yml | 144 | b4886bbc2a1cacb4 |
| journal/decisions.md | 420 | 664dbabdb4a333c3 |
| lib/index.js | 55065 | f94eac796cf13766 |
| package.json | 2225 | 564abcf6e47a07f7 |
| preset/agent.cordis.yml | 8662 | 80539aa34bda39b7 |
| preset/preset.yml | 245 | 52594dc37eb57faa |
| references/anchors.md | 2451 | 03cbcfb34d1c8ed2 |
| references/formal-audit.md | 6317 | 62097c69d6a5e845 |
| references/investing.md | 7682 | e768592c95307670 |
| scripts/ashare_disclosures.py | 13144 | d3842f292358975a |
| scripts/free_market_observations.py | 29703 | bdc62eb3d77373ba |
| scripts/tier1_providers.py | 6493 | e794ea1f1879eeda |
| test/dsh-budget-guard.test.mjs | 1653 | b83fa95ee6c8a7df |
| test/fixtures/unreadable-decision.md | 1549 | 165bc2e1ef6ee458 |
| test/plugin.test.mjs | 30617 | 2d327d9827f57886 |
| test/test_anchor_check.py | 2038 | dccf611f16af0c0b |
| test/test_ashare_disclosures.py | 6447 | 9a7ca5cc79d76b04 |
| test/test_failure_tracker.py | 2843 | e7ad6b13504a47bc |
| test/test_final_ab_dsh_runner.py | 26790 | 2ada0c286f3d5690 |
| test/test_final_ab_runner.py | 7505 | 1356d6decc1558cf |
| test/test_free_market_observations.py | 5642 | c41b30ad6b60dad6 |
| test/test_release_tree.py | 2036 | 17ad6c39d56c8f07 |
| test/test_report_check.py | 6620 | 2562c5b1a675d374 |
| test/test_research_check.py | 16205 | 83a615aa0b3ea6ab |
| test/test_skill_identity.py | 4345 | 28119115758005d2 |
| test/test_v2_validation_runner.py | 5583 | 610fc24c103913c9 |
| test/test_validation_contract.py | 13450 | acb523784e519df5 |
| tools/anchor_check.py | 5124 | fa7d5c0815fbe782 |
| tools/failure_tracker.py | 5007 | ff3231f2f5f7292a |
| tools/report_check.py | 10163 | 257c3b4a8deb11ea |
| tools/research_check.py | 31231 | b1eba5b05f652955 |
| tools/skill_identity.py | 9215 | d313206f7d8fc1d8 |
| tools/validation_source_check.py | 11700 | c74728bb8170fb9b |
| validation/README.md | 2243 | 650908eb2e9d6295 |
| validation/eval/README.md | 2129 | 3b6b6aa6f08c4082 |
| validation/eval/collect.py | 4175 | 5cd68fbe67b5b86c |
| validation/eval/questions.md | 1903 | a0c610a7c8b5467d |
| validation/eval/rubric.md | 3514 | f4d988027b274c24 |
| validation/host-receipt-template.json | 658 | 5f88e6c56d002a31 |
| validation/receipt-template.json | 1861 | 6f1b7eb63d2db12d |
| validation/v2/README.md | 13116 | 91dd398e3fb817b7 |
| validation/v2/check_preset.mjs | 12672 | 2ccadcc108993531 |
| validation/v2/dsh-budget-guard/cordis.patch.yml | 86 | c7c9bd4a4b03ff60 |
| validation/v2/dsh-budget-guard/index.js | 2823 | 6b38c77aed3cfeff |
| validation/v2/dsh-budget-guard/package.json | 483 | f3524c780fcdea39 |
| validation/v2/prelayers-receipt-template.json | 583 | 4923ca6a553c1d0d |
| validation/v2/prompts/anchor-active-archived.md | 430 | dd4bb4015ebc959f |
| validation/v2/prompts/anchor-active-realized.md | 480 | 210a50fb08d5fe1d |
| validation/v2/prompts/anchor-active.md | 526 | db3a69b3a77e9118 |
| validation/v2/prompts/anchor-archived.md | 478 | af1fd10eded836a5 |
| validation/v2/prompts/anchor-realized.md | 396 | 72193fd97ff2ef15 |
| validation/v2/prompts/anchor-refuted.md | 428 | cdfd6fede43cc94e |
| validation/v2/prompts/candidate-instruction.md | 255 | fabf5623093b82ba |
| validation/v2/prompts/core-debug.md | 654 | b6f4942fce6c56d0 |
| validation/v2/prompts/core-policy.md | 613 | 15ed83f5f3f1ce0b |
| validation/v2/prompts/core-product.md | 607 | cfb81e655337e130 |
| validation/v2/prompts/investing-company.md | 1749 | 784cff6af6379938 |
| validation/v2/prompts/investing-profit-pool.md | 1950 | 2137a92d10ad59a5 |
| validation/v2/prompts/network-investing.md | 673 | cfa7ba24bdfd3f52 |
| validation/v2/prompts/network-policy.md | 629 | 4708d5df8533a7e6 |
| validation/v2/prompts/network-product.md | 585 | feeb8e27aab469de |
| validation/v2/prompts/strong-baseline.md | 739 | 572a787b42159e28 |
| validation/v2/run_dsh_prelayers.py | 23880 | bbd861150e58c3a2 |
| validation/v2/run_final_ab.py | 37189 | daa29c354c52eff8 |
| validation/v2/run_final_ab_dsh.py | 62764 | 01436538f8cc360c |
| validation/v2/run_validation.py | 21686 | 930e4ea4acc94d8a |
| validation/v2/suite.json | 6283 | aa4829b3dfa230dd |
| validation/v2/sync_preset.mjs | 2680 | 9c1c339e27905cea |

## 6. MCP 关联（文本取证）

未发现 mcp__<server>__ 或 kp_ 工具引用：只依赖自身脚本与工作区文件。

## 7. 副本

逐字节副本：`99-原件/skills/resanity/`（未改写；已用 SHA-256 复算校验）。
