# 技能：workdsh-skill-creator

> 本文件由 `tools/expert-report/build.mjs` 从本机权威数据源自动构建，内容基准时间（UTC）：2026-11-02T11:27:23Z（= 源文件最新 mtime；构建器实际运行时间见 .state/manifest.json）。所有内容可凭 07-核对/ 下的清单与哈希复算；手工修改会在下次构建被覆盖。

## 1. 元数据

| 字段 | 值 |
|---|---|
| name | workdsh-skill-creator |
| description | 创建或更新技能，将专业知识、工作流程、工具操作和可复用脚本、参考文档、模板组织成可校验、可分发的技能包。 |
| when-to-use | 用户希望创建、修改、完善或打包技能时使用。 |
| license | Apache-2.0; see LICENSE.workbuddy.txt and NOTICE.md |

## 2. 位置与来源

| 项 | 值 |
|---|---|
| 来源类型 | 插件内置（bundled） |
| 目录 | /Users/apple/workdsh/.test-runtime/preview/profiles/preview/node_modules/workdsh-plugin-skills/resources/skills/workdsh-skill-creator |
| 所属插件 | workdsh-plugin-skills |
| 文件数 | 10 |
| 体积 | 49.5 KB |
| 被忽略文件 | 无 |

## 3. 引用关系

- 本次范围内专家配备：**未被范围内专家配备**
- 全部专家引用（含范围外）：无

## 4. SKILL.md 正文（全文）

~~~markdown
---
name: workdsh-skill-creator
description: 创建或更新技能，将专业知识、工作流程、工具操作和可复用脚本、参考文档、模板组织成可校验、可分发的技能包。
when-to-use: 用户希望创建、修改、完善或打包技能时使用。
license: Apache-2.0; see LICENSE.workbuddy.txt and NOTICE.md
---

# Skill Creator

This skill provides guidance for creating effective skills.

Read [DSH authoring adaptation](references/dsh-authoring.md) for installation, available lifecycle tools and update boundaries. Read [bundle production](references/bundle-production.md) when executing the bundled scripts. These platform notes supplement the creation process below.

## About Skills

Skills are modular, self-contained packages that extend WorkDSH's capabilities by providing
specialized knowledge, workflows, and tools. Think of them as "onboarding guides" for specific
domains or tasks—they transform WorkDSH from a general-purpose agent into a specialized agent
equipped with procedural knowledge that no model can fully possess.

### What Skills Provide

1. Specialized workflows - Multi-step procedures for specific domains
2. Tool integrations - Instructions for working with specific file formats or APIs
3. Domain expertise - Company-specific knowledge, schemas, business logic
4. Bundled resources - Scripts, references, and assets for complex and repetitive tasks

### Anatomy of a Skill

Every skill consists of a required SKILL.md file and optional bundled resources:

```
skill-name/
├── SKILL.md (required)
│   ├── YAML frontmatter metadata (required)
│   │   ├── name: (required)
│   │   └── description: (required)
│   └── Markdown instructions (required)
└── Bundled Resources (optional)
    ├── scripts/          - Executable code (Python/Bash/etc.)
    ├── references/       - Documentation intended to be loaded into context as needed
    └── assets/           - Files used in output (templates, icons, fonts, etc.)
```

#### SKILL.md (required)

**Metadata Quality:** The `name` and `description` in YAML frontmatter determine when WorkDSH will use the skill. Be specific about what the skill does and when to use it. Use the third-person (e.g. "This skill should be used when..." instead of "Use this skill when...").

#### Bundled Resources (optional)

##### Scripts (`scripts/`)

Executable code (Python/Bash/etc.) for tasks that require deterministic reliability or are repeatedly rewritten.

- **When to include**: When the same code is being rewritten repeatedly or deterministic reliability is needed
- **Example**: `scripts/rotate_pdf.py` for PDF rotation tasks
- **Benefits**: Token efficient, deterministic, may be executed without loading into context
- **Note**: Scripts may still need to be read by WorkDSH for patching or environment-specific adjustments

##### References (`references/`)

Documentation and reference material intended to be loaded as needed into context to inform WorkDSH's process and thinking.

- **When to include**: For documentation that WorkDSH should reference while working
- **Examples**: `references/finance.md` for financial schemas, `references/mnda.md` for company NDA template, `references/policies.md` for company policies, `references/api_docs.md` for API specifications
- **Use cases**: Database schemas, API documentation, domain knowledge, company policies, detailed workflow guides
- **Benefits**: Keeps SKILL.md lean, loaded only when WorkDSH determines it's needed
- **Best practice**: If files are large (>10k words), include grep search patterns in SKILL.md
- **Avoid duplication**: Information should live in either SKILL.md or references files, not both. Prefer references files for detailed information unless it's truly core to the skill—this keeps SKILL.md lean while making information discoverable without hogging the context window. Keep only essential procedural instructions and workflow guidance in SKILL.md; move detailed reference material, schemas, and examples to references files.

##### Assets (`assets/`)

Files not intended to be loaded into context, but rather used within the output WorkDSH produces.

- **When to include**: When the skill needs files that will be used in the final output
- **Examples**: `assets/logo.png` for brand assets, `assets/slides.pptx` for PowerPoint templates, `assets/frontend-template/` for HTML/React boilerplate, `assets/font.ttf` for typography
- **Use cases**: Templates, images, icons, boilerplate code, fonts, sample documents that get copied or modified
- **Benefits**: Separates output resources from documentation, enables WorkDSH to use files without loading them into context

### Progressive Disclosure Design Principle

Skills use a three-level loading system to manage context efficiently:

1. **Metadata (name + description)** - Always in context (~100 words)
2. **SKILL.md body** - When skill triggers (<5k words)
3. **Bundled resources** - As needed by WorkDSH (Unlimited*)

*Unlimited because scripts can be executed without reading into context window.

## Skill Creation Process

To create a skill, follow the "Skill Creation Process" in order, skipping steps only if there is a clear reason why they are not applicable.

### Step 1: Understanding the Skill with Concrete Examples

Skip this step only when the skill's usage patterns are already clearly understood. It remains valuable even when working with an existing skill.

To create an effective skill, clearly understand concrete examples of how the skill will be used. This understanding can come from either direct user examples or generated examples that are validated with user feedback.

For example, when building an image-editor skill, relevant questions include:

- "What functionality should the image-editor skill support? Editing, rotating, anything else?"
- "Can you give some examples of how this skill would be used?"
- "I can imagine users asking for things like 'Remove the red-eye from this image' or 'Rotate this image'. Are there other ways you imagine this skill being used?"
- "What would a user say that should trigger this skill?"

To avoid overwhelming users, avoid asking too many questions in a single message. Start with the most important questions and follow up as needed for better effectiveness.

Conclude this step when there is a clear sense of the functionality the skill should support.

### Step 2: Planning the Reusable Skill Contents

To turn concrete examples into an effective skill, analyze each example by:

1. Considering how to execute on the example from scratch
2. Identifying what scripts, references, and assets would be helpful when executing these workflows repeatedly

Example: When building a `pdf-editor` skill to handle queries like "Help me rotate this PDF," the analysis shows:

1. Rotating a PDF requires re-writing the same code each time
2. A `scripts/rotate_pdf.py` script would be helpful to store in the skill

Example: When designing a `frontend-webapp-builder` skill for queries like "Build me a todo app" or "Build me a dashboard to track my steps," the analysis shows:

1. Writing a frontend webapp requires the same boilerplate HTML/React each time
2. An `assets/hello-world/` template containing the boilerplate HTML/React project files would be helpful to store in the skill

Example: When building a `big-query` skill to handle queries like "How many users have logged in today?" the analysis shows:

1. Querying BigQuery requires re-discovering the table schemas and relationships each time
2. A `references/schema.md` file documenting the table schemas would be helpful to store in the skill

To establish the skill's contents, analyze each concrete example to create a list of the reusable resources to include: scripts, references, and assets.

### Step 3: Initializing the Skill

At this point, it is time to actually create the skill.

Skip this step only if the skill being developed already exists, and iteration or packaging is needed. In this case, continue to the next step.

Initialize only in a workspace draft directory, never directly in an official installed skill root. Provide an explicit output directory:

```bash
python3 <skill-resource-base>/scripts/init_skill.py <skill-name> --path <workspace>/skill-drafts
```

Use the actual resourceBase path exposed by Harness, not the literal placeholder above. If shell/Python is unavailable, explain the execution gap; do not claim files were generated.

The script:

- Creates the skill directory at the specified path
- Generates a SKILL.md template with proper frontmatter and TODO placeholders
- Creates example resource directories: `scripts/`, `references/`, and `assets/`
- Adds example files in each directory that can be customized or deleted

After initialization, customize or remove the generated SKILL.md and example files as needed.

### Step 4: Edit the Skill

When editing the (newly-generated or existing) skill, remember that the skill is being created for another instance of WorkDSH to use. Focus on including information that would be beneficial and non-obvious to WorkDSH. Consider what procedural knowledge, domain-specific details, or reusable assets would help another WorkDSH instance execute these tasks more effectively.

#### Start with Reusable Skill Contents

To begin implementation, start with the reusable resources identified above: `scripts/`, `references/`, and `assets/` files. Note that this step may require user input. For example, when implementing a `brand-guidelines` skill, the user may need to provide brand assets or templates to store in `assets/`, or documentation to store in `references/`.

Also, delete any example files and directories not needed for the skill. The initialization script creates example files in `scripts/`, `references/`, and `assets/` to demonstrate structure, but most skills won't need all of them.

#### Update SKILL.md

**Writing Style:** Write the entire skill using **imperative/infinitive form** (verb-first instructions), not second person. Use objective, instructional language (e.g., "To accomplish X, do Y" rather than "You should do X" or "If you need to do X"). This maintains consistency and clarity for AI consumption.

To complete SKILL.md, answer the following questions:

1. What is the purpose of the skill, in a few sentences?
2. When should the skill be used?
3. In practice, how should WorkDSH use the skill? All reusable skill contents developed above should be referenced so that WorkDSH knows how to use them.

### Step 5: Packaging a Skill

Once the skill is ready, it should be packaged into a distributable zip file that gets shared with the user. The packaging process automatically validates the skill first to ensure it meets all requirements:

```bash
python3 <skill-resource-base>/scripts/package_skill.py <path/to/skill-folder>
```

Optional output directory specification:

```bash
python3 <skill-resource-base>/scripts/package_skill.py <path/to/skill-folder> ./dist
```

The packaging script will:

1. **Validate** the skill automatically, checking:
   - Basic frontmatter boundaries and required fields (official Harness parsing remains the installation gate)
   - Skill naming conventions and directory structure
   - Description presence and basic character restrictions (semantic routing quality requires review)
   - File organization, unresolved placeholders and relative Markdown resource references

2. **Package** the skill if validation passes, creating a zip file named after the skill (e.g., `my-skill.zip`) that includes all files and maintains the proper directory structure for distribution.

If validation fails, the script will report the errors and exit without creating a package. Fix any validation errors and run the packaging command again.

### Step 6: Iterate

After testing the skill, users may request improvements. Often this happens right after using the skill, with fresh context of how the skill performed.

**Iteration workflow:**
1. Use the skill on real tasks
2. Notice struggles or inefficiencies
3. Identify how SKILL.md or bundled resources should be updated
4. Implement changes and test again

## Updating an Existing Skill

Read the existing SKILL.md and relevant resources. Preserve company rules and supplied assets. Use WorkDSH management operations for installed content; never shell-write official skill roots. For a complete bundle update, prepare a separate draft, compare its content with the installed version, export a verified ZIP, and use the dedicated import flow. Same-name imports currently reject collisions: explain the replacement procedure and preserve the original before any user-authorized uninstall. Do not write WorkBuddy market metadata or promise automatic update protection that WorkDSH does not implement.
~~~

## 5. 资源清单

| 文件 | 字节 | SHA-256（前 16） |
|---|---|---|
| LICENSE.workbuddy.txt | 11357 | 58d1e17ffe5109a7 |
| NOTICE.md | 602 | b7dedfe421d529da |
| SKILL.md | 12829 | ae3fd4aabe2a0171 |
| references/bundle-production.md | 1684 | 0896a89bbdb93d79 |
| references/creation-methods.md | 1782 | 7486ebed9eb4a0ab |
| references/dsh-authoring.md | 1720 | f8d0be56f66c89bf |
| references/editing-and-delivery.md | 1577 | db9d7cb4b2a7c1ca |
| scripts/init_skill.py | 12188 | e99480c6f6201de5 |
| scripts/package_skill.py | 3607 | fb79d9990b5582c0 |
| scripts/quick_validate.py | 3316 | 89edbed09daf153e |

## 6. MCP 关联（文本取证）

未发现 mcp__<server>__ 或 kp_ 工具引用：只依赖自身脚本与工作区文件。

## 7. 副本

逐字节副本：`99-原件/skills/workdsh-skill-creator/`（未改写；已用 SHA-256 复算校验）。
