# 技能：claude-paper-summary

> 本文件由 `tools/expert-report/build.mjs` 从本机权威数据源自动构建，内容基准时间（UTC）：2026-11-02T13:05:37Z（= 源文件最新 mtime；构建器实际运行时间见 .state/manifest.json）。所有内容可凭 07-核对/ 下的清单与哈希复算；手工修改会在下次构建被覆盖。

## 1. 元数据

| 字段 | 值 |
|---|---|
| name | claude-paper-summary |
| description | Use this for a quick summary of a research paper's core ideas and key points. Use when you want to quickly understand a paper without deep study materials. Triggers on PDF paths, arXiv URLs, or paper URLs. |
| allowed-tools | Bash, Write, Read |

## 2. 位置与来源

| 项 | 值 |
|---|---|
| 来源类型 | 用户/共享技能根 |
| 目录 | /Users/apple/.agents/skills/claude-paper-summary |
| 所属插件 | （非插件内置） |
| 文件数 | 2 |
| 体积 | 8.9 KB |
| 被忽略文件 | 无 |

## 3. 引用关系

- 本次范围内专家配备：**未被范围内专家配备**
- 全部专家引用（含范围外）：无

## 4. SKILL.md 正文（全文）

~~~markdown
---
name: claude-paper-summary
description: Use this for a quick summary of a research paper's core ideas and key points. Use when you want to quickly understand a paper without deep study materials. Triggers on PDF paths, arXiv URLs, or paper URLs.
allowed-tools: Bash, Write, Read
---

## Cross-Agent Compatibility

> This file is generated from the existing Claude Paper Skill. Its workflow and output requirements are unchanged; only equivalent host metadata, the plugin-root variable, and cross-skill invocation are adapted.

Resolve `CLAUDE_PAPER_PLUGIN_ROOT` to the absolute `plugin/` directory in this package before each shell invocation. From this `SKILL.md`, that directory is `../../plugin`.
Treat every `${CLAUDE_PAPER_PLUGIN_ROOT}` reference below as that resolved absolute directory. Do not substitute the current workspace root.

When this workflow asks to launch the viewer, load and follow the `claude-paper-webui` skill.

---

# Quick Paper Summary Workflow

This skill generates a **concise summary** of a research paper's core ideas and key points.

**When to use:**
- You want to quickly understand what a paper is about
- You need the main contributions without deep technical details
- You're screening papers to decide which to study in depth

**When NOT to use:**
- You want comprehensive study materials (use `claude-paper-study` skill instead)
- You need code demonstrations
- You want interactive visualizations

---

**Language Detection**: Detect the user's language from their input and generate ALL materials in that language.
- Example: User says "我们学习一下这篇论文" → Generate materials in Chinese
- Example: User says "Let's study this paper" → Generate materials in English

---

# Step 0: Check Dependencies (First Run Only)

```bash
if [ ! -f "${CLAUDE_PAPER_PLUGIN_ROOT}/.installed" ]; then
  echo "First run - installing dependencies..."
  cd "${CLAUDE_PAPER_PLUGIN_ROOT}"
  npm install || exit 1

  # Install Python dependencies for image extraction
  python3 -m pip install pymupdf --user 2>/dev/null || pip3 install pymupdf --user 2>/dev/null || echo "Warning: Failed to install pymupdf"

  touch "${CLAUDE_PAPER_PLUGIN_ROOT}/.installed"
  echo "Dependencies installed!"
fi
```

---

# Step 1: Download and Parse PDF

Supports multiple input formats:
- **Local path**: `~/Downloads/paper.pdf`
- **Direct PDF URL**: `https://arxiv.org/pdf/1706.03762.pdf`
- **arXiv URL**: `https://arxiv.org/abs/1706.03762`

## Step 1a: Check input type and download if URL

```bash
USER_INPUT="<user-input>"

# Check if input is a URL (starts with http:// or https://)
if [[ "$USER_INPUT" =~ ^https?:// ]]; then
  # Download PDF from URL
  INPUT_PATH=$(node ${CLAUDE_PAPER_PLUGIN_ROOT}/skills/study/scripts/download-pdf.cjs "$USER_INPUT")
else
  # Use local path directly
  INPUT_PATH="$USER_INPUT"
fi
```

For URLs, the download script will:
- Download PDFs to `/tmp/claude-paper-downloads/`
- Convert arXiv `/abs/` URLs to PDF URLs automatically
- Validate that URLs point to PDF files
- Return the local file path for processing

## Step 1b: Parse PDF

Extract structured information:

```bash
PARSE_OUTPUT_DIR=$(mktemp -d)
node ${CLAUDE_PAPER_PLUGIN_ROOT}/skills/study/scripts/parse-pdf.js \
  "$INPUT_PATH" \
  --output-dir "$PARSE_OUTPUT_DIR"
```

The command prints a small, strict JSON summary to stdout and writes:
- `meta.json` — title, authors, abstract, links, page count, and a context-safe content preview
- `paper.txt` — complete extracted text without the 50k preview limit

Use `paper.txt` as the source for the quick summary. Do not treat `meta.json.content` as the complete paper when `contentTruncated` is true.

---

# Step 2: Generate Quick Summary

Create the paper folder:

```bash
mkdir -p ~/claude-papers/papers/{paper-slug}
cp "<metaPath-from-parser-output>" ~/claude-papers/papers/{paper-slug}/meta.json
cp "<fullTextPath-from-parser-output>" ~/claude-papers/papers/{paper-slug}/paper.txt
cp "$INPUT_PATH" ~/claude-papers/papers/{paper-slug}/paper.pdf
```

Generate **quick-summary.md** with the following structure:

```markdown
# Quick Summary: [Paper Title]

## One Sentence
[One sentence that captures what the paper is about]

## Problem
[What problem does this paper solve? Why is it important?]

## Core Idea
[The key innovation explained in 2-3 sentences. What makes this paper novel?]

## Key Contributions
- [Contribution 1]
- [Contribution 2]
- [Contribution 3]
- [Contribution 4 if applicable]

## Main Results
| Metric | Value | Dataset/Benchmark |
|--------|-------|-------------------|
| [metric1] | [value] | [dataset] |
| [metric2] | [value] | [dataset] |

## Why It Matters
[Practical implications. How does this advance the field? What can we now do that we couldn't before?]

## Limitations（已下沉）

见 `references/Limitations模板.md`。摘要：Limitations 章节的写法模板与
常见错误（把「作者没做」写成「方法不行」、把未来工作写成缺陷）。

## One Sentence
This paper introduces the Transformer, a neural network architecture based entirely on attention mechanisms, achieving state-of-the-art results in machine translation.

## Problem
Sequence transduction models at the time (RNNs, LSTMs, GRUs) process data sequentially, limiting parallelization and struggling with long-range dependencies.

## Core Idea
Replace recurrent layers with self-attention mechanisms, enabling full parallelization during training and direct modeling of dependencies regardless of distance. The Transformer uses multi-head attention to jointly attend to information from different representation subspaces.

## Key Contributions
- First transduction model relying entirely on self-attention, no recurrence
- Multi-head attention mechanism for joint attention across subspaces
- Positional encodings to inject sequence order information
- Achieved 28.4 BLEU on WMT 2014 English-to-German (2+ BLEU improvement)
- Training was significantly faster than previous state-of-the-art

## Main Results
| Metric | Value | Dataset/Benchmark |
|--------|-------|-------------------|
| BLEU (EN-DE) | 28.4 | WMT 2014 |
| BLEU (EN-FR) | 41.8 | WMT 2014 |
| Training cost | 3.3 × 10^18 FLOPs | WMT 2014 EN-DE |
| Training time | 12 hours on 8 P100 | WMT 2014 EN-DE |

## Why It Matters
The Transformer eliminated recurrence, enabling massive parallelization and scaling. This architecture became the foundation for BERT, GPT, and virtually all modern large language models, fundamentally changing NLP and beyond.

## Limitations
- Self-attention has O(n²) complexity, limiting sequence length
- No explicit modeling of position beyond learned encodings
- Requires large amounts of training data
```

---

# Notes

- This skill is intentionally **minimal** - it generates only the summary, no code demos, no interactive HTML, no deep-dive materials
- For users who want more, they can use `claude-paper-study` skill to generate comprehensive materials
- The summary should be **self-contained** and readable in under 5 minutes
- Focus on **conceptual clarity** over technical details
~~~

## 5. 资源清单

| 文件 | 字节 | SHA-256（前 16） |
|---|---|---|
| SKILL.md | 7096 | 53cb6b4841db8fd6 |
| references/Limitations模板.md | 1977 | 8d188a1d0c43f3b3 |

## 6. MCP 关联（文本取证）

未发现 mcp__<server>__ 或 kp_ 工具引用：只依赖自身脚本与工作区文件。

## 7. 副本

逐字节副本：`99-原件/skills/claude-paper-summary/`（未改写；已用 SHA-256 复算校验）。
