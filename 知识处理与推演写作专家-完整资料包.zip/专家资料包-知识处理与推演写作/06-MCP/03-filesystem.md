# MCP：filesystem

> 本文件由 `tools/expert-report/build.mjs` 从本机权威数据源自动构建，内容基准时间（UTC）：2026-11-03T02:37:14Z（= 源文件最新 mtime；构建器实际运行时间见 .state/manifest.json）。所有内容可凭 07-核对/ 下的清单与哈希复算；手工修改会在下次构建被覆盖。

## 1. 三视图在场情况

| 视图 | 是否存在 | 说明 |
|---|---|---|
| 会话可见 | 是 | 模型可调用 mcp__filesystem__* |
| WorkDSH 定义 | 是 | DSH_HOME/storages/workdsh_connectors/definitions/filesystem.json |
| 第三方注册表 | 否 | - |
| 运行时状态 | 未采集 | - |

## 2. WorkDSH 定义（磁盘权威）

| 字段 | 值 |
|---|---|
| id | filesystem |
| 标题 | 文件系统 |
| 描述 | 官方 MCP 文件系统服务，读写 ~/mcp-workspace。 |
| 传输 | stdio |
| 命令 | /usr/local/bin/node |
| 参数 | /Users/apple/workdsh-mcp-servers/node_modules/@modelcontextprotocol/server-filesystem/dist/index.js /Users/apple/mcp-workspace |
| URL | - |
| env 键名 | （无） |
| 启用 | true |
| 创建时间 | 2026-09-16T08:05:27.958Z |

## 3. 工具清单（0）

（无工具记录）

## 4. 关联

- 引用该 server 的技能：无
- 引用该项目连接：测试 配置#2、可研报告推演写作 配置#5
