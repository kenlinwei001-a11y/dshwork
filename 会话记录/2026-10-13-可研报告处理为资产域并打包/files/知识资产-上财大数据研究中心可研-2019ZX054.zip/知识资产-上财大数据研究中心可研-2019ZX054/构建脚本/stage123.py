import json, re, sys
from pathlib import Path
sys.path.insert(0, "/Users/apple/Desktop/workdsh/knowledge/knowledge-processing-expert")
sys.path.insert(0, str(Path(__file__).parent))
import corpus_pipeline.full_emit as FE
from corpus_pipeline import run_pipeline

def _safe(t): return re.sub(r'[\\/:*?"<>|\r\n]+', "／", str(t)).strip()[:80]
def emit_style_safe(root, chunks, outline):
    root = Path(root)
    lens = [len(c["text"]) for c in chunks] or [0]
    profile = {"number_format": "千分位、两位小数、单位后置、万元优先，建筑面积单位㎡", "terminology": {},
               "forbidden": ["大约", "左右（除非带明确区间）", "或许"], "citation_style": "〔节点ID｜规则ID｜证据ID〕",
               "table_caption": "表N-<标题>", "person": "第三人称", "avg_chunk_len": sum(lens)//len(lens),
               "chunk_count": len(chunks), "lang": "zh", "tone": "formal"}
    (root/"style").mkdir(parents=True, exist_ok=True)
    (root/"style/style_profile.yaml").write_text(json.dumps(profile, ensure_ascii=False, indent=2), encoding="utf-8")
    tdir = root/"style/section_templates"; tdir.mkdir(parents=True, exist_ok=True)
    for i, sec in enumerate(outline.get("sections", [])):
        (tdir/f"{i+1:02d}-{_safe(sec['title'])}.yaml").write_text(json.dumps({"level": sec["level"], "title": sec["title"], "template": "## "+sec["title"]}, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"templates": len(list(tdir.glob("*.yaml")))}
FE.emit_style = emit_style_safe

WS = Path(__file__).resolve().parent.parent
RAW = (WS/"input/大数据研究中心可研.md").read_text(encoding="utf-8")
LEGAL = ["总论","项目建设背景及必要性","项目建设内容及规模","项目选址及建设条件","项目规划设计方案",
         "节能设计","环境影响评价","卫生防疫与劳动安全","社会稳定风险分析","项目管理及实施进度",
         "项目招投标方案","投资估算及资金筹措","社会效益","结论与建议"]
PKG = WS/"知识资产-上财大数据研究中心可研"
res = run_pipeline(RAW, PKG, LEGAL)
o = res["outline"]
print("sections:", len(o["sections"]), "missing:", o["missing"], "coverage_ok:", o["coverage_ok"])
ch = [json.loads(l) for l in (PKG/"chunks/chunks.jsonl").read_text(encoding="utf-8").splitlines() if l]
print("chunks:", len(ch))
