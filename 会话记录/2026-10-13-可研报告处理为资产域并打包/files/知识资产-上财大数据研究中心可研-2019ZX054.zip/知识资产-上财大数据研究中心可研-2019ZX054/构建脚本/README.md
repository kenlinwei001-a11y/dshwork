# 构建脚本（可复跑）

七道工序 = 确定性驱动 + LLM 语义抽取。**执行顺序不可颠倒。**

| 顺序 | 文件 | 作用 |
| --- | --- | --- |
| 1 | `_prep.py` + `_headings.json` | 纯文本视图 → 结构化 Markdown（章节标记、列表项归一化、追加附录A/附录B） |
| 2 | `stage123.py` | 工序 1-3：归一化、骨架抽取、语义切块 |
| 3 | `sem_a.py` `sem_b.py` | 报告正文的 LLM 语义抽取（事实/规则/论断/证据/十类关系） |
| 4 | `sem_c.py` `sem_d.py` | 附录A 核查结论层、附录B 规范条款层的语义抽取 |
| 5 | `run.py` | 工序 4-7：装配图谱、脱敏重映射、质量登记、索引、法定大纲映射、**依赖台账与矩阵**、契约盘点 |
| 6 | `make_brief.py` | 生成写作输入单（`写作输入/推演写作输入包.md` + `fact-brief.yaml`），并刷新 `inventory.yaml` |
| 7 | `make_section_prompts.py` | 逐节提示词抽取：144 节 / 19 个章节文件 + 索引 + 机器可读版，并刷新 `inventory.yaml` |
| 8 | `make_handoff.py` | 生成移交说明（资产放哪、上下文放什么、12 个工具→文件映射、kp-mcp 连接定义），并刷新 `inventory.yaml` |
| 9 | `make_node_index.py` | 生成节点索引表（人读 MD + 可 grep 的 TSV），并刷新 `inventory.yaml` |

复跑：

```bash
cd /Users/apple/Desktop/workdsh/knowledge/knowledge-processing-expert
.venv/bin/python <本目录>/stage123.py     # 或先跑 _prep.py 重建源文本
.venv/bin/python <本目录>/run.py
python3 <本目录>/make_brief.py            # 必须在 run.py 之后
python3 <本目录>/make_section_prompts.py  # 逐节提示词，同样必须在 run.py 之后
python3 <本目录>/make_handoff.py          # 移交说明，同上
python3 <本目录>/make_node_index.py       # 节点索引表，同上
```

注：脚本内硬编码了语料包输出目录；`stage123.py` 会 `rm -rf` 目标目录，故 `run.py` 与 `make_brief.py` 需依次重跑。

分层纪律：分句/切块/建图/溯源/数值·时间冲突/schema 校验等确定性步骤零 LLM、可复现；
实体/事实/关系/Claim/证据/推理抽取等语义步骤由 LLM 结构化输出并经 validator 校验。
