# -*- coding: utf-8 -*-
"""规则判官校准（薄消费者）：不再自带任何判定逻辑与规则。

推理与事实构造全部来自 semantica_judge（其内部调用官方 Reasoner）。
本文件只做一件事：在 17 组人工标准答案上测准确率并落盘。
"""
from __future__ import annotations
import json, os, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from semantica_env import load_env  # noqa: E402
load_env()
import semantica_judge as J  # noqa: E402

PKG = Path(os.environ["KP_CORPUS_DIR"]) if os.environ.get("KP_CORPUS_DIR") else Path("/Users/apple/Desktop/知识资产-上财大数据研究中心可研-2019ZX054/语料包")
OUT = PKG / "外部核验"


def main():
    vals = {}
    for n in json.loads((PKG / "graph/nodes.yaml").read_text(encoding="utf-8")):
        vals.setdefault(n["subject"], []).append(str(n["value"]))
    rev = json.loads((OUT / "dedup-review.yaml").read_text(encoding="utf-8"))
    gt = [(e["a"], e["b"], e["verdict"], e["similarity"]) for e in rev["entries"]]
    derived, facts, secs, nf = J.reason_pairs([(a, b, s) for a, b, _, s in gt], vals)
    print("Semantica Reasoner: 事实 %d -> 结论 %d（%ss）" % (nf, len(derived), secs))
    ok, detail = 0, []
    for a, b, v, _s in gt:
        gold = {"confirmed_alias": "SAME", "false_positive": "DIFF", "needs_review": "UNKNOWN"}[v]
        got = J.verdict_from(derived, a, b)
        hit = got == gold
        ok += hit
        detail.append({"a": a, "b": b, "human": v, "gold": gold, "rule_engine": got, "hit": hit,
                       "basis": J.basis_from(derived, facts, a, b)})
    acc = ok / len(detail)
    print("Semantica Reasoner vs 人工标准答案：%d/%d = %.0f%%" % (ok, len(detail), acc * 100))
    (OUT / "rule-judge-accuracy.yaml").write_text(json.dumps({
        "judge": "semantica.reasoning.Reasoner.forward_chain()（官方推理引擎）",
        "engine": "semantica.reasoning.Reasoner", "rules_from": "semantica_judge.RULES",
        "elapsed_s": secs, "ground_truth": "处理者人工复核的 17 组",
        "accuracy": round(acc, 3), "n": len(detail), "detail": detail,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        from semantica_metrics import append_history
        append_history(str(OUT), "rule", {"accuracy": round(acc, 3), "n": len(detail),
                                          "engine": "semantica.reasoning.Reasoner"})
    except Exception as e:
        print("  历史追加失败:", str(e)[:80])
    print("已写 rule-judge-accuracy.yaml")


if __name__ == "__main__":
    main()
