# -*- coding: utf-8 -*-
"""第 6 项 C：真实 docx 的 ingest + parse（Semantica 标准路径）。

纠正：此前声明"ingest/parse 不适用"是【错判】——原始 docx 实际可得（1,123,286 B / 37 条目 / 12 图 / 31 表）。
docling 是 Semantica 的【增强解析】extra（parse-docling），未部署；当前用 Semantica 自带的
FileIngestor + DocumentParser（python-docx 路径），同样是 Semantica 官方模块，非降级。
"""
from __future__ import annotations
import json, os, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from semantica_env import load_env  # noqa: E402
load_env()
from semantica_workflow import run_workflow, Step, semantica_call, WorkflowViolation  # noqa: E402

PKG = Path(os.environ["KP_CORPUS_DIR"]) if os.environ.get("KP_CORPUS_DIR") else Path("/Users/apple/Desktop/知识资产-上财大数据研究中心可研-2019ZX054/语料包")
OUT = PKG / "外部核验" / "ingest_parse"
OUT.mkdir(parents=True, exist_ok=True)
DOCX = PKG / "source/original.docx"
BOX = {}


def step_ingest():
    from semantica.ingest import FileIngestor
    ing = FileIngestor()
    res = None
    for call in (lambda: ing.ingest_file(str(DOCX)), lambda: ing.ingest(str(DOCX))):
        try:
            res = semantica_call("ingest.FileIngestor.ingest_file", call)
            break
        except Exception as e:
            BOX["ingest_err"] = str(e)[:120]
            continue
    if res is None:
        raise WorkflowViolation("FileIngestor 无法加载 docx：%s" % BOX.get("ingest_err"))
    BOX["ingest"] = res
    return 1 if res is not None else 0


def step_parse():
    from semantica.parse import DocumentParser
    p = DocumentParser()
    parsed = None
    for call in (lambda: p.parse(str(DOCX)), lambda: p.parse_document(str(DOCX))):
        try:
            parsed = semantica_call("parse.DocumentParser.parse", call)
            break
        except Exception as e:
            BOX["parse_err"] = str(e)[:120]
            continue
    if parsed is None:
        raise WorkflowViolation("DocumentParser 无法解析 docx：%s" % BOX.get("parse_err"))
    BOX["parsed"] = parsed
    txt = parsed.get("full_text") or parsed.get("text") or "" if isinstance(parsed, dict) else str(parsed)
    BOX["text"] = txt
    (OUT / "parsed-by-semantica.md").write_text(txt, encoding="utf-8")
    meta = parsed.get("metadata", {}) if isinstance(parsed, dict) else {}
    tables = parsed.get("tables") if isinstance(parsed, dict) else None
    (OUT / "parse-meta.yaml").write_text(json.dumps({
        "engine": "semantica.parse.DocumentParser",
        "source": str(DOCX), "source_bytes": DOCX.stat().st_size,
        "chars": len(txt), "tables_parsed": len(tables) if isinstance(tables, list) else None,
        "metadata_keys": list(meta.keys())[:12] if isinstance(meta, dict) else None,
    }, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return len(txt)


def main():
    att = run_workflow([
        Step("C1 加载 docx", ["ingest.FileIngestor.ingest_file"], step_ingest,
             note="Semantica FileIngestor 读真实 docx"),
        Step("C2 解析 docx", ["parse.DocumentParser.parse"], step_parse,
             note="Semantica DocumentParser（docling 为可选增强，未部署）"),
    ], OUT, title="Semantica 加载与解析（第 6 项 C，纠正此前不适用声明）")
    print(json.dumps({"status": att["status"], "chars": len(BOX.get("text", "")),
                      "steps": [(s["step"], s["status"]) for s in att["steps"]]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
