# -*- coding: utf-8 -*-
"""动态提示词编译器：画像（LLM）-> 槽位绑定（代码）-> 生成新提示词 -> 抽取（LLM）。

泛化原则（回应"不为每个文档定制"）：
  * ① 文档画像由 LLM 结构化输出，只产出【类型与特征】，不含任何文档专有内容；
  * ② 提示词编译是纯代码：类型 -> 槽位绑定规则 -> 从【可复用资产】取值；
  * ③ 抽取用编译出来的提示词；
  * ④ 校验失败时把失败原因回灌 ②，修改槽位后重新编译（而非重试同一提示词）。
  * 槽位值来源全部是可复用资产：抽取契约、角色词表、术语表、规范依赖清单、历史相似样本。
"""
from __future__ import annotations
import json, os, re, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from semantica_env import load_env  # noqa: E402
load_env()
from semantica_workflow import semantica_call  # noqa: E402

PKG = Path(os.environ["KP_CORPUS_DIR"]) if os.environ.get("KP_CORPUS_DIR") else Path("/Users/apple/Desktop/知识资产-上财大数据研究中心可研-2019ZX054/语料包")
OUT = PKG / "外部核验" / "prompt"
OUT.mkdir(parents=True, exist_ok=True)

# ---------- ① 文档画像（LLM 结构化输出，只给类型与特征） ----------
PROFILE_SCHEMA = {
  "doc_type": "字符串：文档类型（如 可研报告/标准规范/学术论文/招投标文件/政策文件/其他）",
  "genre": "字符串：体裁（论证型/规范型/说明型/数据型）",
  "structure_style": "字符串：结构特征（编号章节/条款编号/论文式/自由段落）",
  "numeric_density": "字符串：数值密度（高/中/低）",
  "entity_categories": "数组：需要抽取的实体类别，如 指标/机构/人员/标准号/设备型号/时间",
  "key_risks": "数组：抽取时该类型最容易出的错，最多 3 条",
}

DOC_TYPE_CANDIDATES = ["可研报告", "标准规范", "学术论文", "招投标文件", "政策文件", "其他"]

def profile_prompt(sample: str, stats: dict) -> str:
    return ("你是文档画像器。只输出 JSON，字段如下：" + json.dumps(PROFILE_SCHEMA, ensure_ascii=False) +
            "\n\n【doc_type 必须从以下候选里选一个】" + "、".join(DOC_TYPE_CANDIDATES) + "\n\n"
            "统计特征：" + json.dumps(stats, ensure_ascii=False) + "\n\n"
            "正文抽样（前 1200 字）：\n" + sample[:1200] + "\n\n"
            "只输出 JSON，不要解释。")

def profile_document(text: str) -> dict:
    from semantica.llms import DeepSeek
    stats = {"chars": len(text),
             "numbered_sections": len(re.findall(r"^\s*\d+(\.\d+)*\s", text, re.M)),
             "clause_refs": len(re.findall(r"第\s*\d+(\.\d+)*\s*条", text)),
             "gb_refs": len(re.findall(r"GB\s*/?\s*T?\s*\d+", text)),
             "units": len(re.findall(r"\d+(?:\.\d+)?\s*(?:㎡|平方米|万元|m3|L/s|kW|KN/m2|%)", text)),
             "tabular_lines": len([l for l in text.splitlines() if l.count("|") >= 2])}
    llm = DeepSeek(model="deepseek-chat", api_key=os.environ["DEEPSEEK_API_KEY"])
    raw = semantica_call("llms.DeepSeek.generate(profile)", lambda: llm.generate(profile_prompt(text, stats)))
    m = re.search(r"\{[\s\S]*\}", raw if isinstance(raw, str) else str(raw))
    prof = json.loads(m.group(0)) if m else {}
    prof["_stats"] = stats
    return prof

# ---------- ② 提示词编译（纯代码；类型 -> 槽位绑定） ----------
# 槽位绑定表：只描述"该类型要哪几组槽位"，不含任何文档专有文本
TYPE_BINDINGS = {
  "可研报告":   {"schema": "fact_spo",  "roles": True,  "terms": True,  "norms": True,  "units": "工程计量", "fewshot": "可研报告"},
  "标准规范":   {"schema": "clause",     "roles": False, "terms": False, "norms": True,  "units": "条文限值", "fewshot": "标准规范"},
  "学术论文":   {"schema": "claim_evidence", "roles": True, "terms": True, "norms": False, "units": "实验量", "fewshot": "学术论文"},
  "招投标文件": {"schema": "fact_spo",  "roles": True,  "terms": True,  "norms": True,  "units": "金额/工期", "fewshot": "招投标文件"},
  "政策文件":   {"schema": "claim_evidence", "roles": True, "terms": False, "norms": True, "units": "无", "fewshot": "政策文件"},
  "其他":       {"schema": "fact_spo",  "roles": True,  "terms": True,  "norms": False, "units": "通用", "fewshot": "其他"},
}

SCHEMAS = {
  "fact_spo": "每条事实输出 {subject, predicate, object, unit, source_hint}；subject 用文档中的规范称谓，不缩写；数值与单位分离。",
  "clause":   "每条条款输出 {clause_no, requirement, limit_value, unit, mandatory}；must 与 should 必须区分（应/宜/可）。",
  "claim_evidence": "每条论断输出 {claim, claim_type, evidence, evidence_span, confidence}；无证据的论断标 evidence=null。",
}

ROLE_LABELS = {"grade_fire": "耐火等级", "grade_safety": "结构安全等级", "grade_seismic": "抗震设防",
               "role_person": "人员职务", "area": "建筑面积", "indicator": "人均/定额指标",
               "standard": "技术标准", "fee": "费用金额", "demand": "需求/合计", "total": "总额",
               "count": "人数/数量", "period": "工期/天数", "state": "状态", "award": "获奖",
               "project": "课题/项目", "fund": "资金", "load": "负荷/荷载", "rate": "费率/系数"}

def _roles_slot():
    """输出【人类可读】的角色类别，不泄漏内部枚举名。"""
    try:
        import semantica_judge as J
        labels = [ROLE_LABELS.get(n, n) for n, _ in J.ROLES]
        return "、".join(labels[:12])
    except Exception:
        return "指标/机构/人员/标准号/设备型号/时间"

def _terms_slot():
    for cand in (Path("/Users/apple/Desktop/workdsh/knowledge/knowledge-processing-expert/corpus_pipeline/domain_rules.py"),
                 PKG.parent / "corpus_pipeline/domain_rules.py"):
        if cand.exists():
            txt = cand.read_text(encoding="utf-8")
            m = re.search(r"TERM_ALIASES\s*=\s*\{([\s\S]{0,600})", txt)
            if m:
                keys = re.findall(r'"([^"]{2,12})"\s*:', m.group(1))
                return "、".join(keys[:18]) or "（术语表为空）"
    return "（未取到术语表）"

def _norms_slot():
    """从 dependencies.yaml 的 links[].norm_node 解析出规范名称（经 nodes.yaml 反查 subject）。"""
    f = PKG / "dependencies.yaml"
    if not f.exists():
        return "（无规范依赖清单）"
    try:
        d = json.loads(f.read_text(encoding="utf-8"))
        links = d.get("links", [])
        id2subj = {}
        nf = PKG / "graph/nodes.yaml"
        if nf.exists():
            for n in json.loads(nf.read_text(encoding="utf-8")):
                id2subj[n["id"]] = n["subject"]
        names = []
        for l in links:
            nm = id2subj.get(l.get("norm_node"), "") or l.get("report_subject", "")
            if nm and nm not in names:
                names.append(nm)
        return "、".join(names[:12]) or "（清单为空）"
    except Exception as e:
        return "（解析失败：%s）" % str(e)[:40]


def _fewshot_slot(kind: str):
    """按【文档类型】检索历史相似语料（借形不借值）；类型不匹配则明确说明未命中。"""
    KEY = {"可研报告": ["feasib", "可研"], "标准规范": ["standard", "gb", "规范"],
           "学术论文": ["paper", "论文"], "招投标文件": ["tender", "招标"], "政策文件": ["policy", "政策"]}
    try:
        lib = Path("/Users/apple/Desktop/workdsh/knowledge/knowledge-processing-expert/corpus-library")
        if lib.exists():
            hits = [p.name for p in lib.iterdir()
                    if any(k in p.name.lower() for k in KEY.get(kind, []))]
            if hits:
                return "历史同类型语料（借形不借值）：" + "、".join(sorted(hits)[:3])
    except Exception:
        pass
    return "（未命中同类型历史语料：「%s」）" % kind


def compile_prompt(profile: dict, failure_hint: str = "") -> dict:
    doc_type = profile.get("doc_type") or "其他"
    bind = TYPE_BINDINGS.get(doc_type, TYPE_BINDINGS["其他"])
    slots = {
      "doc_type": doc_type,
      "schema": SCHEMAS.get(bind["schema"], SCHEMAS["fact_spo"]),
      "entity_categories": "、".join(profile.get("entity_categories") or []) or _roles_slot(),
      "roles": _roles_slot() if bind["roles"] else "（本类型不需要角色词表）",
      "terms": _terms_slot() if bind["terms"] else "（本类型不需要别名表）",
      "norms": _norms_slot() if bind["norms"] else "（本类型不引用规范清单）",
      "units": bind["units"],
      "fewshot": _fewshot_slot(bind["fewshot"]),
      "risks": "；".join(profile.get("key_risks") or []) or "无专项风险提示",
      "failure_hint": failure_hint or "（首轮，无失败反馈）",
    }
    prompt = (
      "【任务】从下列文段抽取结构化知识。\n"
      "【文档类型】{doc_type}（由画像器识别，非人工指定）\n"
      "【输出契约】{schema}\n"
      "【实体类别】{entity_categories}\n"
      "【规范称谓与角色约束】{roles}\n"
      "【术语与别名（同一概念的等价写法）】{terms}\n"
      "【需引用的规范】{norms}\n"
      "【计量口径】{units}\n"
      "【可借形样本】{fewshot}\n"
      "【本类型易错点】{risks}\n"
      "【上轮失败反馈】{failure_hint}\n"
      "【硬约束】数值与单位不得合并书写；原文未给出的量写 null，不得推断；冲突口径并列保留并标 pending。\n"
      "只输出 JSON 数组。"
    ).format(**slots)
    return {"doc_type": doc_type, "binding": bind, "slots": slots, "prompt": prompt}

def doc_level_sample(chunks_path, max_chars: int = 3000, picks: int = 12) -> str:
    """文档级抽样：按位置均匀取【较长】的 chunk 拼合，避免只喂单个碎片导致类型误判。"""
    rows = [json.loads(l) for l in Path(chunks_path).read_text(encoding="utf-8").splitlines() if l]
    if not rows:
        return ""
    step = max(1, len(rows) // picks)
    chosen = [r for r in rows[::step][:picks]]
    chosen.sort(key=lambda r: -len(r.get("text", "")))
    out = ""
    for r in chosen:
        if len(out) >= max_chars:
            break
        out += r.get("text", "")[:400] + chr(10)
    return out[:max_chars]


if __name__ == "__main__":
    import sys as _s
    samples = []
    a = PKG / "chunks/chunks.jsonl"
    if a.exists():
        rows = [json.loads(l) for l in a.read_text(encoding="utf-8").splitlines() if l]
        samples.append(("语料包（可研类，文档级抽样）", doc_level_sample(a)))
    ref = Path("/Users/apple/workdsh/.test-runtime/preview/workdsh-projects/1667349c74609b4500654ac978662087a947e3f197112fe62706d819b8d081f0/references/raw/gb50016-5.1-建筑分类和耐火等级.txt")
    if ref.exists():
        samples.append(("外部检索文段（规范类）", ref.read_text(encoding="utf-8", errors="ignore")[:1500]))
    for name, text in samples:
        prof = profile_document(text)
        comp = compile_prompt(prof)
        print("=" * 70)
        print("样本:", name)
        print("画像:", json.dumps({k: v for k, v in prof.items() if k != "_stats"}, ensure_ascii=False)[:220])
        print("绑定:", json.dumps(comp["binding"], ensure_ascii=False))
        print("编译出的提示词（前 520 字）:")
        print(comp["prompt"][:520])
        (OUT / ("compiled-%s.json" % ("a" if name.startswith("语料") else "b"))).write_text(
            json.dumps({"sample": name, "profile": prof, "compiled": comp}, ensure_ascii=False, indent=2), encoding="utf-8")
