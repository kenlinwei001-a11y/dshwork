# -*- coding: utf-8 -*-
"""主链编排器：把 shell 串联改成代码编排（第 3 项收尾）。

为什么必须用代码 —— shell 串联有三个漏洞，本编排器逐个堵死：
   1. 管道吞退出码：cmd 后接管道再 tail，会让 set -e 失效，核心步骤失败也照样往下跑；
   2. 静默跳过：某步失败后输出被丢进 /dev/null，事后无从察觉；
   3. 无全链证据：每步各自 attestation，缺一份就无法证明整条链都真跑了。

本编排器：
   * 直接 subprocess.run（无 shell、无管道），取真实退出码；
   * 标记为 semantica 的步骤，必须产出并通过其 attestation（引擎证明），否则 fail-closed；
   * 全过程汇总为一份 外部核验/chain-attestation.yaml；
   * 支持 --dry-run / --from / --only。
"""
from __future__ import annotations
import argparse
import json
import os
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

ROOT = Path("/Users/apple/Desktop/workdsh/knowledge/knowledge-processing-expert")
KB = Path(__file__).resolve().parent
PKG = Path(os.environ["KP_CORPUS_DIR"]) if os.environ.get("KP_CORPUS_DIR") else Path("/Users/apple/Desktop/知识资产-上财大数据研究中心可研-2019ZX054/语料包")
OUT = PKG / "外部核验"
SP = "/Users/apple/.venvs/semantica/bin/python"
KP = str(ROOT / ".venv/bin/python")
SYS = sys.executable
SEM = "semantica"


def S(name, cmd, kind="kp", attestation=None, produces=None, note=""):
    return {"name": name, "cmd": cmd, "kind": kind, "attestation": attestation,
            "produces": produces or [], "note": note}


STEPS = [
  S("替身检查", [SYS, str(KB/"semantica_workflow.py"), str(KB)], kind="lint",
    note="发现手写前向链等替代实现即失败"),
  S("七道工序核心", [KP, str(KB/"run.py")], note="kp 侧确定性流水线（30 文件契约）"),
  S("注入产物-输入包", [SYS, str(KB/"make_brief.py")]),
  S("注入产物-章节提示词", [SYS, str(KB/"make_section_prompts.py")]),
  S("注入产物-移交说明", [SYS, str(KB/"make_handoff.py")]),
  S("注入产物-节点索引", [SYS, str(KB/"make_node_index.py")]),
  S("注入产物-启动包", [SYS, str(KB/"make_launch_pack.py")]),
  S("P0a 冲突互证", [SP, str(KB/"semantica_p0.py")], kind=SEM,
    produces=["外部核验/conflicts-semantica.yaml"]),
  S("P1 消歧+溯源+切块", [SP, str(KB/"semantica_p1p2.py")], kind=SEM,
    produces=["外部核验/provenance/prov.db"]),
  S("P1a 候选分类", [SP, str(KB/"semantica_p1a_refine.py")], kind=SEM),
  S("核验报告", [SYS, str(KB/"semantica_report.py")]),
  S("规则判官(官方Reasoner)", [SP, str(KB/"semantica_rule_judge.py")], kind=SEM,
    produces=["外部核验/rule-judge-accuracy.yaml"], note="semantica.reasoning.Reasoner"),
  S("归一队列", [SP, str(KB/"semantica_normalize_queue.py")], kind=SEM,
    attestation="外部核验/semantica-attestation.yaml", note="Reasoner 门禁"),
  S("置信度分档", [SP, str(KB/"semantica_refine_confidence.py")]),
  S("双判官合并", [SP, str(KB/"semantica_merge_judges.py")]),
  S("人工判断清单", [SP, str(KB/"semantica_make_review_md.py")]),
  S("P0b 交叉校验分析", [SYS, str(KB/"semantica_p0b_analyze.py")]),
  S("本体图谱+图构建", [SP, str(KB/"semantica_ontology_stage.py")], kind=SEM,
    attestation="外部核验/ontology/semantica-attestation.yaml",
    produces=["外部核验/ontology/ontology.ttl", "外部核验/ontology/shapes.ttl"]),
  S("动态提示词编译", [SP, str(KB/"semantica_prompt_compiler.py")], kind=SEM,
    produces=["外部核验/prompt/compiled-a.json"]),
  S("归一化(TextNormalizer)", [SP, str(KB/"semantica_normalize_stage.py")], kind=SEM,
    attestation="外部核验/normalize/semantica-attestation.yaml"),
  S("加载与解析(docx)", [SP, str(KB/"semantica_ingest_parse_stage.py")], kind=SEM,
    attestation="外部核验/ingest_parse/semantica-attestation.yaml"),
  S("表格结构落盘", [SP, str(KB/"semantica_parse_tables_fix.py")], kind=SEM,
    attestation="外部核验/ingest_parse/semantica-attestation.yaml",
    produces=["外部核验/ingest_parse/tables.jsonl"]),
  S("统计", [SYS, str(KB/"stats.py")]),
]


def check_attestation(rel):
    p = PKG / rel
    if not p.exists():
        return False, "attestation 缺失: " + rel
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        return False, "attestation 无法解析: " + str(e)[:60]
    if d.get("status") != "pass":
        return False, "attestation 状态非 pass: " + str(d.get("status"))
    return True, "ok"


def check_produces(rels):
    missing = [r for r in rels if not (PKG / r).exists()]
    return (not missing), ("缺少产物: " + ", ".join(missing) if missing else "ok")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--from", dest="from_step", default=None)
    ap.add_argument("--only", default=None)
    a = ap.parse_args()

    steps = STEPS
    if a.from_step:
        names = [s["name"] for s in steps]
        if a.from_step in names:
            steps = steps[names.index(a.from_step):]
    if a.only:
        steps = [s for s in steps if a.only in s["name"]]

    if a.dry_run:
        for i, s in enumerate(steps, 1):
            print("  %2d. [%-9s] %s   %s" % (i, s["kind"], s["name"], s["note"]))
        print("  共 %d 步（其中 semantica 步骤 %d 步）"
              % (len(steps), sum(1 for s in steps if s["kind"] == SEM)))
        return 0

    att = {"title": "主链编排 attestation", "started": datetime.now().isoformat(timespec="seconds"),
           "package": str(PKG), "steps": [], "status": "running"}
    OUT.mkdir(parents=True, exist_ok=True)
    logf = OUT / "chain-run.log"
    t_all = time.time()
    with logf.open("a", encoding="utf-8") as log:
        log.write("\n===== 运行 %s =====\n" % att["started"])
        for i, s in enumerate(steps, 1):
            t0 = time.time()
            log.write("### [%d/%d] %s\n" % (i, len(steps), s["name"]))
            p = subprocess.run(s["cmd"], cwd=str(ROOT), capture_output=True, text=True)
            log.write((p.stdout or "")[-4000:] + (p.stderr or "")[-2000:] + "\n")
            rec = {"step": s["name"], "kind": s["kind"], "exit_code": p.returncode,
                   "elapsed_s": round(time.time() - t0, 1)}
            if p.returncode != 0:
                rec["status"] = "failed"
                rec["reason"] = "退出码 %d（无管道遮蔽）" % p.returncode
                att["steps"].append(rec); att["status"] = "failed"; att["failed_at"] = s["name"]
                break
            ok, msg = True, "ok"
            if s["attestation"]:
                ok, msg = check_attestation(s["attestation"])
                rec["attestation"] = s["attestation"]
            if ok and s["produces"]:
                ok, msg = check_produces(s["produces"])
            if not ok:
                rec["status"] = "violation"; rec["reason"] = msg
                att["steps"].append(rec); att["status"] = "failed"; att["failed_at"] = s["name"]
                break
            rec["status"] = "pass"
            att["steps"].append(rec)
            print("  [%2d/%d] %-26s pass  %5.1fs" % (i, len(steps), s["name"], rec["elapsed_s"]), flush=True)
        else:
            att["status"] = "pass"
    att["finished"] = datetime.now().isoformat(timespec="seconds")
    att["total_s"] = round(time.time() - t_all, 1)
    att["semantica_steps"] = sum(1 for s in att["steps"] if s["kind"] == SEM)
    (OUT / "chain-attestation.yaml").write_text(json.dumps(att, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"status": att["status"], "steps": len(att["steps"]),
                      "failed_at": att.get("failed_at"), "total_s": att["total_s"]}, ensure_ascii=False))
    return 0 if att["status"] == "pass" else 1


if __name__ == "__main__":
    sys.exit(main())
