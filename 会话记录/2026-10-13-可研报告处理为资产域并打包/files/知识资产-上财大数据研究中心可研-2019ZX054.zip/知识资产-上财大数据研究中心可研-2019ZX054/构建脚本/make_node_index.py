# -*- coding: utf-8 -*-
"""生成节点索引表（字典用法）：把 442 条事实节点做成可按 ID / 按事实名速查的索引。
产物：写作输入/节点索引表.md（人读）+ 写作输入/node-index.tsv（机器读，可直接 grep）
"""
import json, re
from pathlib import Path

BT = chr(96); F3 = BT * 3
def c(s): return BT + s + BT
WS = Path(__file__).resolve().parent.parent
PKG = WS / "知识资产-上财大数据研究中心可研"
OUT = PKG / "写作输入"
OUT.mkdir(parents=True, exist_ok=True)

chunks = [json.loads(l) for l in (PKG / "chunks/chunks.jsonl").read_text(encoding="utf-8").splitlines() if l]
nodes = json.loads((PKG / "graph/nodes.yaml").read_text(encoding="utf-8"))
node_index = json.loads((PKG / "index/node_index.json").read_text(encoding="utf-8"))

# ---- chunk -> 章节树（与 make_section_prompts.py 同一套逻辑） ----
head_re = re.compile(r'^(#{1,6})\s+(.+)$')
sections, stack, owner = [], [], {}
for ch in chunks:
    if ch["type"] == "heading":
        m = head_re.match(ch["text"].strip())
        if m:
            lvl, title = len(m.group(1)), m.group(2).strip()
            stack = [(l, t, i) for (l, t, i) in stack if l < lvl] + [(lvl, title, len(sections))]
            sections.append({"no": len(sections), "level": lvl, "title": title, "chunk": ch["id"],
                             "index": ch["index"], "path": " / ".join(t for _, t, _ in stack),
                             "parent": stack[-2][2] if len(stack) > 1 else None})
    owner[ch["id"]] = stack[-1][2] if stack else None

def top_of(si):
    cur = si
    while sections[cur].get("parent") is not None:
        cur = sections[cur]["parent"]
    return cur

def safe(t):
    return re.sub(r'[\\/:*?"<>|]', "／", t)[:40]

# 章文件命名与 make_section_prompts.py 保持一致
chap_file = {}
for s in sections:
    if s["level"] == 1:
        chap_file[s["no"]] = f'{s["no"] + 1:02d}-{safe(s["title"])}.md'

def chap_of_chunk(cid):
    si = owner.get(cid)
    if si is None: return "（正文前）"
    return chap_file.get(top_of(si), "（未定位）")

uses = {}
for e in (node_index if isinstance(node_index, list) else []):
    uses[e.get("node")] = uses.get(e.get("node"), 0) + 1

rows = []
for n in nodes:
    ch = chap_of_chunk(n.get("source", ""))
    si = owner.get(n.get("source", ""))
    rows.append({
        "node": n["id"], "subject": n["subject"], "value": n["value"], "unit": n.get("unit", ""),
        "time": n.get("time", ""), "caliber": n.get("caliber", ""),
        "chapter_file": ch, "section": sections[si]["path"] if si is not None else "（未定位）",
        "uses": uses.get(n["id"], 0),
    })
rows.sort(key=lambda r: r["node"])
by_subject = sorted(rows, key=lambda r: (r["subject"], r["node"]))

L = []; A = L.append
A("# 节点索引表（字典用法）")
A("")
A(f"共 {len(rows)} 条事实节点。**用法**：骨架 " + c("chunks/skeletons.jsonl") + " 里出现 " + c("{{node:N-xxx}}") + " 时，"
  "在 §1 按 ID 查到值，按 §2 的「所在章文件」去读上下文；或用 " + c("node-index.tsv") + " 直接 grep。")
A("")
A("| 索引 | 排序 | 用途 |")
A("| --- | --- | --- |")
A("| §1 节点ID索引 | 按节点ID | 看到占位符 → 查值（主用） |")
A("| §2 事实名索引 | 按事实名 | 知道要写什么 → 找节点ID |")
A("| " + c("node-index.tsv") + " | 按节点ID | 机器读 / 命令行 grep |")
A("")
A("> 与其它文件的关系：" + c("推演写作输入包.md") + " §2 是同一批节点**按章节分组**（写某一章时用）；"
  "本表是同一批节点**按ID/名称排序**（解析占位符时用）。二者同源，值以本表与节点表为准。")
A("")
A("## 1. 节点ID索引")
A("")
A("| 节点ID | 事实 | 值 | 单位 | 时点 | 口径 | 引用数 | 所在章文件 |")
A("| --- | --- | --- | --- | --- | --- | --- | --- |")
for r in rows:
    A(f'| {r["node"]} | {r["subject"]} | {r["value"]} | {r["unit"] or "—"} | {r["time"] or "—"} | '
      f'{r["caliber"] or "—"} | {r["uses"]} | {r["chapter_file"]} |')
A("")
A("## 2. 事实名索引")
A("")
A("| 事实 | 节点ID | 值 |")
A("| --- | --- | --- |")
for r in by_subject:
    A(f'| {r["subject"]} | {r["node"]} | {r["value"]}{(" " + r["unit"]) if r["unit"] else ""} |')
A("")
A("---")
A("")
A(f"（本表由 " + c("构建脚本/make_node_index.py") + " 生成；节点 {len(rows)} 条，"
  f"被骨架引用的 {sum(1 for r in rows if r['uses'] > 0)} 条。）")
(OUT / "节点索引表.md").write_text("\n".join(L), encoding="utf-8")

tsv = ["node_id\tsubject\tvalue\tunit\ttime\tcaliber\tsection\tchapter_file\tuses"]
for r in rows:
    tsv.append("\t".join([r["node"], r["subject"], str(r["value"]).replace("\t", " "), r["unit"], r["time"],
                          r["caliber"], r["section"], r["chapter_file"], str(r["uses"])]))
(OUT / "node-index.tsv").write_text("\n".join(tsv) + "\n", encoding="utf-8")

invp = PKG / "inventory.yaml"
iv = json.loads(invp.read_text(encoding="utf-8"))
for nm, desc in [("写作输入/节点索引表.md", "节点字典：按ID与事实名速查，含所在章文件"),
                 ("写作输入/node-index.tsv", "节点字典（TSV，可 grep）")]:
    if not any(e["name"] == nm for e in iv.get("extensions", [])):
        iv.setdefault("extensions", []).append({"name": nm, "desc": desc, "exists": True})
for e in iv["extensions"]:
    p = PKG / e["name"]
    e["exists"] = bool(list(p.parent.glob(p.name))) if "*" in e["name"] else p.exists()
iv["extensions_present"] = sum(1 for e in iv["extensions"] if e["exists"])
invp.write_text(json.dumps(iv, ensure_ascii=False, indent=2), encoding="utf-8")
chars = len("\n".join(L))
print(f"节点 {len(rows)} 条 | 索引表 {chars} 字 | TSV {len(tsv)-1} 行 | extensions {iv['extensions_present']}/{len(iv['extensions'])}")
