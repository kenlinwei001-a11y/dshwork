# -*- coding: utf-8 -*-
"""第 6 项 C2 修复：落盘 DocumentParser 的结构化表格（此前被丢弃）。

事实：DocumentParser 已返回 tables=[{rows:[[cell,...]],...}] × 31，我上一版只写了 full_text，
导致 31 个表格结构丢失（markdown 里 0 个 '|'）。本版补上，并量化合并单元格重复带来的结构失真。
"""
from __future__ import annotations
import json, os, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from semantica_env import load_env  # noqa: E402
load_env()
from semantica_workflow import run_workflow, Step, semantica_call, WorkflowViolation  # noqa: E402

PKG = Path(os.environ["KP_CORPUS_DIR"]) if os.environ.get("KP_CORPUS_DIR") else Path("/Users/apple/Desktop/知识资产-上财大数据研究中心可研-2019ZX054/语料包")
OUT = PKG / "外部核验" / "ingest_parse"
OUT.mkdir(parents=True, exist_ok=True)
DOCX = PKG / "source/original.docx"
BOX = {}


def _dedup_merged(rows):
    """把 python-docx 因横向/纵向合并而重复填充的单元格还原为空，得到更接近真实的表形。"""
    out, dup = [], 0
    for ri, row in enumerate(rows):
        nr = []
        for ci, cell in enumerate(row):
            c = (cell or "").strip()
            left = (row[ci - 1] if ci > 0 else "").strip() if isinstance(row[ci - 1] if ci > 0 else "", str) else ""
            up = ""
            if ri > 0 and ci < len(rows[ri - 1]):
                up = (rows[ri - 1][ci] or "").strip() if isinstance(rows[ri - 1][ci], str) else ""
            if c and (c == left or c == up):
                nr.append(""); dup += 1
            else:
                nr.append(cell)
        out.append(nr)
    return out, dup


def step_parse_full():
    from semantica.parse import DocumentParser
    p = DocumentParser()
    parsed = semantica_call("parse.DocumentParser.parse", lambda: p.parse(str(DOCX)))
    if not isinstance(parsed, dict):
        raise WorkflowViolation("DocumentParser 未返回字典")
    BOX["parsed"] = parsed
    text = parsed.get("full_text") or ""
    tables = parsed.get("tables") or []

    # 1) 结构化表格落盘（此前丢失）
    with (OUT / "tables.jsonl").open("w", encoding="utf-8") as fh:
        for i, t in enumerate(tables):
            fh.write(json.dumps({"index": i, "table": t}, ensure_ascii=False, default=str) + "\n")

    # 2) 去合并后渲染 markdown 表格
    md, total_dup, stats = [], 0, []
    for i, t in enumerate(tables):
        rows = t.get("rows") if isinstance(t, dict) else None
        if not rows:
            continue
        clean, dup = _dedup_merged(rows)
        total_dup += dup
        stats.append({"index": i, "rows": len(rows), "cols": max(len(r) for r in rows), "dup_cells": dup})
        md.append("\n### 表 %d（%d行 × %d列，去合并后）\n" % (i, len(rows), max(len(r) for r in rows)))
        for r in clean:
            md.append("| " + " | ".join((c or "").replace("\n", " ").replace("|", "／") for c in r) + " |")
        md.append("")
    (OUT / "tables-by-semantica.md").write_text("\n".join(md), encoding="utf-8")
    (OUT / "parsed-by-semantica.md").write_text(text, encoding="utf-8")

    cel = sum(s["rows"] * s["cols"] for s in stats)
    (OUT / "parse-meta.yaml").write_text(json.dumps({
        "engine": "semantica.parse.DocumentParser",
        "source": str(DOCX), "source_bytes": DOCX.stat().st_size,
        "chars": len(text), "tables_parsed": len(tables),
        "cells_total": cel, "cells_merged_duplicated": total_dup,
        "merged_dup_ratio": round(total_dup / cel, 3) if cel else 0,
        "largest_tables": sorted(stats, key=lambda x: -x["rows"] * x["cols"])[:5],
        "note": "合并单元格被 python-docx 重复填充；已按左/上邻去重渲染，但 colspan/rowspan 的真实跨度无法还原",
    }, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return len(tables)


def main():
    att = run_workflow([
        Step("C2' 解析并落盘表格结构", ["parse.DocumentParser.parse"], step_parse_full,
             note="补齐上一版丢弃的 31 个结构化表格"),
    ], OUT, title="Semantica 解析落盘修复（第 6 项 C2）")
    print(json.dumps({"status": att["status"], "tables": BOX["parsed"].get("total_tables")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
