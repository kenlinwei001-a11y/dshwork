# -*- coding: utf-8 -*-
"""第 4 项：向量化与向量库 —— 全部走 Semantica（embeddings + vector_store），门禁 fail-closed。"""
from __future__ import annotations
import json, os, sys, time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from semantica_env import load_env  # noqa: E402
load_env()
from semantica_workflow import run_workflow, Step, semantica_call, WorkflowViolation  # noqa: E402

PKG = Path(os.environ["KP_CORPUS_DIR"]) if os.environ.get("KP_CORPUS_DIR") else Path("/Users/apple/Desktop/知识资产-上财大数据研究中心可研-2019ZX054/语料包")
OUT = PKG / "外部核验" / "vector"
OUT.mkdir(parents=True, exist_ok=True)
BOX = {}

chunks = [json.loads(l) for l in (PKG / "chunks/chunks.jsonl").read_text(encoding="utf-8").splitlines() if l]
texts = [c["text"][:500] for c in chunks]


def step_embed():
    from semantica.embeddings import EmbeddingGenerator
    g = EmbeddingGenerator()
    # 关键：Semantica 默认是【英文】模型 BAAI/bge-small-en-v1.5(384维)，中文语料必须显式换中文模型
    MODEL = os.environ.get("SEMANTICA_EMBED_MODEL", "BAAI/bge-small-zh-v1.5")
    semantica_call("embeddings.EmbeddingGenerator.set_text_model",
                   lambda: g.set_text_model("fastembed", MODEL))
    BOX["model"] = MODEL
    vecs = None
    last = None
    for call in (lambda: g.generate_embeddings(texts),
                 lambda: g.generate_embeddings(texts=texts),
                 lambda: g.process_batch(texts)):
        try:
            vecs = semantica_call("embeddings.EmbeddingGenerator.generate_embeddings", call)
            break
        except Exception as e:
            last = e
            continue
    if vecs is None:
        raise WorkflowViolation("EmbeddingGenerator 无可用入口：%s" % str(last)[:80])
    arr = vecs.get("embeddings") if isinstance(vecs, dict) else vecs
    if hasattr(arr, "tolist"):
        arr = arr.tolist()
    BOX["vectors"] = arr
    dim = len(arr[0]) if arr else 0
    BOX["dim"] = dim
    (OUT / "embedding-meta.json").write_text(json.dumps(
        {"engine": "semantica.embeddings.EmbeddingGenerator", "method": "fastembed",
         "model": BOX.get("model"), "count": len(arr or []), "dim": dim},
        ensure_ascii=False, indent=2), encoding="utf-8")
    return len(arr or [])


def step_store():
    from semantica.vector_store import FAISSStore
    dim = BOX.get("dim") or 0
    if not dim:
        raise WorkflowViolation("向量维度为 0，无法建库")
    st = FAISSStore(dimension=dim)
    semantica_call("vector_store.FAISSStore.add_vectors",
                   lambda: st.add_vectors(BOX["vectors"], metadata=[{"chunk": c["id"]} for c in chunks]))
    idx = OUT / "faiss.index"
    for m in ("save_index", "save"):
        fn = getattr(st, m, None)
        if fn:
            try:
                semantica_call("vector_store.FAISSStore." + m, lambda: fn(str(idx)))
                BOX["saved"] = m
                break
            except TypeError:
                continue
    BOX["store"] = st
    return len(BOX["vectors"])


def step_search():
    """检索验证：FAISSStore 要的是向量，不是字符串（曾据 TypeError 误降级）。"""
    st = BOX["store"]
    import numpy as _np
    qv = _np.asarray(BOX["vectors"][0], dtype="float32")  # 签名要求 ndarray，list 会因无 .ndim 报错
    res, used = None, None
    for m, arg in (("search_similar", qv), ("search", qv), ("search", texts[0][:200])):
        fn = getattr(st, m, None)
        if not fn:
            continue
        try:
            res = semantica_call("vector_store.FAISSStore." + m, lambda: fn(arg, k=3))
            used = m
            break
        except Exception:
            continue
    if res is None:
        raise WorkflowViolation("FAISSStore 无可用检索入口（search_similar/search 均失败）——不得跳过")
    (OUT / "search-sample.json").write_text(json.dumps(
        {"method": used, "query_chunk": chunks[0]["id"], "result": str(res)[:800]},
        ensure_ascii=False, indent=2), encoding="utf-8")
    BOX["search_method"] = used
    return len(res) if hasattr(res, "__len__") else 1


def main():
    steps = [
        Step("1 向量化", ["embeddings.EmbeddingGenerator.generate_embeddings"], step_embed,
             note="1208 chunk -> Semantica 向量（非 kp fastembed）"),
        Step("2 建库", ["vector_store.FAISSStore.add_vectors"], step_store, note="FAISS 本地索引"),
        Step("3 检索验证", ["vector_store.FAISSStore.search_similar", "vector_store.FAISSStore.search"],
             step_search, mode="any", note="多签名择一（曾误按全必调判违规）"),
    ]
    att = run_workflow(steps, OUT, title="Semantica 向量化 + 向量库（第 4 项）")
    print(json.dumps({"status": att["status"], "dim": BOX.get("dim"),
                      "steps": [(s["step"], s["status"]) for s in att["steps"]]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
