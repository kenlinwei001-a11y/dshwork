
import json, re
from pathlib import Path
H = json.loads(Path("input/_headings.json").read_text(encoding="utf-8"))
lines = Path("input/大数据研究中心可研.raw.txt").read_text(encoding="utf-8").split("\n")
errs = [{"line": ln, "want": t, "got": lines[ln].strip()} for ln, lvl, t in H if lines[ln].strip() != t]
assert not errs, errs
hmap = {ln: (lvl, t) for ln, lvl, t in H}
hmap.pop(0, None); hmap[30] = (1, "目录")
NUMH = re.compile(r'^(\d+(?:\.\d+)*)\s*[、.．]\s*(.+)$')
BAD = "。；：，！？、"
res, converted = [], 0
for i, l in enumerate(lines):
    if i == 0:
        res.append("# 封面与编制信息"); res.append(l); continue
    if i in hmap:
        res.append("#" * hmap[i][0] + " " + hmap[i][1]); continue
    s = l.strip()
    m = NUMH.match(s)
    if m and (len(m.group(2)) > 14 or any(ch in m.group(2) for ch in BAD)):
        res.append("- " + s); converted += 1; continue
    res.append(l)
text = "\n".join(res)
A = Path("input/appendix_a.md").read_text(encoding="utf-8")
B = Path("input/appendix_b.md").read_text(encoding="utf-8")
text = text + "\n\n" + A + "\n\n" + B
Path("input/大数据研究中心可研.md").write_text(text, encoding="utf-8")
print(f"列表项归一化 {converted} 行; 附录A {len(A)} + 附录B {len(B)} 字符; 合计 {len(text)}")
