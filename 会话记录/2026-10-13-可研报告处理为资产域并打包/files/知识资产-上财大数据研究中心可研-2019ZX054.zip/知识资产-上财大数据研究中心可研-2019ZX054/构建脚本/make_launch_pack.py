# -*- coding: utf-8 -*-
"""生成《写作会话启动包》：提示词 + 装配指引 + 逐节索引 + 节点字典，合成一份自足文件。"""
import json
from pathlib import Path
from datetime import date

BT = chr(96); F3 = BT * 3
WS = Path(__file__).resolve().parent.parent
PKG = WS / "知识资产-上财大数据研究中心可研"
OUT = PKG / "写作输入"
DESK = Path("/Users/apple/Desktop/知识资产-上财大数据研究中心可研-2019ZX054")
ASSET = str(DESK) if DESK.exists() else str(PKG.parent / "知识资产-上财大数据研究中心可研-2019ZX054")
CORPUS = ASSET + "/语料包"

meta = json.loads((PKG / "meta.yaml").read_text(encoding="utf-8"))
cw = json.loads((PKG / "dependencies.yaml").read_text(encoding="utf-8"))
conf = json.loads((PKG / "quality/conflicts.yaml").read_text(encoding="utf-8"))
gaps = json.loads((PKG / "quality/gaps.yaml").read_text(encoding="utf-8"))["gaps"]
handoff = (OUT / "00-移交说明-给推演写作专家.md").read_text(encoding="utf-8")
idx = (OUT / "章节提示词索引.md").read_text(encoding="utf-8")
nodes = (OUT / "节点索引表.md").read_text(encoding="utf-8")

PROMPT = f"""【角色】
你是「推演写作专家」。任务：基于一套已抽取好的知识资产，还原撰写
《上海财经大学中山北一路校区大数据研究中心可行性研究报告（修订）》。

【固定资产地址（只读，已就位）】
ASSET      = {ASSET}
CORPUS_DIR = {CORPUS}

【第一步 自检，把每步实际输出贴出来】
1) ls "$ASSET"                 # 应看到 语料包/ 复核/ 依据来源/ 构建脚本/ README.md
2) ls "$CORPUS_DIR"            # 应看到 chunks/ graph/ quality/ 写作输入/ 等
3) ls "$CORPUS_DIR/写作输入"    # 应看到 00-移交说明… / 节点索引表.md / 章节提示词索引.md / 章节提示词/
任一步失败就停下，把报错原样贴回来，不要猜路径、不要编数据。

【第二步 建写作项目目录（必须在你自己的工作区内；沙箱写权限只覆盖那里）】
mkdir -p ./writing-project
PROJECT_DIR = <用 pwd 得到的绝对路径>/writing-project

【第三步 取事实值，并回报】
执行并贴出结果：
  grep -c "^| N-" "$CORPUS_DIR/写作输入/节点索引表.md"      # 应为 442
回报「已读事实节点 ___ 条」并抽查 3 条（节点ID + 事实 + 值）。

【MCP 调用约定】所有含目录参数的工具一律带：
  corpus_dir  = {CORPUS}
  project_dir = <你的工作区>/writing-project
可用（kp-processing 组，均需 corpus_dir）：graph_query / graph_get_node / graph_explain /
  graph_why / graph_impact / evidence_get / gate_check / corpus_where_used /
  corpus_get_chunk / corpus_get_skeleton / corpus_search
注意：
  - corpus_get_chunk(只传 limit) 与 corpus_get_skeleton 的修复需重启 DSH Host 后生效；
    未生效就按本包 §1 的文件通道直接读文件，不要卡住。
  - 若 kp-assembly 组（wp_get_facts / build_work_package / gate_check_draft）不可用，
    直接取 $CORPUS_DIR/写作输入/章节提示词/<NN>-<章>.md 的对应节当工作包用。

【写作纪律·硬约束】
1) 形取 $CORPUS_DIR/chunks/skeletons.jsonl（数值已占位）；
   值取本包 §3 节点字典（或 $CORPUS_DIR/写作输入/节点索引表.md）；
   律取 graph/ + reasoning/derivation.yaml + dependencies.yaml。
2) 禁读 $CORPUS_DIR/chunks/chunks.jsonl 与 $CORPUS_DIR/source/（含原文数值）。
3) 正文里每个数值一律写成〔节点ID〕，不得写字面量；写不出节点ID 说明你还没取到值，先停下读 §3。
4) {len(conf)} 项冲突一律「待审」并在对应章节显式呈现（清单见本包 §2 与 §1），不裁决、不改数字、不补口径。
5) {len(gaps)} 项缺口不得填 0、不得估值；{cw['summary']['pending']} 条「待核」规范条款不得写「符合规范」。
6) 不得编造；资产未给出的量保持未知。

【首个交付】
按还原目标 A（原报告 16 章结构），先写第 1 章《总论》，覆盖
$CORPUS_DIR/写作输入/章节提示词/02-总论.md 里的全部节，交付：
  draft_md / node_mentions / new_claims / unresolved
"""

L = []; A = L.append
A("# 写作会话启动包 · 推演写作专家")
A("")
A(f"> 语料 {meta['doc_id']} ｜ 事实 442 条 ｜ 技术函数 31 条 ｜ 规范依赖 {cw['summary']['total']} 条 ｜ "
  f"待审冲突 {len(conf)} 项 ｜ 缺口 {len(gaps)} 项 ｜ 生成日期 {date.today().isoformat()}")
A("")
A("本文件**自足**：把 §0 整段贴进写作会话，或直接让它读本文件，即完成全部输入。")
A("")
A("| 章节 | 内容 | 是否自足 |")
A("| --- | --- | --- |")
A("| §0 | **提示词**（首条消息，直接复制） | 是 |")
A("| §1 | 装配指引（通道、工具到文件映射、每节 8 步、硬禁令、返回契约） | 是 |")
A("| §2 | 逐节索引（144 节 / 19 章文件，含各节事实数、冲突数、缺口数） | 是 |")
A("| §3 | **节点字典**（442 条按 ID 查值 ＋ 按事实名查 ID） | 是（值全部在内） |")
A("")
A("唯一需要读盘的是「形」——句式骨架在 @@chunks/skeletons.jsonl@@；其余（值、结构、规则、冲突、缺口）本文件已全部包含。")
A("")
A("---")
A("")
A("## §0 提示词（首条消息，直接复制以下整段）")
A("")
A(F3 + "text")
A(PROMPT.rstrip())
A(F3)
A("")
A("---")
A("")
A("## §1 装配指引")
A("")
A("> 以下为 @@写作输入/00-移交说明-给推演写作专家.md@@ 全文。")
A("")
A((handoff.split("\n", 1)[1] if handoff.startswith("# ") else handoff).strip())
A("")
A("---")
A("")
A("## §2 逐节索引")
A("")
A((idx.split("\n", 1)[1] if idx.startswith("# ") else idx).strip())
A("")
A("---")
A("")
A("## §3 节点字典")
A("")
A((nodes.split("\n", 1)[1] if nodes.startswith("# ") else nodes).strip())
A("")
A("---")
A("")
A("## 附：按需读盘的文件（可选，用于提升质量）")
A("")
A("| 用途 | 路径（相对 CORPUS_DIR） | 说明 |")
A("| --- | --- | --- |")
A("| 借形（句式骨架） | @@chunks/skeletons.jsonl@@ | 1208 条，数值已占位；写作质量关键 |")
A("| 逐节工作包 | @@写作输入/章节提示词/<NN>-<章>.md@@ | 中位 5.5k 字/章，含该节事实表与骨架 chunk 指针 |")
A("| 按章节分组的同一批值 | @@写作输入/推演写作输入包.md@@ | §2 与 §3 同源的另一种排法；写整章时更顺 |")
A("| 技术函数叙述句 | @@reasoning/derivation.yaml@@ | 「经测算」句的唯一来源，直接引用 |")
A("| 规范依赖 | @@dependencies.yaml@@ / @@dependencies.md@@ | 25 条，已核 10 / 待核 15 |")
A("| 证据与摘录 | @@evidence/evidence.yaml@@ ＋ @@evidence/excerpts/@@ | 458 条 |")
A("| 条文与来源 | @@依据来源/@@（资产根目录下） | 外部核查原始网页摘录 |")
A("| 外部核验（Semantica） | @@外部核验/SEMANTICA-INTEGRATION.md@@ | 跨引擎冲突互证、7 组待办主体合并、PROV-O 溯源；**仅供复核，不得据此改值** |")
A("")

text = "\n".join(L).replace("@@", BT)
(OUT / "写作会话启动包.md").write_text(text, encoding="utf-8")

invp = PKG / "inventory.yaml"
iv = json.loads(invp.read_text(encoding="utf-8"))
if not any(e["name"] == "写作输入/写作会话启动包.md" for e in iv.get("extensions", [])):
    iv.setdefault("extensions", []).append({"name": "写作输入/写作会话启动包.md",
        "desc": "自足启动包：提示词 + 装配指引 + 逐节索引 + 节点字典，一次投喂即完成全部输入", "exists": True})
for e in iv["extensions"]:
    p = PKG / e["name"]
    e["exists"] = bool(list(p.parent.glob(p.name))) if "*" in e["name"] else p.exists()
iv["extensions_present"] = sum(1 for e in iv["extensions"] if e["exists"])
invp.write_text(json.dumps(iv, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"启动包 {len(text)} 字 | extensions {iv['extensions_present']}/{len(iv['extensions'])}")
print("ASSET =", ASSET)
