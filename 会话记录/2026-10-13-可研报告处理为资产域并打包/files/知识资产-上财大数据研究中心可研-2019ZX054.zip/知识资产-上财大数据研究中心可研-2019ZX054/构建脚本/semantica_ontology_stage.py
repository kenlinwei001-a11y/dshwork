# -*- coding: utf-8 -*-
"""第 1、2 项：本体图谱 + 图构建与存储 —— 全部经 Semantica 官方模块，门禁 fail-closed。

产出（<corpus>/外部核验/ontology/）：
  ontology.ttl         OWL 本体（OntologyGenerator + OWLGenerator）
  shapes.ttl           SHACL 约束（SHACLGenerator）
  validation.yaml      本体校验（OntologyValidator）
  kg-graph.json        图构建结果（kg.GraphBuilder + GraphAnalyzer）
  rdfstore/            本地三元组库（triplet_store.OxigraphStore）
  export/              RDF 导出（export.RDFExporter）
"""
from __future__ import annotations
import json, os, sys, time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from semantica_env import load_env  # noqa: E402
load_env()

from semantica_workflow import run_workflow, Step, semantica_call, WorkflowViolation  # noqa: E402

PKG = Path(os.environ["KP_CORPUS_DIR"]) if os.environ.get("KP_CORPUS_DIR") else Path("/Users/apple/Desktop/知识资产-上财大数据研究中心可研-2019ZX054/语料包")
OUT = PKG / "外部核验" / "ontology"
OUT.mkdir(parents=True, exist_ok=True)
BOX = {}

nodes = json.loads((PKG / "graph/nodes.yaml").read_text(encoding="utf-8"))
rels = json.loads((PKG / "graph/relations.yaml").read_text(encoding="utf-8"))


def build_inputs():
    """把我方事实/关系转成 Semantica 图输入（纯数据，不含判定）。"""
    ents, seen = [], set()
    for n in nodes:
        for eid, etype, label in ((n["id"], n.get("kind") or "Fact", n["subject"]),
                                  (n["subject"], "Concept", n["subject"])):
            if eid in seen:
                continue
            seen.add(eid)
            ents.append({"id": eid, "type": etype, "name": label,
                         "properties": {"subject": n["subject"], "value": str(n["value"]),
                                        "unit": n.get("unit", ""), "source": n.get("source", "")}})
    rls = [{"source": r["from"], "target": r["to"], "type": r.get("type", "related_to")} for r in rels]
    return {"entities": ents, "relationships": rls}


# ---- 步骤 1：图构建（kg.GraphBuilder） ----
def step_build_graph():
    from semantica.kg import GraphBuilder
    data = build_inputs()
    BOX["input"] = data
    g = semantica_call("kg.GraphBuilder.build", lambda: GraphBuilder(merge_entities=True).build(data))
    BOX["kg"] = g
    n = len(g.get("entities", g.get("nodes", []))) if isinstance(g, dict) else 0
    (OUT / "kg-graph.json").write_text(json.dumps(g, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return n or len(data["entities"])


# ---- 步骤 2：本体生成（ontology.OntologyGenerator） ----
def step_ontology():
    from semantica.ontology import OntologyGenerator
    o = semantica_call("ontology.OntologyGenerator.generate_from_graph",
                       lambda: OntologyGenerator().generate_from_graph(BOX["kg"]))
    BOX["onto"] = o
    return len(o.get("classes", [])) + len(o.get("properties", [])) if isinstance(o, dict) else 0


# ---- 步骤 3：SHACL 形状（ontology.SHACLGenerator） ----
def step_shacl():
    from semantica.ontology import SHACLGenerator
    gen = SHACLGenerator(base_uri="https://shufe.example.org/corpus/shapes/")
    sh = semantica_call("ontology.SHACLGenerator.generate", lambda: gen.generate(BOX["onto"]))
    txt = semantica_call("ontology.SHACLGenerator.serialize", lambda: gen.serialize(sh, format="turtle"))
    (OUT / "shapes.ttl").write_text(txt or "", encoding="utf-8")
    BOX["shacl"] = txt
    return len(sh.node_shapes) if hasattr(sh, "node_shapes") else (1 if txt else 0)


# ---- 步骤 4：OWL 导出（ontology.OWLGenerator） ----
def step_owl():
    from semantica.ontology import OWLGenerator
    gen = OWLGenerator()
    p = OUT / "ontology.ttl"
    semantica_call("ontology.OWLGenerator.export_owl", lambda: gen.export_owl(BOX["onto"], p))
    BOX["owl_path"] = p
    return p.stat().st_size


# ---- 步骤 5：本体校验（ontology.OntologyValidator） ----
def step_validate():
    from semantica.ontology import OntologyValidator
    v = semantica_call("ontology.OntologyValidator.validate",
                       lambda: OntologyValidator(check_consistency=True).validate(BOX["onto"]))
    d = {k: getattr(v, k, None) for k in ("valid", "consistent", "satisfiable")} if v is not None else {}
    if not d:
        d = {"raw": str(v)}
    (OUT / "validation.yaml").write_text(json.dumps(d, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return len(json.dumps(d))


# ---- 步骤 6：三元组入库（triplet_store.OxigraphStore） ----
def step_store():
    from semantica.triplet_store import OxigraphStore
    from semantica.semantic_extract.types import Triplet
    store = OxigraphStore(path=str(OUT / "rdfstore"))
    # Oxigraph 要求 subject/predicate 为绝对 IRI；object 可为字面量
    from urllib.parse import quote
    BASE = "https://shufe.example.org/corpus/"
    def iri_ent(x): return BASE + "e/" + quote(str(x), safe="")
    def iri_prop(x): return BASE + "p/" + quote(str(x), safe="")
    trips = [Triplet(subject=iri_ent(n["subject"]), predicate=iri_prop(n.get("predicate") or "has_value"),
                     object=str(n["value"]), confidence=1.0,
                     metadata={"node_id": n["id"], "unit": n.get("unit", "")}) for n in nodes]
    # 语义关系也入库（不只 has_value）
    for r in rels:
        if r.get("type") == "has_value":
            continue
        trips.append(Triplet(subject=iri_ent(r["from"]), predicate=iri_prop(r.get("type", "related_to")),
                             object=iri_ent(r["to"]), confidence=1.0, metadata={"relation": True}))
    r = semantica_call("triplet_store.OxigraphStore.add_triplets",
                       lambda: store.add_triplets(trips))
    semantica_call("triplet_store.OxigraphStore.flush", store.flush)
    BOX["triplets"] = len(trips)
    return len(trips)


# ---- 步骤 7：RDF 导出（export.RDFExporter） ----
def step_export():
    import semantica.export as EX
    ex = EX.RDFExporter()
    tgt = OUT / "export"
    tgt.mkdir(exist_ok=True)
    ttl = tgt / "kg-graph.ttl"
    semantica_call("export.RDFExporter.export_knowledge_graph",
                   lambda: ex.export_knowledge_graph(BOX["kg"], ttl, format="turtle"))
    jsonld = semantica_call("export.RDFExporter.export_to_rdf",
                            lambda: ex.export_to_rdf(BOX["kg"], format="json-ld"))
    (tgt / "kg-graph.jsonld").write_text(jsonld or "", encoding="utf-8")
    # 本体 + SHACL 也一并导出（同一导出器）
    if BOX.get("owl_path") and BOX["owl_path"].exists():
        semantica_call("export.RDFExporter.export_shacl",
                       lambda: ex.export_shacl(BOX.get("shacl") or "", tgt / "shapes.ttl"))
    BOX["export_dir"] = str(tgt)
    return len(list(tgt.glob("*")))


def main():
    steps = [
        Step("1 图构建", ["kg.GraphBuilder.build"], step_build_graph, note="442 事实 + 514 关系 -> Semantica 图"),
        Step("2 本体生成", ["ontology.OntologyGenerator.generate_from_graph"], step_ontology, note="从图推导 OWL 类/属性"),
        Step("3 SHACL 形状", ["ontology.SHACLGenerator.generate", "ontology.SHACLGenerator.serialize"], step_shacl),
        Step("4 OWL 导出", ["ontology.OWLGenerator.export_owl"], step_owl),
        Step("5 本体校验", ["ontology.OntologyValidator.validate"], step_validate),
        Step("6 三元组入库", ["triplet_store.OxigraphStore.add_triplets"], step_store, note="本地 Oxigraph"),
        Step("7 RDF 导出", ["export.RDFExporter.export_knowledge_graph", "export.RDFExporter.export_to_rdf"], step_export, note="Turtle + JSON-LD + SHACL"),
    ]
    att = run_workflow(steps, OUT, title="Semantica 本体图谱 + 图构建（第 1、2、5 项）")
    print(json.dumps({"status": att["status"], "steps": [(s["step"], s["status"]) for s in att["steps"]]},
                     ensure_ascii=False))


if __name__ == "__main__":
    main()
