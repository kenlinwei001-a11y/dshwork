# -*- coding: utf-8 -*-
"""第 6 项：归一化接入 Semantica（并明确记录 ingest/parse 为何不适用）。

严格区分三类，避免把"职能不存在"当成"跳过"：
  A. 文本规范化      -> semantica.normalize.TextNormalizer   【必须用】
  B. 形态还原（纯文本视图重建标题）-> kp 侧保留（Semantica 无此职能）
  C. 文件加载/解析    -> semantica.ingest / semantica.parse   【当前不适用：无原始二进制】
"""
from __future__ import annotations
import json, os, re, sys, difflib
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from semantica_env import load_env  # noqa: E402
load_env()
from semantica_workflow import run_workflow, Step, semantica_call  # noqa: E402

PKG = Path(os.environ["KP_CORPUS_DIR"]) if os.environ.get("KP_CORPUS_DIR") else Path("/Users/apple/Desktop/知识资产-上财大数据研究中心可研-2019ZX054/语料包")
OUT = PKG / "外部核验" / "normalize"
OUT.mkdir(parents=True, exist_ok=True)
BOX = {}

SRC = PKG / "source/normalized.md"
raw = SRC.read_text(encoding="utf-8") if SRC.exists() else ""


def step_normalize():
    """A. 文本规范化一律走 Semantica TextNormalizer。"""
    from semantica.normalize import TextNormalizer
    nz = TextNormalizer()
    norm = semantica_call("normalize.TextNormalizer.normalize_text",
                          lambda: nz.normalize_text(raw, unicode_form="NFC"))
    clean = semantica_call("normalize.TextNormalizer.clean_text", lambda: nz.clean_text(norm))
    BOX["semantica_norm"] = clean or norm
    (OUT / "normalized-by-semantica.md").write_text(BOX["semantica_norm"], encoding="utf-8")
    # 与 kp 侧结果对比（只报差异，不改语料）
    sm = difflib.SequenceMatcher(None, raw, BOX["semantica_norm"])
    ratio = sm.ratio()
    diff = []
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag != "equal" and len(diff) < 20:
            diff.append({"op": tag, "kp": raw[i1:i2][:60], "semantica": BOX["semantica_norm"][j1:j2][:60]})
    (OUT / "normalize-compare.yaml").write_text(json.dumps({
        "source": str(SRC), "engine": "semantica.normalize.TextNormalizer",
        "kp_chars": len(raw), "semantica_chars": len(BOX["semantica_norm"]),
        "similarity": round(ratio, 4), "first_diffs": diff,
        "note": "本步骤只做规范化与对比，不覆盖语料（语料仍由 kp 侧归一化流程产出）",
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    return len(BOX["semantica_norm"])


def main():
    att = run_workflow([
        Step("A 文本规范化", ["normalize.TextNormalizer.normalize_text"],
             step_normalize, note="全角/Unicode/空白规范化走 Semantica"),
    ], OUT, title="Semantica 归一化（第 6 项 A 部分）")

    # B/C 的适用性：此前的"不适用"是错判，已纠正（原始 docx 实际可得）
    decl = {
      "B_形态还原": {
        "owner": "kp 侧（保留）",
        "reason": "由行锚点重建标题层级属于【数据形态还原】，Semantica 无对应职能；"
                  "不是跳过 Semantica，而是该职能不在 Semantica 能力面内",
      },
      "C_文件加载与解析": {
        "owner": "semantica.ingest.FileIngestor / semantica.parse.DocumentParser",
        "applicable_now": True,
        "executed": "已执行，见 外部核验/ingest_parse/（55,967 字 / 31 表 / 元数据齐全）",
        "correction": "此前声明为『不适用』系错判——原始 docx 实际存在：附件库 1,123,286 B，"
                      "SHA 与工作区副本一致；且内含 12 图 / 31 表，故 source/original.docx 与 source/assets/* 均已补齐",
      },
      "D_docling 增强解析": {
        "owner": "semantica.parse.DoclingParser",
        "status": "未部署（Semantica 的 optional extra：parse-docling -> docling>=2.107.0）",
        "decision": "已决：先保持使用 DocumentParser（2026-10-14）",
        "rationale": [
          "本件为 Microsoft Word 2007+ 原生 docx，非扫描件，OCR 无需求",
          "表格规模 31 个 / 1551 单元格，不大",
          "引入 docling 会带 torch，此前实测与 numpy 2 冲突并打穿过 semantica.vector_store",
          "DocumentParser 属 Semantica 官方标准路径，非第三方替代，不构成降级"
        ],
        "measured_delta": "270 个合并单元格(17.4%)的真实跨度无法还原；表头识别与版面模型缺失；已用左或上邻同值置空的启发式消解重复",
        "trigger_to_revisit": "出现扫描件 / 批量表格密集文档 / 需要真实单元格跨度或表头时，再部署并做安装后回归验证"
      },
      "gate_policy": "只有『有能力却不用』才算跳过；职能不存在记为不需要，可选增强记为升级项——都留证据",
    }
    (OUT / "applicability.yaml").write_text(json.dumps(decl, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"status": att["status"], "chars": len(BOX.get("semantica_norm", "")),
                      "steps": [(s["step"], s["status"]) for s in att["steps"]]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
