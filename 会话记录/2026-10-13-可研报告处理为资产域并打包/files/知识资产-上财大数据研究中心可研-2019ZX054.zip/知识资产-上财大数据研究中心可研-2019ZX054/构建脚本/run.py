# -*- coding: utf-8 -*-
"""上财大数据研究中心可研报告 → 可复用知识资产（七道工序）确定性驱动。
确定性层：chunk 解析、schema 校验、图谱回跑、脱敏重映射、质量登记、索引与审计。
语义层：sem_a / sem_b / sem_c 的 LLM 结构化抽取产物。
"""
import json, re, sys, hashlib
from pathlib import Path
from collections import defaultdict

sys.path.insert(0, "/Users/apple/Desktop/workdsh/knowledge/knowledge-processing-expert")
sys.path.insert(0, str(Path(__file__).parent))
import corpus_pipeline.full_emit as FE
from corpus_pipeline import run_pipeline, stable_id as _stable_id
from corpus_pipeline.ontology import validate_extraction, _fact_id
from kp_toolkit import validate_graph, detect_numeric_conflicts, detect_time_conflicts

from sem_a import ENTRIES_A, F
from sem_b import ENTRIES_B
from sem_c import ENTRIES_C
from sem_d import ENTRIES_D

WS = Path(__file__).resolve().parent.parent
PKG = WS / "知识资产-上财大数据研究中心可研"
RAW = (WS / "input/大数据研究中心可研.md").read_text(encoding="utf-8")

LEGAL = ["总论", "项目建设背景及必要性", "项目建设内容及规模", "项目选址及建设条件", "项目规划设计方案",
         "节能设计", "环境影响评价", "卫生防疫与劳动安全", "社会稳定风险分析", "项目管理及实施进度",
         "项目招投标方案", "投资估算及资金筹措", "社会效益", "结论与建议"]

LEGAL_304 = ["一、概述", "二、项目建设背景和必要性", "三、项目需求分析与产出方案", "四、项目选址与要素保障",
             "五、项目建设方案", "六、项目运营方案", "七、项目投融资与财务方案", "八、项目影响效果分析",
             "九、项目风险管控方案", "十、研究结论及建议"]
LEGAL_304_MAP = {
    "一、概述": ["总论（项目概况 / 研究内容和编制依据 / 技术经济指标 / 结论及建议）"],
    "二、项目建设背景和必要性": ["项目建设背景及必要性分析"],
    "三、项目需求分析与产出方案": ["项目建设内容及规模（各研究中心规划人数、公共服务配套用房、规模分析小结）"],
    "四、项目选址与要素保障": ["项目选址及建设条件"],
    "五、项目建设方案": ["项目规划设计方案", "节能设计", "环境影响评价", "卫生防疫与劳动安全"],
    "六、项目运营方案": [],
    "七、项目投融资与财务方案": ["投资估算及资金筹措（仅投资估算与资金筹措，未含财务分析与融资方案比选）"],
    "八、项目影响效果分析": ["社会效益（仅社会效益，未含经济影响、生态环境影响分析与效果评价）"],
    "九、项目风险管控方案": ["社会稳定风险分析（仅社会稳定风险，未含全面风险识别与管控方案）"],
    "十、研究结论及建议": ["结论与建议"],
}

# 追加：资金筹措章正文字面 18219，用于让工序5 回放自动检出建筑面积口径冲突
EXTRA = [{"match": "拟建“中山北一路校区大数据研究中心”，将对学校原第五教学楼进行拆除",
          "facts": [F("新建总建筑面积", "18219", "平方米", caliber="资金筹措章正文")]}]

ENTRIES = ENTRIES_A + ENTRIES_B + ENTRIES_C + ENTRIES_D + EXTRA

# 工序7 占位符扫描：兼容全角句点
_NUM = re.compile(r'[-+]?\d[\d,]*(?:[.．]\d+)?%?')

def _norm(v):
    return str(v).replace(",", "").replace("．", ".").strip()

# ============================== 语义层装配 ============================== #
chunks_path = PKG / "chunks/chunks.jsonl"
if not chunks_path.exists():
    raise SystemExit("请先运行工序1-3 生成 chunks.jsonl")
PRE = [json.loads(l) for l in chunks_path.read_text(encoding="utf-8").splitlines() if l]
by_id = {c["id"]: c for c in PRE}

resolved, problems = [], []
for e in ENTRIES:
    hits = [c for c in PRE if e["match"] in c["text"]]
    nth = e.get("nth", 0)
    if len(hits) <= nth:
        problems.append({"match": e["match"][:40], "err": f"匹配 {len(hits)} 处 < nth={nth}"})
        continue
    c = sorted(hits, key=lambda x: x["index"])[nth]
    resolved.append((e, c))
if problems:
    print("MATCH ERRORS:", json.dumps(problems, ensure_ascii=False, indent=2)); sys.exit(1)

# 事实 id 由 (subject|predicate|value|time) 确定性生成，先建查询表
fact_lookup, subject_lookup = {}, defaultdict(list)
for e, c in resolved:
    for f in e.get("facts", []):
        fid = _fact_id(f["subject"], "has_value", str(f["value"]), f.get("time", "") or "")
        fact_lookup[(_norm(f["subject"]), _norm(f["value"]))] = fid
        if fid not in subject_lookup[f["subject"]]:   # 同一事实多次抽取折叠，subject→id 去重
            subject_lookup[f["subject"]].append(fid)

def resolve_ref(tok: str) -> str:
    if tok.startswith("FACT::"):
        s, _, v = tok[len("FACT::"):].partition("|")
        return fact_lookup.get((_norm(s), _norm(v)), tok)
    if "|" in tok:
        s, _, v = tok.partition("|")
        return fact_lookup.get((_norm(s), _norm(v)), tok)
    ids = subject_lookup.get(tok, [])
    return ids[0] if len(ids) == 1 else tok

extractions, problems = [], []
for e, c in resolved:
    ext = {"chunk_id": c["id"], "facts": [], "rules": [], "claims": [], "evidence": [], "relations": []}
    for f in e.get("facts", []):
        f = dict(f); f.setdefault("unit", ""); f.setdefault("time", ""); f["source"] = c["id"]
        ext["facts"].append(f)
    for r in e.get("rules", []):
        r = dict(r)
        r["inputs"] = [resolve_ref(t) for t in r.get("inputs", [])]
        r["outputs"] = [resolve_ref(t) for t in r.get("outputs", [])]
        ext["rules"].append(r)
    for cl in e.get("claims", []):
        cl = dict(cl); cl.setdefault("evidence", []); ext["claims"].append(cl)
    for ev in e.get("evidence", []):
        ev = dict(ev); ev.setdefault("claim", ""); ev.setdefault("kind", "内部资料摘录")
        ev["doc"] = c["id"]; ev["span"] = f'{c["span"][0]},{c["span"][1]}'
        ext["evidence"].append(ev)
    for r in e.get("relations", []):
        r = dict(r); r["from"] = resolve_ref(r.get("from", "")); r["to"] = resolve_ref(r.get("to", ""))
        ext["relations"].append(r)
    v = validate_extraction(ext)
    if not v["ok"]:
        problems.append((c["index"], v["errors"]))
    extractions.append(ext)
if problems:
    print("SCHEMA ERRORS:", json.dumps(problems, ensure_ascii=False, indent=2)); sys.exit(1)
# ============ 跨文件依赖：报告技术函数/取值 → 规范条款（depends_on） ============ #
# (报告侧主语, 规范侧条款主语)：报告侧为该规则的输出节点或关键参数节点
NORM_LINKS = [
    ("地上总建筑面积需求", "建标191-2018 专职科研机构用房人均建筑面积指标"),
    ("公共服务配套用房建筑面积", "GB/T50353-2013 建筑面积计算规则"),
    ("总计算负荷", "JGJ16-2008 需要系数与同时使用系数取值"),
    ("最高日用水量", "GB50555-2010 用水定额限值"),
    ("消防用水量合计", "GB50974-2014 消火栓系统设计流量"),
    ("消防一次灭火用水量", "GB50974-2014 消火栓系统设计流量"),
    ("高位消防水箱有效容积", "GB50974-2014-5.2.1 一类高层公共建筑高位消防水箱"),
    ("自动喷水灭火系统用水量", "GB50084-2017-表5.0.1 中危险级Ⅰ级参数"),
    ("冷负荷", "GB50736-2012 室内空气计算参数限值"),
    ("年总用水量", "GB50555-2010 用水定额限值"),
    ("年总耗电量", "JGJ16-2008 需要系数与同时使用系数取值"),
    ("年综合能耗（当量值）", "GB/T2589-2008 折标系数"),
    ("单位面积综合能耗（当量值）", "GB/T2589-2008 折标系数"),
    ("建筑耐火等级", "一类高层建筑耐火等级要求"),
    ("抗震设防烈度", "GB50011-2010 附录A 上海市虹口区抗震设防参数"),
    ("抗震设计分组", "GB50011-2010 附录A 上海市虹口区抗震设防参数"),
    ("特征周期", "GB50011-2010-表5.1.4-2 特征周期值"),
    ("建筑抗震设防类别", "GB50223-2008-6.0.8 教育建筑抗震设防分类"),
    ("设计使用年限", "GB50352-2005-表3.2.1 设计使用年限类别年限"),
    ("绿色建筑设计标准", "GB/T50378-2019实施日期"),
    ("预制率", "上海市装配式建筑装配率要求"),
    ("建筑层数", "GB50016-2014-5.1.1 民用建筑分类"),
    ("建安工程招标估算金额", "必须招标施工限额"),
    ("设计招标估算金额", "必须招标勘察设计监理服务限额"),
    ("监理招标估算金额", "必须招标勘察设计监理服务限额"),
]
_ab_chunk = next(c for c in PRE if "第5.1.1条：民用建筑根据其建筑高度和层数" in c["text"])
_norm_rels, _unresolved = [], []
for rep_subj, norm_subj in NORM_LINKS:
    a = subject_lookup.get(rep_subj, [])
    b = subject_lookup.get(norm_subj, [])
    if len(a) == 1 and len(b) == 1:
        _norm_rels.append({"from": a[0], "to": b[0], "type": "depends_on"})
    else:
        _unresolved.append((rep_subj, len(a), norm_subj, len(b)))
if _unresolved:
    print("NORM LINK UNRESOLVED:", json.dumps(_unresolved, ensure_ascii=False)); sys.exit(1)
extractions.append({"chunk_id": _ab_chunk["id"], "facts": [], "rules": [], "claims": [],
                    "evidence": [], "relations": _norm_rels})
print(f"[1] 语义抽取通过 schema 校验：{len(extractions)} 个 chunk 记录；跨文件依赖边 {len(_norm_rels)} 条")
(WS / "复核/semantic-extractions.json").parent.mkdir(parents=True, exist_ok=True)
(WS / "复核/semantic-extractions.json").write_text(json.dumps(extractions, ensure_ascii=False, indent=2), encoding="utf-8")

# ============================== 工序1-7 回跑 ============================== #
def _safe(t):
    return re.sub(r'[\\/:*?"<>|\r\n]+', "／", str(t)).strip()[:80]

def emit_style_safe(root, chunks, outline):
    root = Path(root)
    lens = [len(c["text"]) for c in chunks] or [0]
    profile = {"number_format": "千分位、两位小数、单位后置、万元优先，建筑面积单位㎡", "terminology": {},
               "forbidden": ["大约", "左右（除非带明确区间）", "或许"],
               "citation_style": "〔节点ID｜规则ID｜证据ID〕", "table_caption": "表N-<标题>",
               "person": "第三人称", "avg_chunk_len": sum(lens) // len(lens),
               "chunk_count": len(chunks), "lang": "zh", "tone": "formal"}
    (root / "style").mkdir(parents=True, exist_ok=True)
    (root / "style/style_profile.yaml").write_text(json.dumps(profile, ensure_ascii=False, indent=2), encoding="utf-8")
    tdir = root / "style/section_templates"; tdir.mkdir(parents=True, exist_ok=True)
    for i, s in enumerate(outline.get("sections", [])):
        (tdir / f"{i+1:02d}-{_safe(s['title'])}.yaml").write_text(
            json.dumps({"level": s["level"], "title": s["title"], "template": "## " + s["title"]}, ensure_ascii=False, indent=2),
            encoding="utf-8")
    return {"templates": len(list(tdir.glob("*.yaml")))}
FE.emit_style = emit_style_safe

# 事实单源：同一 (subject|predicate|value|time) 只入图一次（跨章重复引用折叠为同一节点）
_seen, extractions_dedup, collapsed = set(), [], 0
for ext in extractions:
    e2 = dict(ext); e2["facts"] = []
    for f in ext["facts"]:
        fid = _fact_id(f["subject"], "has_value", str(f["value"]), f.get("time", "") or "")
        if fid in _seen:
            collapsed += 1; continue
        _seen.add(fid); e2["facts"].append(f)
    extractions_dedup.append(e2)
print(f"[1b] 事实单源折叠：重复事实 {collapsed} 条 → 唯一事实节点 {len(_seen)} 个")

result = run_pipeline(RAW, PKG, LEGAL, extractions_dedup)
print(f"[2] 七道工序完成：chunks={result['chunks']} facts={result['facts']} gate={result['gate']}")

# ============================== 脱敏骨架重映射 ============================== #
facts = json.loads((PKG / "graph/nodes.yaml").read_text(encoding="utf-8"))
per_chunk = defaultdict(list)
for ext in extractions:
    for f in ext["facts"]:
        per_chunk[ext["chunk_id"]].append(f)
uniq = defaultdict(list)
for f in facts:
    uniq[_norm(f["value"])].append(f["id"])

chunks = [json.loads(l) for l in (PKG / "chunks/chunks.jsonl").read_text(encoding="utf-8").splitlines() if l]
out_sk, remapped, phantom, ph_list = [], 0, 0, []
for c in chunks:
    text = c["text"]; used = set(); seg = []; prev = 0; hit = False
    for m in _NUM.finditer(text):
        tok = m.group(0); nid = None
        locals_ = per_chunk.get(c["id"], [])
        for f in locals_:
            if id(f) in used: continue
            if _norm(f["value"]) == _norm(tok):
                nid = _fact_id(f["subject"], "has_value", str(f["value"]), f.get("time", "") or "")
                used.add(id(f)); break
        if not nid:
            # 回退1：同一 chunk 内同值事实的重复出现（不消费，保持按序绑定）
            for f in locals_:
                if _norm(f["value"]) == _norm(tok):
                    nid = _fact_id(f["subject"], "has_value", str(f["value"]), f.get("time", "") or ""); break
        if not nid:
            ids = uniq.get(_norm(tok), [])
            if len(ids) == 1: nid = ids[0]
        if not nid:
            # 幻影占位：原文中未绑定到语义事实节点的数值，用 X- 前缀与事实节点区分，不进 node_index
            nid = _stable_id(f"{c['id']}:{tok}", "X"); phantom += 1
            if len(ph_list) < 60: ph_list.append((c["index"], tok))
        seg.append(text[prev:m.start()]); seg.append("{{node:%s}}" % nid); prev = m.end(); hit = True
    seg.append(text[prev:])
    new = "".join(seg)
    if hit: remapped += 1
    out_sk.append({**{k: v for k, v in c.items() if k != "text"}, "text": new})
(PKG / "chunks/skeletons.jsonl").write_text("\n".join(json.dumps(s, ensure_ascii=False) for s in out_sk) + "\n", encoding="utf-8")
FE.emit_index(PKG, {"facts": facts}, chunks, out_sk)
_PH = re.compile(r'{{node:[^}]+}}')
leak = sum(len(_NUM.findall(_PH.sub(" ", s["text"]))) for s in out_sk)
print(f"[3] 脱敏骨架：{remapped}/{len(chunks)} chunk 含占位符；幻影占位 {phantom}；占位符外残留数值 {leak}")

# 证据摘录对齐：目录只保留 evidence.yaml 中登记的摘录（防止跨进程/跨运行残留）
_ev_ids = {e["id"] for e in json.loads((PKG / "evidence/evidence.yaml").read_text(encoding="utf-8"))}
_ex = PKG / "evidence/excerpts"
_removed = 0
for p in _ex.glob("*.md"):
    if p.stem not in _ev_ids:
        p.unlink(); _removed += 1
print(f"[3b] 证据摘录对齐：登记 {len(_ev_ids)} 条，清理未登记残留 {_removed} 个")

# 原稿文本视图入仓（库提供的是固定修订文本视图，docx 二进制不可得）
_src = PKG / "source"
(_src / "original.md").write_text(
    "# 原始文本视图（资料库固定修订 e11fa167-bf22-4471-bdfd-02db9fe4668f / 49f5bb03-33ed-4acb-a001-c673d588c7e4）\n\n"
    + (WS / "input/大数据研究中心可研.raw.txt").read_text(encoding="utf-8"), encoding="utf-8")

# ============================== 冲突与缺口（全部待审） ============================== #
def nid(subject, value):
    return fact_lookup.get((_norm(subject), _norm(value)), subject)

auto = json.loads((PKG / "quality/conflicts.yaml").read_text(encoding="utf-8"))
CURATED_SUBJECTS = {"新建总建筑面积", "室外总体工程", "接待室", "建安工程费用", "办公（教师）用水定额",
                    "项目用水/用电测算人数", "建筑类别", "建筑耐火等级",
                    "《高层民用建筑设计防火规范》GB50045-95", "《普通高等学校建筑规划面积指标》",
                    "《绿色建筑评价标准》GB/T50378-2014"}
CONFLICTS = []
for c in auto:
    c["status"] = "待审"
    c["note"] = "工序5 推演回放自动检出：同一 (主语, 谓语) 出现多个数值，待人工裁定" if c["subject"] not in CURATED_SUBJECTS         else "工序5 推演回放自动检出；同项另有处理者补充注记，以 CURATED 条目为准"
    if c["subject"] in CURATED_SUBJECTS:
        continue
    CONFLICTS.append(c)
CURATED = [
 {"type": "numeric", "subject": "新建总建筑面积", "values": ["18319 平方米", "18219 平方米"],
  "involved": [nid("新建总建筑面积", "18319"), nid("新建总建筑面积", "18219")],
  "note": "真实口径分歧：1.1/5.6/6.1/7.2 等处为18319㎡，13.4资金筹措章正文为18219㎡；以18319㎡为准需回改资金筹措章，待审"},
 {"type": "numeric", "subject": "室外总体工程", "values": ["49 万元", "52 万元"],
  "involved": [nid("室外总体工程", "49"), nid("道路广场硬地铺装工程", "19")],
  "note": "分项与合计不一致：道路19+绿化3+室外安装12+标识18=52万元，表13-1合价写49万元，差3万元（6.1%），待审"},
 {"type": "numeric", "subject": "接待室", "values": ["60 ㎡（1间×60㎡）", "70 ㎡"],
  "involved": [nid("接待室用房标准", "60"), nid("接待室面积需求", "70")],
  "note": "表5-5内部不一致：接待室1间×60㎡/间应为60㎡，面积需求列写70㎡；合计1210㎡按70㎡才成立，待审"},
 {"type": "numeric", "subject": "建安工程费用", "values": ["11188 万元（投资估算）", "10135 万元（招标估算）"],
  "involved": [nid("建安工程费用", "11188"), nid("建安工程招标估算金额", "10135")],
  "note": "同口径不同数：表13-1建安工程费用11188万元，表12-1建安工程招标估算金额10135万元，差1053万元，待审"},
 {"type": "numeric", "subject": "办公（教师）用水定额", "values": ["50 L/人·日（6.4给排水）", "35 L/人·d（7.2节能）"],
  "involved": [nid("办公用水标准", "50"), nid("教师用水定额", "35")],
  "note": "同一288人用水定额两处不一致，导致最高日用水量95.04m³/d（给排水）与节能章日用水量82.1m³/d口径不同，待审"},
 {"type": "numeric", "subject": "项目用水/用电测算人数", "values": ["1665 人（规模测算）", "2088 人（1800学生+288教师）"],
  "involved": [nid("合计规划人数", "1665"), nid("科研学生用水人数", "1800")],
  "note": "人数口径分歧：5.6规模测算按315科研人员+1350研究生=1665人；6.4/7.1用水用电按科研学生1800人（暂定）+办公288人，两套口径未说明换算关系，待审"},
 {"type": "caliber", "subject": "建筑类别", "values": ["3类", "设计使用年限50年"],
  "involved": [nid("建筑类别", "3类"), nid("设计使用年限", "50")],
  "note": "外部核查（附录A.4）：《民用建筑设计通则》GB50352设计使用年限分四类，类别序号与年限对应；本稿未界定“3类”所指，待审"},
 {"type": "code", "subject": "建筑耐火等级", "values": ["二级", "一类高层建筑不应低于一级"],
  "involved": [nid("建筑耐火等级", "二级"), nid("一类高层建筑耐火等级要求", "不应低于一级")],
  "note": "外部核查（附录A.3）：GB50016-2014(2018年版)第5.1.3条，建筑高度大于50m的公共建筑属一类高层，耐火等级不应低于一级；本稿建筑高度控制60m而耐火等级为二级，待审"},
 {"type": "code", "subject": "《高层民用建筑设计防火规范》GB50045-95", "values": ["作为设计依据引用", "已废止"],
  "involved": [nid("GB50045-95状态", "已废止")],
  "note": "外部核查（附录A.3）：GB50045-95已自2015年5月1日起废止，报告6.1节仍列为设计依据，待审"},
 {"type": "code", "subject": "《普通高等学校建筑规划面积指标》", "values": ["报告1.2节引用名称", "已于2018年9月1日废止"],
  "involved": [nid("报告1.2节所列编制依据", "《普通高等学校建筑规划面积指标》（建标191-2018）"),
               nid("原《普通高等学校建筑规划面积指标》状态", "已废止")],
  "note": "外部核查（附录A.2）：建标191-2018正式名称为《普通高等学校建筑面积指标》，原《普通高等学校建筑规划面积指标》同时废止；报告1.2节名称有误，待审"},
 {"type": "code", "subject": "高位消防水箱有效容积", "values": ["18 m³（本稿取值）", "一类高层公共建筑不应小于36 m³"],
  "involved": [nid("高位消防水箱有效容积", "18"), nid("GB50974-2014-5.2.1 一类高层公共建筑高位消防水箱", "不应小于36")],
  "note": "外部核查（附录B.2）：GB50974-2014第5.2.1条，一类高层公共建筑高位消防水箱不应小于36m³，二类高层及多层公共建筑不应小于18m³；本稿取18m³，若按一类高层则应为36m³，待审"},
 {"type": "code", "subject": "抗震设计分组", "values": ["第二组（本稿取值）", "第一组（GB50011附录A 上海虹口）"],
  "involved": [nid("抗震设计分组", "第二组"), nid("GB50011-2010 附录A 上海市虹口区抗震设防参数", "抗震设防烈度7度、设计基本地震加速度0.10g、设计地震第一组")],
  "note": "外部核查（附录B.4）：GB50011-2010附录A中上海市虹口区为设计地震第一组，本稿取第二组，分组取值与规范附录不一致，待审"},
 {"type": "code", "subject": "《绿色建筑评价标准》GB/T50378-2014", "values": ["作为设计依据引用", "已废止"],
  "involved": [nid("GB/T50378-2014状态", "已废止")],
  "note": "外部核查（附录A.6）：GB/T50378-2014已于2019年8月1日废止，报告6.5节仍引用，待审"},
]
CONFLICTS.extend(CURATED)
for c in CONFLICTS:
    c["status"] = "待审"          # 铁律：冲突一律「待审」，不自动裁决
    c.setdefault("involved", [])
(PKG / "quality/conflicts.yaml").write_text(json.dumps(CONFLICTS, ensure_ascii=False, indent=2), encoding="utf-8")

GAPS = [
 {"type": "legal_outline", "section": "六、项目运营方案", "desc": "发改投资规〔2023〕304号通用大纲第六章，本稿无对应独立章节（运行费用仅在11.3提及纳入后勤保障经费）"},
 {"type": "legal_outline", "section": "八、项目影响效果分析", "desc": "通用大纲第八章，本稿仅有第14章社会效益，未含经济影响与生态环境影响的效果分析"},
 {"type": "legal_outline", "section": "九、项目风险管控方案", "desc": "通用大纲第九章，本稿仅有第10章社会稳定风险分析，未形成全面风险识别与管控方案"},
 {"type": "unknown_value", "section": "1.3 技术经济指标", "desc": "容积率、绿地率等指标全校统筹，本稿未给出本项目取值"},
 {"type": "unknown_value", "section": "6.5 强电设计", "desc": "总计算负荷952kW的同时系数取值未给出，无法由建筑面积与单位指标正向复算"},
 {"type": "unknown_value", "section": "16 附件", "desc": "原有第五教学楼拆除手续处于“正同步办理中/待补充”，前置条件未闭合"},
 {"type": "unknown_value", "section": "7.3 能耗指标分析", "desc": "表7-3折标系数中电力等价值按3 tce/万kW·h取值，其依据文件未列明"},
]
(PKG / "quality/gaps.yaml").write_text(json.dumps({"gaps": GAPS, "outline_missing": []}, ensure_ascii=False, indent=2), encoding="utf-8")

gate = {"gate": "REVIEW" if CONFLICTS else "PASS",
        "blockers": CONFLICTS, "invariant_ok": True,
        "review_notes": [{"subject": c["subject"], "note": c["note"]} for c in CONFLICTS],
        "summary": f"共 {len(CONFLICTS)} 项冲突全部呈「待审」，未作裁决；缺口 {len(GAPS)} 项保持显式未知。"}
(PKG / "quality/gate_report.yaml").write_text(json.dumps(gate, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"[4] 质量登记：冲突 {len(CONFLICTS)} 项（全部待审）/ 缺口 {len(GAPS)} 项")

# ============================== 溯源增强（一事实多来源） ============================== #
sources = defaultdict(list)
for ext in extractions:
    for f in ext["facts"]:
        fid = _fact_id(f["subject"], "has_value", str(f["value"]), f.get("time", "") or "")
        if ext["chunk_id"] not in sources[fid]:
            sources[fid].append(ext["chunk_id"])
prov = json.loads((PKG / "provenance.yaml").read_text(encoding="utf-8"))
for p in prov:
    if p.get("obj_type") == "fact":
        allsrc = sources.get(p["obj_id"])
        if allsrc:
            p["derived_from"] = allsrc
            p["occurrences"] = len(allsrc)
(PKG / "provenance.yaml").write_text(json.dumps(prov, ensure_ascii=False, indent=2), encoding="utf-8")

# ============================== 法定大纲映射 ============================== #
mapping = {"legal_basis": "发改投资规〔2023〕304号《政府投资项目可行性研究报告编写通用大纲（2023年版）》",
           "report_basis": "本稿编制于2019年8月，未按2023年版通用大纲章节体系组织",
           "chapters": [{"outline": k, "report_sections": v, "status": "covered" if v else "gap"} for k, v in LEGAL_304_MAP.items()]}
(PKG / "legal_mapping.yaml").write_text(json.dumps(mapping, ensure_ascii=False, indent=2), encoding="utf-8")

# ============================== 联合依赖：报告 ↔ 规范 ============================== #
rule_by_output = defaultdict(list)
for ext in extractions:
    for r in ext["rules"]:
        for o in r.get("outputs", []):
            rule_by_output[o].append(r["id"])
val_by_id = {f["id"]: f for f in facts}
rows = []
for rep_subj, norm_subj in NORM_LINKS:
    rid_ = subject_lookup[rep_subj][0]
    nid_ = subject_lookup[norm_subj][0]
    nval = str(val_by_id[nid_].get("value", ""))
    rows.append({
        "report_node": rid_, "report_subject": rep_subj,
        "report_value": val_by_id[rid_].get("value"), "report_unit": val_by_id[rid_].get("unit", ""),
        "rules": sorted(set(rule_by_output.get(rid_, []))),
        "norm_node": nid_, "norm_clause": norm_subj, "norm_value": nval,
        "norm_status": "待核" if "待核" in nval else "已核",
        "relation": "depends_on",
    })
cross = {"note": "报告的技术函数与关键取值 → 其所依赖的外部规范条款（跨文件依赖）",
         "relation": "depends_on", "links": rows,
         "summary": {"total": len(rows),
                     "verified": sum(1 for r in rows if r["norm_status"] == "已核"),
                     "pending": sum(1 for r in rows if r["norm_status"] == "待核")}}
(PKG / "dependencies.yaml").write_text(json.dumps(cross, ensure_ascii=False, indent=2), encoding="utf-8")
_lines = ["# 规范依赖矩阵：报告技术函数 ↔ 外部规范条款", "",
          "> 由 `dependencies.yaml` 渲染。`已核`= 已取到规范条款原文；`待核`= 条款存在但本次未取到限值原文，不得据此判定符合规范。", "",
          "| 报告技术函数 / 取值 | 节点 | 规则 | 依赖的规范条款 | 条款值 | 状态 |",
          "| --- | --- | --- | --- | --- | --- |"]
for r in rows:
    rv = f"{r['report_value']}{(' ' + r['report_unit']) if r['report_unit'] else ''}"
    _lines.append(f"| {r['report_subject']}（{rv}） | {r['report_node']} | {'、'.join(r['rules']) or '—'} | {r['norm_clause']} | {r['norm_value']} | {r['norm_status']} |")
(PKG / "dependencies.md").write_text("\n".join(_lines) + "\n", encoding="utf-8")
print(f"[6b] 联合依赖：{len(rows)} 条 depends_on（已核 {cross['summary']['verified']} / 待核 {cross['summary']['pending']}）")

# ============================== meta 修正 ============================== #
meta = {"title": "上海财经大学中山北一路校区大数据研究中心可行性研究报告（修订）",
        "doc_type": "可研报告", "doc_id": "2019ZX054", "version": "修订版",
        "author": "上海同济工程咨询有限公司", "owner": "上海财经大学",
        "data_cutoff": "2019-08", "lang": "zh", "source_sha": hashlib.sha1(RAW.encode("utf-8")).hexdigest()[:16],
        "scope_note": "corpus 含原报告全文与两份处理者补充附录（附录A：外部规范与法定大纲核查结论层；附录B：引用规范条款层），"
                       "均来源为公开权威网页，非原报告内容；报告的技术函数与关键取值经 depends_on 边挂接到规范条款节点"}
(PKG / "meta.yaml").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

# 扩展产物登记：30 文件契约之外，本资产增补的正式产物
man = json.loads((PKG / "manifest.yaml").read_text(encoding="utf-8"))
man["extensions"] = [
    {"name": "legal_mapping.yaml", "stage": "2", "fmt": "YAML", "mutable": "冻结",
     "agent": "① 注入(大纲覆盖)", "desc": "报告章节 ↔ 发改投资规〔2023〕304号通用大纲 10 章映射与覆盖状态"},
    {"name": "dependencies.yaml", "stage": "4", "fmt": "YAML", "mutable": "冻结",
     "agent": "② graph_impact/graph_explain", "desc": "跨文件依赖台账：报告技术函数与关键取值 → 外部规范条款，含核验状态"},
    {"name": "dependencies.md", "stage": "4", "fmt": "Markdown", "mutable": "冻结",
     "agent": "① 注入(依赖矩阵)", "desc": "dependencies.yaml 的人读视图"},
    {"name": "写作输入/推演写作输入包.md", "stage": "7", "fmt": "Markdown", "mutable": "可更新",
     "agent": "① 注入(写作输入单)", "desc": "形(骨架)+值(节点值表)+律(规则/依赖/冲突/缺口) 的装配输入单"},
    {"name": "写作输入/fact-brief.yaml", "stage": "7", "fmt": "YAML", "mutable": "可更新",
     "agent": "② 工具调用", "desc": "上者的机器可读版本"},
    {"name": "inventory.yaml", "stage": "7", "fmt": "YAML", "mutable": "冻结",
     "agent": "✕", "desc": "30 文件契约 + 扩展产物的到位盘点"},
    {"name": "写作输入/章节提示词/*.md", "stage": "7", "fmt": "Markdown", "mutable": "可更新",
     "agent": "① 注入(逐节提示词)", "desc": "逐节提示词：每个结构性章节一段可投喂提示词 + 本节事实表"},
    {"name": "写作输入/章节提示词索引.md", "stage": "7", "fmt": "Markdown", "mutable": "可更新",
     "agent": "① 注入(索引)", "desc": "逐节提示词索引：层级、篇幅、事实数、函数数、冲突数、缺口数"},
    {"name": "写作输入/section-prompts.yaml", "stage": "7", "fmt": "YAML", "mutable": "可更新",
     "agent": "② 工具调用", "desc": "逐节提示词的机器可读版本"},
    {"name": "README.md", "stage": "7", "fmt": "Markdown", "mutable": "可更新",
     "agent": "✕", "desc": "知识资产说明（结构、通道、规模、契约缺口）"},
    {"name": "写作输入/00-移交说明-给推演写作专家.md", "stage": "7", "fmt": "Markdown", "mutable": "可更新",
     "agent": "① 注入(装配指引)", "desc": "移交给推演写作专家：资产放哪、上下文放什么、通道用法、硬禁令"},
    {"name": "写作输入/节点索引表.md", "stage": "7", "fmt": "Markdown", "mutable": "可更新",
     "agent": "① 注入(节点字典)", "desc": "节点字典：442 条按ID与事实名速查，含所在章文件与引用数"},
    {"name": "写作输入/node-index.tsv", "stage": "7", "fmt": "TSV", "mutable": "可更新",
     "agent": "② 工具调用", "desc": "节点字典的 TSV 版本，可直接 grep 占位符 ID"},
    {"name": "写作输入/写作会话启动包.md", "stage": "7", "fmt": "Markdown", "mutable": "可更新",
     "agent": "① 注入(一次投喂)", "desc": "自足启动包：提示词 + 装配指引 + 逐节索引 + 节点字典"},
    {"name": "外部核验/SEMANTICA-INTEGRATION.md", "stage": "6", "fmt": "Markdown", "mutable": "可更新",
     "agent": "① 注入(核验报告)", "desc": "Semantica 外部核验报告：用了哪些模块/方法、结果、局限、复现命令"},
    {"name": "外部核验/*.yaml", "stage": "6", "fmt": "YAML", "mutable": "可更新",
     "agent": "② 工具调用", "desc": "Semantica 核验产物：冲突互证 / 去重候选与复核 / 抽取探测 / PROV-O 统计"},
    {"name": "外部核验/provenance/prov.db", "stage": "6", "fmt": "SQLite", "mutable": "追加",
     "agent": "② 工具调用", "desc": "W3C PROV-O 合规溯源库（442 条实体、SHA-256 校验和）"},
    {"name": "外部核验/实体归一-人工判断清单.md", "stage": "6", "fmt": "Markdown", "mutable": "可更新",
     "agent": "① 注入(人工待办)", "desc": "实体归一人工判断清单：490 条「待人工判断」，分 P1-P4 优先级"},
    {"name": "外部核验/*.tsv", "stage": "6", "fmt": "TSV", "mutable": "可更新",
     "agent": "② 工具调用", "desc": "实体归一队列 TSV，可直接 grep / 填入人工决定"},
    {"name": "外部核验/P0B-交叉校验报告.md", "stage": "6", "fmt": "Markdown", "mutable": "可更新",
     "agent": "① 注入(核验报告)", "desc": "P0-b 全语料抽取交叉校验报告（指标 v2，两级判定）"},
    {"name": "外部核验/p0b-crosscheck.yaml", "stage": "6", "fmt": "YAML", "mutable": "可更新",
     "agent": "② 工具调用", "desc": "P0-b 交叉校验结果（A 组两级判定 + B 组分层噪声过滤）"},
    {"name": "外部核验/judge-accuracy-history.yaml", "stage": "6", "fmt": "YAML", "mutable": "追加",
     "agent": "② 工具调用", "desc": "判官准确率历史（每轮追加），所有准确率数字的权威来源"},
    {"name": "外部核验/ontology/ontology.ttl", "stage": "4", "fmt": "Turtle", "mutable": "可更新",
     "agent": "② 工具调用", "desc": "OWL 本体（OntologyGenerator + OWLGenerator 从图推导）"},
    {"name": "外部核验/ontology/shapes.ttl", "stage": "6", "fmt": "Turtle", "mutable": "可更新",
     "agent": "② 工具调用", "desc": "SHACL 约束形状（SHACLGenerator）"},
    {"name": "外部核验/ontology/kg-graph.json", "stage": "4", "fmt": "JSON", "mutable": "可更新",
     "agent": "② 工具调用", "desc": "Semantica 图构建结果（kg.GraphBuilder，442 事实 + 514 关系）"},
    {"name": "外部核验/ontology/semantica-attestation.yaml", "stage": "6", "fmt": "YAML", "mutable": "追加",
     "agent": "② 工具调用", "desc": "本体图谱工步的引擎证明（引擎/调用次数/输出计数/耗时）"},
    {"name": "外部核验/prompt/*.json", "stage": "4", "fmt": "JSON", "mutable": "可更新",
     "agent": "① 注入", "desc": "动态提示词编译产物（文档画像 -> 槽位绑定 -> 生成的提示词）"},
    {"name": "外部核验/ingest_parse/*", "stage": "1", "fmt": "混合", "mutable": "可更新",
     "agent": "② 工具调用", "desc": "Semantica FileIngestor + DocumentParser 解析真实 docx（31 表）"},
    {"name": "外部核验/normalize/*", "stage": "1", "fmt": "混合", "mutable": "可更新",
     "agent": "② 工具调用", "desc": "Semantica TextNormalizer 规范化 + 适用性声明"},
    {"name": "外部核验/vector/*", "stage": "7", "fmt": "混合", "mutable": "可更新",
     "agent": "② 工具调用", "desc": "Semantica EmbeddingGenerator(512维中文) + FAISSStore"},
    {"name": "外部核验/chain-attestation.yaml", "stage": "0", "fmt": "YAML", "mutable": "追加",
     "agent": "② 工具调用", "desc": "主链编排 attestation（23 步，含 10 个 Semantica 步骤的引擎证明）"},
    {"name": "外部核验/chain-run.log", "stage": "0", "fmt": "日志", "mutable": "追加",
     "agent": "② 工具调用", "desc": "主链编排运行日志（无管道遮蔽，保留真实退出码）"},
]
(PKG / "manifest.yaml").write_text(json.dumps(man, ensure_ascii=False, indent=2), encoding="utf-8")

# ============================== 图谱审计 ============================== #
graph = json.loads((PKG / "graph/graph.yaml").read_text(encoding="utf-8"))
claims, evidence, rules, rels = graph.get("claims", []), graph.get("evidence", []), graph.get("rules", []), graph.get("relations", [])
entity_ids = set()
for r in rels:
    for k in ("from", "to"):
        v = r.get(k)
        if v and not re.match(r'^(N-|EV-|CL-|R\d)', str(v)): entity_ids.add(v)
for f in facts: entity_ids.add(f["subject"])
rel_nodes = []
for i, r in enumerate(rels):
    rr = dict(r); rr["id"] = "REL-" + hashlib.sha1(f"{r.get('from')}|{r.get('type')}|{r.get('to')}|{i}".encode()).hexdigest()[:12]
    rel_nodes.append(rr)
items = {"entities": [{"id": e} for e in sorted(entity_ids)], "facts": facts, "relations": rel_nodes,
         "reasoning": rules, "claims": claims, "evidence": evidence,
         "conflicts": [{"id": f"CF-{i+1}", "subject": c["subject"], "involved": c.get("involved", [])} for i, c in enumerate(CONFLICTS)],
         "validations": []}
vg = validate_graph({"items": items})
_ATOMIC = re.compile(r'^[-+]?\d[\d,]*(?:[.．]\d+)?%?$')
atomic = [f for f in facts if _ATOMIC.match(str(f.get("value", "")))]
nc = detect_numeric_conflicts(atomic)
tc = detect_time_conflicts(atomic)
print(f"[5] 图谱校验 ok={vg['ok']} errors={len(vg['errors'])} stats={vg['stats']}")
print(f"[6] 原子数值事实 {len(atomic)}；数字冲突(工具) {len(nc)}；时间冲突 {len(tc)}")
audit = {"validate_graph": vg, "numeric_conflicts_tool": nc, "time_conflicts_tool": tc,
         "counts": {"facts": len(facts), "rules": len(rules), "claims": len(claims), "evidence": len(evidence),
                    "relations": len(rels), "chunks": len(chunks), "skeletons": len(out_sk),
                    "official_conflicts": len(CONFLICTS), "gaps": len(GAPS)},
         "phantom_placeholders": phantom, "literal_number_leak": leak, "phantom_samples": ph_list}
(WS / "复核/graph-audit.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(audit["counts"], ensure_ascii=False))

# ============================== 30 文件契约盘点 ============================== #
from corpus_pipeline.spec import MANIFEST
inv, missing_f = [], []
for m in MANIFEST:
    name = m["name"]
    if "*" in name:
        base, pat = name.rsplit("/", 1)
        d = PKG / base
        n = len(list(d.rglob(pat))) if d.exists() else 0
        ok = n > 0
    else:
        p = PKG / name
        n = 1 if p.exists() else 0
        ok = p.exists()
    inv.append({"name": name, "stage": m["stage"], "exists": bool(ok), "files": n, "agent": m["agent"]})
    if not ok: missing_f.append(name)
EXT = [("legal_mapping.yaml", "法定大纲映射"), ("dependencies.yaml", "跨文件依赖台账"),
       ("dependencies.md", "依赖矩阵人读视图"), ("写作输入/推演写作输入包.md", "写作输入单"),
       ("写作输入/fact-brief.yaml", "写作输入单(机器可读)"),
       ("写作输入/章节提示词/*.md", "逐节提示词"), ("写作输入/章节提示词索引.md", "逐节提示词索引"),
       ("写作输入/section-prompts.yaml", "逐节提示词(机器可读)"),
       ("写作输入/00-移交说明-给推演写作专家.md", "移交说明"),
       ("写作输入/节点索引表.md", "节点字典"), ("写作输入/node-index.tsv", "节点字典(TSV)"),
       ("写作输入/写作会话启动包.md", "自足启动包"),
       ("外部核验/SEMANTICA-INTEGRATION.md", "Semantica 核验报告"),
       ("外部核验/*.yaml", "Semantica 核验产物"),
       ("外部核验/provenance/prov.db", "PROV-O 溯源库"),
       ("外部核验/实体归一-人工判断清单.md", "实体归一人工判断清单"),
       ("外部核验/*.tsv", "实体归一队列 TSV"),
       ("外部核验/P0B-交叉校验报告.md", "P0-b 交叉校验报告"),
       ("外部核验/p0b-crosscheck.yaml", "P0-b 结果"),
       ("外部核验/judge-accuracy-history.yaml", "准确率历史(权威)"),
       ("外部核验/ontology/ontology.ttl", "OWL 本体"),
       ("外部核验/ontology/shapes.ttl", "SHACL 约束"),
       ("外部核验/ontology/kg-graph.json", "Semantica 图"),
       ("外部核验/ontology/semantica-attestation.yaml", "本体工步引擎证明"),
       ("外部核验/prompt/*.json", "动态提示词编译产物"),
       ("外部核验/ingest_parse/*", "加载与解析产物"),
       ("外部核验/normalize/*", "规范化产物与适用性声明"),
       ("外部核验/vector/*", "向量与FAISS库"),
       ("外部核验/chain-attestation.yaml", "全链编排证据"),
       ("外部核验/chain-run.log", "全链运行日志"),
       ("inventory.yaml", "本盘点表"), ("README.md", "资产说明")]
def _ext_exists(n: str) -> bool:
    """扩展条目存在性：支持 glob（此前用 (PKG/n).exists()，glob 恒为 False）。"""
    p = PKG / n
    if "*" not in n:
        return p.exists()
    return bool(list(p.parent.glob(p.name)))


ext_items = [{"name": n, "desc": d, "exists": _ext_exists(n), "files": len(list((PKG / n).parent.glob((PKG / n).name))) if "*" in n else 1} for n, d in EXT]
(PKG / "inventory.yaml").write_text(json.dumps({
    "base_contract_files": len(MANIFEST), "base_present": len(MANIFEST) - len(missing_f), "base_missing": missing_f,
    "extensions": ext_items, "extensions_present": sum(1 for e in ext_items if e["exists"]),
    "items": inv}, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"[7] 30 文件契约盘点：{len(MANIFEST) - len(missing_f)}/{len(MANIFEST)} 就位；缺 {missing_f}")
