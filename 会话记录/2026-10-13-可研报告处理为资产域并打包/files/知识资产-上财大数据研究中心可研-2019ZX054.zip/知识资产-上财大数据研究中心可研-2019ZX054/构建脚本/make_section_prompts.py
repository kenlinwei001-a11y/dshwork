# -*- coding: utf-8 -*-
"""逐节提示词抽取：为原报告每一个章节生成可直接投喂写作 Agent 的提示词。"""
import json, re
from pathlib import Path
from collections import defaultdict

F3 = chr(96) * 3   # 代码围栏
WS = Path(__file__).resolve().parent.parent
PKG = WS / "知识资产-上财大数据研究中心可研"
OUT = PKG / "写作输入"
PROMPT_DIR = OUT / "章节提示词"
PROMPT_DIR.mkdir(parents=True, exist_ok=True)

chunks = [json.loads(l) for l in (PKG / "chunks/chunks.jsonl").read_text(encoding="utf-8").splitlines() if l]
nodes = json.loads((PKG / "graph/nodes.yaml").read_text(encoding="utf-8"))
rules = json.loads((PKG / "graph/rules.yaml").read_text(encoding="utf-8"))
conf = json.loads((PKG / "quality/conflicts.yaml").read_text(encoding="utf-8"))
gaps = json.loads((PKG / "quality/gaps.yaml").read_text(encoding="utf-8"))["gaps"]
cw = json.loads((PKG / "dependencies.yaml").read_text(encoding="utf-8"))
outline = json.loads((PKG / "outline.yaml").read_text(encoding="utf-8"))
deriv = json.loads((PKG / "reasoning/derivation.yaml").read_text(encoding="utf-8"))
narr = {d["rule"]: d.get("narrative_zh", "") for d in deriv.get("nodes", [])}

head_re = re.compile(r'^(#{1,6})\s+(.+)$')
sections, stack, owner = [], [], {}
for c in chunks:
    if c["type"] == "heading":
        m = head_re.match(c["text"].strip())
        if m:
            lvl, title = len(m.group(1)), m.group(2).strip()
            stack = [(l, t, i) for (l, t, i) in stack if l < lvl] + [(lvl, title, len(sections))]
            sections.append({"no": len(sections), "level": lvl, "title": title, "chunk": c["id"],
                             "index": c["index"], "path": " / ".join(t for _, t, _ in stack),
                             "parent": stack[-2][2] if len(stack) > 1 else None})
    owner[c["id"]] = stack[-1][2] if stack else None
for s in sections:
    s["chunk_index"] = next(c["index"] for c in chunks if c["id"] == s["chunk"])
for i, s in enumerate(sections):
    end = len(chunks)
    for j in range(i + 1, len(sections)):
        if sections[j]["level"] <= s["level"]:
            end = sections[j]["chunk_index"]; break
    s["block_end"] = end
def in_block(s, c): return s["chunk_index"] < c["index"] < s["block_end"]
def subtree(si, out):
    out.append(si)
    for j, t in enumerate(sections):
        if t.get("parent") == si: subtree(j, out)
    return out

nodes_by_src = defaultdict(list)
for n in nodes: nodes_by_src[n.get("source", "")].append(n)

for s in sections:
    own = []
    for c in chunks:
        if c["type"] == "heading": continue
        if in_block(s, c) and owner.get(c["id"]) == s["no"]: own.append(c)
    s["chunks_own"] = own
    s["chars"] = sum(len(c["text"]) for c in own)
    s["facts_own"] = [n for c in own for n in nodes_by_src.get(c["id"], [])]
    sub = subtree(s["no"], [])
    sub_ids = {sections[k]["chunk"] for k in sub}
    s["facts_sub"] = [n for c in chunks if owner.get(c["id"]) in sub and c["type"] != "heading"
                      for n in nodes_by_src.get(c["id"], [])]
    s["children"] = [j for j, t in enumerate(sections) if t.get("parent") == s["no"]]

node2sec = {}
for s in sections:
    for n in s["facts_sub"]: node2sec.setdefault(n["id"], s["no"])
sec_rules = defaultdict(list)
for r in rules:
    seen = set()
    for tid in [r.get("target")] + list(r.get("deps", [])):
        if tid in node2sec: seen.add(node2sec[tid])
    for si in seen: sec_rules[si].append(r["id"])

def sec_conf(s):
    ids = {n["id"] for n in s["facts_sub"]}
    hits = []
    for i, c in enumerate(conf):
        if ids & set(c.get("involved", [])) or (s["title"] and s["title"] in str(c.get("note", ""))):
            hits.append(i)
    return sorted(set(hits))
def sec_gaps(s):
    hits = 0; out = []
    for i, g in enumerate(gaps):
        gs = str(g.get("section", ""))
        if s["title"] and s["title"] in gs: out.append(i)
    return out
def sec_norm(s):
    ids = {n["id"] for n in s["facts_sub"]}
    return [l for l in cw["links"] if l["report_node"] in ids]

def one_line_vals(fs, k=10):
    parts = [f'{n["subject"]}={n["value"]}{(" " + n["unit"]) if n.get("unit") else ""}〔{n["id"]}〕' for n in fs[:k]]
    if len(fs) > k: parts.append(f"另 {len(fs) - k} 条见本节事实表")
    return "；".join(parts)

def prompt_of(s):
    fs, rs, cf, gp, nm = s["facts_sub"], sec_rules[s["no"]], sec_conf(s), sec_gaps(s), sec_norm(s)
    P = [f'依据脱敏骨架撰写《{s["title"]}》一节（位于 {s["path"]}，层级 h{s["level"]}）。']
    if s["chunks_own"]:
        cids = "、".join(c["id"] for c in s["chunks_own"][:6]) + ("…" if len(s["chunks_own"]) > 6 else "")
        P.append(f'可借用句式与段落结构的骨架 chunk：{cids}（数值均已占位，必须用下列节点替换，不得沿用字面量）。')
    else:
        P.append("本节无对应骨架，按同类章节句式自行组织，数值同样只能取下列节点。")
    if fs:
        P.append(f'本节须覆盖 {len(fs)} 条事实节点，取值唯一来源是事实节点值表：{one_line_vals(fs)}。')
    if rs:
        P.append("涉及技术函数：" + "、".join(rs) + "；须采用其规范叙述句，保证口径一致。")
    if nm:
        P.append("规范依赖：" + "；".join(f'{l["norm_clause"]}（{l["norm_status"]}）' for l in nm) + "。")
    if cf:
        P.append("须显式呈现的待审冲突：" + "；".join(f'{conf[i]["subject"]}（{"／".join(conf[i]["values"])}，待审）' for i in cf) + "；不得裁决。")
    if gp:
        P.append("须显式标注的缺口：" + "；".join(gaps[i]["desc"] for i in gp) + "；不得估值、不得填 0。")
    P.append(f'篇幅参考：原稿本节约 {s["chars"]} 字符，据此控制详略。')
    P.append("返回：正文 Markdown（数值写〔节点ID〕引用）＋ node_mentions ＋ new_claims ＋ unresolved。")
    return "\n".join("  " + x for x in P)

def top_title(s):
    cur = s
    while cur.get("parent") is not None:
        cur = sections[cur["parent"]]
    return cur["title"]

top_chapters = [s for s in sections if s["level"] == 1]
index_rows = []
for ch in top_chapters:
    members = subtree(ch["no"], [])
    safe_title = re.sub(r"[\\/:*?\"<>|]", "／", ch["title"])[:40]
    fname = f'{ch["no"] + 1:02d}-{safe_title}.md'
    L = [f'# 章节提示词 · {ch["title"]}', "",
         f'> 原报告第 {ch["no"] + 1} 个一级章节，含 {len(members)} 节。本章事实节点 {len(ch["facts_sub"])} 条，'
         f'技术函数 {len(sec_rules[ch["no"]])} 条，待审冲突 {len(sec_conf(ch))} 项，缺口 {len(sec_gaps(ch))} 项。', "",
         "**通用铁律**：借形不借值（形取骨架、值取事实节点值表）；缺值守卫（缺口不得填 0、不得估值）；"
         "不许反算；引用即绑定〔节点ID〕；冲突一律待审；不得编造；待核规范条款不得据此写「符合规范」。", ""]
    for si in members:
        s = sections[si]
        h = max(3, s["level"] + 1)
        L.append("#" * h + f' S{si + 1:03d} · {s["title"]}')
        L.append("")
        L.append(f'- 章节路径：{s["path"]}')
        L.append(f'- 层级：h{s["level"]} ｜ 原稿篇幅：约 {s["chars"]} 字符 ｜ 骨架 chunk：{len(s["chunks_own"])} 条 ｜ '
                 f'事实节点：{len(s["facts_sub"])} 条 ｜ 技术函数：{len(sec_rules[si])} 条 ｜ '
                 f'待审冲突：{len(sec_conf(s))} 项 ｜ 缺口：{len(sec_gaps(s))} 项')
        L.append("")
        L.append("**建议提示词**")
        L.append("")
        L.append(F3 + "text")
        L.append(prompt_of(s))
        L.append(F3)
        L.append("")
        if s["facts_sub"]:
            L.append("| 节点ID | 事实 | 值 | 时点 | 口径 |")
            L.append("| --- | --- | --- | --- | --- |")
            for n in s["facts_sub"]:
                L.append(f'| {n["id"]} | {n["subject"]} | {n["value"]}{(" " + n["unit"]) if n.get("unit") else ""} | '
                         f'{n.get("time", "") or "—"} | {n.get("caliber", "") or "—"} |')
            L.append("")
        index_rows.append({"no": si + 1, "chapter": ch["title"], "section": s["title"], "level": s["level"],
                           "chars": s["chars"], "skeleton_chunks": len(s["chunks_own"]),
                           "facts": len(s["facts_sub"]), "rules": len(sec_rules[si]),
                           "conflicts": len(sec_conf(s)), "gaps": len(sec_gaps(s)), "prompt_file": fname})
    (PROMPT_DIR / fname).write_text("\n".join(L), encoding="utf-8")

Id = ["# 章节提示词索引", "",
      f"共 {len(sections)} 个结构性章节（带层级标记），分属 {len(top_chapters)} 个一级章节。逐节提示词见「章节提示词」目录下同名文件。", "",
      "> 口径说明：outline.yaml 记录 268 条标题匹配，其中含编号子项（如「1.设计规模」「（1）水源」）；本索引取其中带层级标记的结构性章节作为写作单元——编号子项归属其父章节，不单独成节。", "",
      "| # | 一级章节 | 章节 | 层级 | 原稿字符 | 骨架chunk | 事实节点 | 技术函数 | 待审冲突 | 缺口 | 提示词文件 |",
      "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |"]
for r in index_rows:
    Id.append(f'| S{r["no"]:03d} | {r["chapter"]} | {r["section"]} | h{r["level"]} | {r["chars"]} | '
              f'{r["skeleton_chunks"]} | {r["facts"]} | {r["rules"]} | {r["conflicts"]} | {r["gaps"]} | {r["prompt_file"]} |')
(OUT / "章节提示词索引.md").write_text("\n".join(Id) + "\n", encoding="utf-8")

out_yaml = []
for s in sections:
    out_yaml.append({
        "section_no": s["no"] + 1, "title": s["title"], "level": s["level"], "path": s["path"],
        "chapter": sections[s["parent"]]["title"] if s.get("parent") is not None else s["title"],
        "top_chapter": top_title(s),
        "source_chars": s["chars"],
        "skeleton_chunks": [c["id"] for c in s["chunks_own"]],
        "must_cover_nodes": [{"node": n["id"], "subject": n["subject"], "value": n["value"], "unit": n.get("unit", "")}
                             for n in s["facts_sub"]],
        "rules": sec_rules[s["no"]],
        "norm_dependencies": [{"norm_clause": l["norm_clause"], "norm_node": l["norm_node"],
                               "norm_status": l["norm_status"], "report_node": l["report_node"]} for l in sec_norm(s)],
        "conflicts": [{"subject": conf[i]["subject"], "values": conf[i]["values"], "status": conf[i]["status"],
                       "note": conf[i].get("note", "")} for i in sec_conf(s)],
        "gaps": [gaps[i] for i in sec_gaps(s)],
        "prompt": prompt_of(s),
        "return_contract": ["draft_md", "node_mentions", "new_claims", "unresolved"],
    })
(OUT / "section-prompts.yaml").write_text(json.dumps(out_yaml, ensure_ascii=False, indent=2), encoding="utf-8")

invp = PKG / "inventory.yaml"
if invp.exists():
    iv = json.loads(invp.read_text(encoding="utf-8"))
    names = {e["name"] for e in iv.get("extensions", [])}
    for nm, desc in [("写作输入/章节提示词/*.md", "逐节提示词（每节可投喂提示词 + 本节事实表）"),
                     ("写作输入/章节提示词索引.md", "逐节提示词索引与装配统计"),
                     ("写作输入/section-prompts.yaml", "逐节提示词机器可读版本")]:
        if nm not in names:
            iv.setdefault("extensions", []).append({"name": nm, "desc": desc, "exists": False})
    for e in iv["extensions"]:
        p = PKG / e["name"]
        e["exists"] = bool(list(p.parent.glob(p.name))) if "*" in e["name"] else p.exists()
    iv["extensions_present"] = sum(1 for e in iv["extensions"] if e["exists"])
    invp.write_text(json.dumps(iv, ensure_ascii=False, indent=2), encoding="utf-8")
    print("inventory extensions:", iv["extensions_present"], "/", len(iv["extensions"]))
print("sections:", len(sections), "| chapters:", len(top_chapters), "| prompt files:", len(top_chapters))
print("有事实的节:", sum(1 for s in sections if s["facts_sub"]),
      "| 有冲突的节:", sum(1 for s in sections if sec_conf(s)),
      "| 有缺口的节:", sum(1 for s in sections if sec_gaps(s)))
