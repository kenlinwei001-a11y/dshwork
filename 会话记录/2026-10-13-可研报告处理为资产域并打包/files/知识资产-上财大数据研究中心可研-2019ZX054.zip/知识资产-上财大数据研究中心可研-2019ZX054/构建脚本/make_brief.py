# -*- coding: utf-8 -*-
"""生成《推演写作输入包》：知识资产 + 外部规范事实 -> 写作 Agent 可直接消费的事实输入单。"""
import json, re
from pathlib import Path
from collections import OrderedDict

WS = Path(__file__).resolve().parent.parent
PKG = WS / "知识资产-上财大数据研究中心可研"
OUT = PKG / "写作输入"          # 写作输入单是知识资产的一部分（装配输入），不放在包外
OUT.mkdir(parents=True, exist_ok=True)

chunks = [json.loads(l) for l in (PKG / "chunks/chunks.jsonl").read_text(encoding="utf-8").splitlines() if l]
nodes = json.loads((PKG / "graph/nodes.yaml").read_text(encoding="utf-8"))
rules = json.loads((PKG / "graph/rules.yaml").read_text(encoding="utf-8"))
claims = json.loads((PKG / "graph/claims.yaml").read_text(encoding="utf-8"))
rels = json.loads((PKG / "graph/relations.yaml").read_text(encoding="utf-8"))
conf = json.loads((PKG / "quality/conflicts.yaml").read_text(encoding="utf-8"))
gaps = json.loads((PKG / "quality/gaps.yaml").read_text(encoding="utf-8"))["gaps"]
ev = json.loads((PKG / "evidence/evidence.yaml").read_text(encoding="utf-8"))
meta = json.loads((PKG / "meta.yaml").read_text(encoding="utf-8"))
outline = json.loads((PKG / "outline.yaml").read_text(encoding="utf-8"))
style = json.loads((PKG / "style/style_profile.yaml").read_text(encoding="utf-8"))
terms = json.loads((PKG / "index/term_index.json").read_text(encoding="utf-8"))
deriv = json.loads((PKG / "reasoning/derivation.yaml").read_text(encoding="utf-8"))
cw = json.loads((PKG / "dependencies.yaml").read_text(encoding="utf-8"))
legal = json.loads((PKG / "legal_mapping.yaml").read_text(encoding="utf-8"))
narr = {d["rule"]: d.get("narrative_zh", "") for d in deriv.get("nodes", [])}

stack, chunk_sec = [], {}
for c in chunks:
    if c["type"] == "heading":
        m = re.match(r'^(#{1,6})\s+(.+)$', c["text"].strip())
        if m:
            lvl, title = len(m.group(1)), m.group(2).strip()
            stack = [(l, t) for (l, t) in stack if l < lvl] + [(lvl, title)]
    chunk_sec[c["id"]] = " / ".join(t for _, t in stack) or "（正文前）"

by_sec = OrderedDict()
for n in nodes:
    by_sec.setdefault(chunk_sec.get(n.get("source", ""), "（未定位）"), []).append(n)
first_idx = {}
for i, c in enumerate(chunks):
    s = chunk_sec.get(c["id"])
    if s is not None and s not in first_idx: first_idx[s] = i
sec_order = sorted(by_sec.keys(), key=lambda s: first_idx.get(s, 10**6))

def tbl(rows, head):
    out = ["| " + " | ".join(head) + " |", "|" + "|".join(["---"] * len(head)) + "|"]
    out += ["| " + " | ".join(str(x).replace("|", "／") for x in r) + " |" for r in rows]
    return "\n".join(out)

def val(n):
    return f'{n["value"]}{(" " + n["unit"]) if n.get("unit") else ""}'

L = []
A = L.append
A("# 推演写作输入包 · 上海财经大学中山北一路校区大数据研究中心可行性研究报告（修订）")
A("")
A(f"> 编号 {meta['doc_id']} ｜ 建设单位 {meta['owner']} ｜ 编制单位 {meta['author']} ｜ 编制时点 {meta['data_cutoff']} ｜ 资产版本 V1.0")
A("")
A("## 0. 这份文件怎么用（装配说明）")
A("")
A("本文件是事实输入单，与知识资产语料包配合使用。三者分工：")
A("")
A("| 通道 | 取自 | 作用 |")
A("| --- | --- | --- |")
A("| 形 | 语料包 chunks/skeletons.jsonl | 段落结构、句式、章节骨架；数值已替换为占位符 |")
A("| 值 | 本文件 §2 节点值表 | 把占位符替换为事实值的唯一合法来源 |")
A("| 律 | graph/rules.yaml、reasoning/derivation.yaml、联合依赖/crosswalk.yaml、evidence/evidence.yaml、quality 目录 | 计算规则、规范依赖、证据链、冲突与缺口 |")
A("")
A("写作铁律（违反即返工）")
A("")
A("1. 借形不借值：只借结构、不借值；数值一律走 §2 节点值表，不得凭记忆写字面量。")
A("2. 缺值守卫：§6 缺口项不得填 0、不得估值、不得跳过；写「待……后测算」并挂缺口。")
A("3. 不许反算：每个数值必须由 §3 规则的输入正向推出，不得由结论倒推中间量。")
A("4. 引用即绑定：正文数值写成〔节点ID〕引用；规则句直接采用 §3 的叙述句，保证表述一致。")
A("5. 冲突一律待审：§5 冲突表必须在对应章节显式呈现，不得裁决、不得只取其一。")
A("6. 不得编造：本文件未给出的量一律保持未知，不得套用同类项目、不得写「暂按经验值」。")
A("7. 规范依赖：§4 中状态为待核的条款，不得据此写「符合规范」。")
A("")
A("还原目标（二选一）")
A("")
A("- A. 按原报告结构还原：章节结构见 §7.1（原稿 " + str(len(outline["sections"])) + " 节），最适合还原写一份报告。")
A("- B. 按法定大纲重组：见 §7.2（发改投资规〔2023〕304号 通用大纲 10 章），需补第 6/8/9 章。")
A("")

KEY = {"项目名称", "报告编号", "报告版本", "建设单位", "编制单位", "编制日期", "项目负责人", "项目审核人",
       "建设地点", "建设内容", "新建总建筑面积", "地上建筑面积", "地下建筑面积", "拆除面积",
       "项目总投资", "建安工程费用", "工程建设其他费用", "预备费", "原建筑拆除费用", "建设资金来源",
       "申请国拨资金", "学校自筹资金", "计划开工时间", "计划竣工时间", "建设工期", "社会稳定风险等级"}
base = sorted([n for n in nodes if n["subject"] in KEY], key=lambda n: n["subject"])
A("## 1. 项目基础信息")
A("")
A(tbl([[n["subject"], val(n), n["id"]] for n in base], ["项目要素", "取值", "节点ID"]))
A("")

A("## 2. 事实节点值表（写作取值的唯一来源）")
A("")
A(f"共 {len(nodes)} 条事实节点，按原报告章节归位。口径列有值时表示该节点带特定统计口径，引用时不得省略。")
A("")
for s in sec_order:
    A(f"### {s}")
    A("")
    A(tbl([[n["id"], n["subject"], val(n), n.get("time", "") or "—", n.get("caliber", "") or "—"] for n in by_sec[s]],
          ["节点ID", "事实", "值", "时点", "口径"]))
    A("")

A("## 3. 技术函数（计算规则）与规范依赖")
A("")
A("每条规则给出表达式、依赖节点、输出节点，以及可直接写入正文的叙述句。")
A("")
A(tbl([[d["id"], d.get("label", ""), d.get("expr", ""),
        "、".join(d.get("deps", [])[:6]) + ("…" if len(d.get("deps", [])) > 6 else ""),
        d.get("target", "") or "—"] for d in rules],
      ["规则", "名称", "表达式", "依赖节点（节选）", "输出节点"]))
A("")
A("### 3.1 各规则的正文叙述句（直接引用，保证口径一致）")
A("")
for d in rules:
    if narr.get(d["id"]):
        A(f'- {d["id"]} {d.get("label","")}：{narr[d["id"]]}')
A("")

A("## 4. 外部规范依据（外部检索文件）")
A("")
A("### 4.1 法定编制大纲")
A("")
A(f'- 法定依据：{legal["legal_basis"]}')
A(f'- 本稿情况：{legal["report_basis"]}')
A("")
A(tbl([[c["outline"], "；".join(c["report_sections"]) or "—", c["status"]] for c in legal["chapters"]],
      ["通用大纲章节", "本稿对应章节", "覆盖状态"]))
A("")
v = [l for l in cw["links"] if l["norm_status"] == "已核"]
p = [l for l in cw["links"] if l["norm_status"] == "待核"]
A("### 4.2 已核规范条款（可取到原文，可据此判定）")
A("")
A(tbl([[l["norm_clause"], l["norm_value"], l["report_subject"] + "（" + str(l["report_value"]) + "）"] for l in v],
      ["规范条款", "条款规定", "报告对应取值"]))
A("")
A("### 4.3 待核规范条款（条款存在、限值原文未取到，不得据此判定符合规范）")
A("")
A(tbl([[l["norm_clause"], l["report_subject"] + "（" + str(l["report_value"]) + "）", "、".join(l["rules"]) or "—"] for l in p],
      ["规范条款", "报告取值", "所属规则"]))
A("")
A("### 4.4 规范符合性发现（基于已核条款）")
A("")
NORM_CLAIMS = {"CL-32", "CL-33", "CL-34", "CL-35", "CL-36", "CL-37", "CL-38", "CL-39", "CL-40", "CL-41", "CL-42", "CL-43"}
for c in claims:
    if c["id"] in NORM_CLAIMS:
        A(f'- [{c["id"]}] {c["text"]}')
A("")

A("## 5. 待审冲突（写作时必须显式呈现，不得裁决）")
A("")
A(tbl([[i + 1, c["type"], c["subject"], " ／ ".join(c["values"]), "、".join(c.get("involved", []))] for i, c in enumerate(conf)],
      ["#", "类型", "主体", "并存口径", "涉及节点"]))
A("")
A("建议写法模板（不得改写为单一结论）：")
A("")
A("- 数值型：本项目〈主体〉存在〈值A〉与〈值B〉两种口径，本报告不作裁决，待〈澄清事项〉后确定，暂按〈值A〉列示并标注待审。")
A("- 规范型：本项目〈取值〉与〈规范条款〉规定不一致，属待审事项，需以〈核算依据〉复核后确定。")
A("")
for i, c in enumerate(conf):
    A(f'{i + 1}. {c["subject"]}（{c["type"]}，{c["status"]}）：{c.get("note", "")}')
A("")

A("## 6. 缺口与未知（不得填 0、不得估值）")
A("")
A(tbl([[i + 1, g["type"], g["section"], g["desc"]] for i, g in enumerate(gaps)], ["#", "类型", "位置", "缺口"]))
A("")
A("建议写法：本项目〈项〉尚待〈依据或手续〉明确，本次不作测算，待其闭合后补充。")
A("")

A("## 7. 章节骨架与装配映射")
A("")
A("### 7.1 原报告结构（还原目标 A）")
A("")
secs = outline["sections"]
A(tbl([[i + 1, "#" * s["level"] + " " + s["title"]] for i, s in enumerate(secs)], ["#", "章节"]))
A("")
A("### 7.2 法定大纲重组建议（还原目标 B）")
A("")
A("| 通用大纲章节 | 本稿可复用章节 | 需新增内容 |")
A("| --- | --- | --- |")
for c in legal["chapters"]:
    need = "以本稿对应章节改写即可" if c["status"] == "covered" else "需新增（本稿无对应章节，见 §6 缺口）"
    A(f'| {c["outline"]} | {"；".join(c["report_sections"]) or "—"} | {need} |')
A("")

A("## 8. 术语、风格与引用规范")
A("")
A("| 项 | 规定 |")
A("| --- | --- |")
for k in ("number_format", "citation_style", "table_caption", "person", "lang", "tone"):
    if k in style: A(f'| {k} | {style[k]} |')
A(f'| 禁用词 | {"、".join(style.get("forbidden", []))} |')
A("")
A("术语表（节选，完整见 index/term_index.json）")
A("")
tl = terms if isinstance(terms, list) else terms.get("terms", [])
A(tbl([[t.get("surface", t.get("canonical", "")), t.get("canonical", ""), t.get("freq", "")] for t in tl[:40]],
      ["术语", "规范名", "频次"]))
A("")
A("---")
A("")
A(f"（本输入包由知识资产自动装配：{len(nodes)} 条事实节点 · {len(rules)} 条技术函数 · "
  f"{len(rels)} 条关系边 · {len(cw['links'])} 条规范依赖 · {len(conf)} 项待审冲突 · {len(gaps)} 项缺口）")

text = "\n".join(L)
(OUT / "推演写作输入包.md").write_text(text, encoding="utf-8")

brief = {
    "meta": meta,
    "usage": {"shape": "chunks/skeletons.jsonl", "values": "本文件 §2", "rules": "graph/rules.yaml + reasoning/derivation.yaml"},
    "base_info": [{"node": n["id"], "subject": n["subject"], "value": n["value"], "unit": n.get("unit", "")} for n in base],
    "facts_by_section": {s: [{"node": n["id"], "subject": n["subject"], "value": n["value"], "unit": n.get("unit", ""),
                              "time": n.get("time", ""), "caliber": n.get("caliber", "")} for n in by_sec[s]] for s in sec_order},
    "rules": [{"id": d["id"], "label": d.get("label", ""), "expr": d.get("expr", ""), "deps": d.get("deps", []),
               "target": d.get("target"), "narrative_zh": narr.get(d["id"], "")} for d in rules],
    "norm_links": cw["links"], "conflicts": conf, "gaps": gaps,
    "legal_outline": legal, "outline": outline["sections"],
}
(OUT / "fact-brief.yaml").write_text(json.dumps(brief, ensure_ascii=False, indent=2), encoding="utf-8")
# 刷新 inventory.yaml 的扩展产物到位状态（本脚本晚于 run.py 执行）
invp = PKG / "inventory.yaml"
if invp.exists():
    iv = json.loads(invp.read_text(encoding="utf-8"))
    for e in iv.get("extensions", []):
        e["exists"] = (PKG / e["name"]).exists()
    iv["extensions_present"] = sum(1 for e in iv.get("extensions", []) if e["exists"])
    invp.write_text(json.dumps(iv, ensure_ascii=False, indent=2), encoding="utf-8")
    print("inventory extensions:", iv["extensions_present"], "/", len(iv.get("extensions", [])))
print("brief chars:", len(text), "| sections:", len(sec_order), "| facts:", len(nodes))
