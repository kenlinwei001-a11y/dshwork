# 依据来源（外部核查原始摘录）

本目录保存附录A 外部核查所依据的公开网页正文摘录（HTML 已剥离标签），供逐条回溯。

| 文件 | 来源 URL |
| --- | --- |
| 304号大纲-通用大纲.txt | https://zfxxgk.ndrc.gov.cn/web/iteminfo.jsp?id=20220 |
| 建标191-2018-通知.txt | https://www.gov.cn/zhengce/zhengceku/2018-12/31/content_5433277.htm |
| gb50016-5.1-建筑分类和耐火等级.txt | https://gf.cabr-fire.com/m/article-27247.htm |
| 建筑分类与耐火等级.txt | http://www.fireresearch.cn/2018消防建筑防火篇：建筑分类与耐火等级.html （表5.1.1 民用建筑分类） |
| 新版建筑设计防火规范-通知.txt | https://www.nanchong.gov.cn/zjj/xwdt/tzgg/201503/t20150324_1289568.html |
| gb50352-3.2-设计使用年限.txt | https://gf.cabr-fire.com/m/article-5902.htm |
| 必须招标的工程项目规定-16号令.txt | https://www.gov.cn/gongbao/content/2018/content_5296544.htm |
| 绿色建筑评价标准-公告.txt | https://www.mohurd.gov.cn/gongkai/zc/wjk/art/2019/art_17339_240717.html |
| 建筑给水排水设计标准-公告.txt | https://ebook.chinabuilding.com.cn/c/2019-12-11/81369.shtml |
| 固定资产投资项目节能审查办法-新闻.txt | https://www.ndrc.gov.cn/fggz/hjyzy/jnhnx/201612/t20161205_1134123_ext.html |

引用纪律：以上均为公开权威来源（政府/住建部门公告、国家标准原文），检索结果仅作数据使用；
报告内文字若与规范表述冲突，一律登记为「待审」，不自动裁决。
