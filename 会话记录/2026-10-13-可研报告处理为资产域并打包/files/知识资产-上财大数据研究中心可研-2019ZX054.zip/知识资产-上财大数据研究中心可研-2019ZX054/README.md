# 知识资产：上海财经大学中山北一路校区大数据研究中心可行性研究报告（修订）

编号 2019ZX054 ｜ 建设单位 上海财经大学 ｜ 编制单位 上海同济工程咨询有限公司 ｜ 编制时点 2019-08 ｜ 资产版本 V1.0

本资产把一份历史可研报告，与**它所依赖的外部规范条款**联合编译为同一套知识图谱语料包：
报告里的每一条技术函数（计算规则）与关键取值，都通过 `depends_on` 边挂接到它赖以成立的规范条款节点上；
依赖台账与写作输入单都是本资产的正式产物，随包交付。

## 一、包内结构

| 路径 | 内容 | 访问形式 |
| --- | --- | --- |
| `manifest.yaml` / `meta.yaml` / `outline.yaml` | 契约与元信息、章节骨架 | 注入 |
| `graph/nodes.yaml` | 442 条事实节点（**事实单源**） | 工具调用 |
| `graph/rules.yaml` | 31 条技术函数（计算规则） | 工具调用 |
| `graph/relations.yaml` | 514 条十类关系，含 **26 条跨文件 depends_on** | 工具调用 |
| `graph/claims.yaml` / `evidence/evidence.yaml` | 43 条论断、458 条证据（带来源 URL） | 工具调用 |
| `dependencies.yaml` | **跨文件依赖台账**：报告技术函数 ↔ 规范条款，含核验状态 | 工具调用 / 注入 |
| `dependencies.md` | 上者的人读视图（规范依赖矩阵） | 注入 |
| `legal_mapping.yaml` | 报告章节 ↔ 发改投资规〔2023〕304号通用大纲 10 章 | 注入 |
| `chunks/skeletons.jsonl` | 1208 条脱敏骨架（**形**，数值已占位） | 工具调用 |
| `写作输入/推演写作输入包.md` | **写作输入单**：形＋值＋律的装配说明与全部事实值 | 注入 |
| `写作输入/fact-brief.yaml` | 上者的机器可读版本 | 工具调用 |
| `写作输入/章节提示词/` | **逐节提示词**：144 个结构性章节，每节一段可投喂提示词 + 本节事实表 | 注入 |
| `写作输入/章节提示词索引.md` | 逐节索引：层级、篇幅、事实数、函数数、冲突数、缺口数 | 注入 |
| `写作输入/section-prompts.yaml` | 逐节提示词的机器可读版本 | 工具调用 |
| `写作输入/节点索引表.md` | **节点字典**：442 条按节点ID与事实名两种排序速查，含所在章文件与引用数 | 注入 |
| `写作输入/node-index.tsv` | 节点字典 TSV（可直接 grep 占位符 ID） | 工具调用 |
| `外部核验/` | **Semantica 外部核验**：跨引擎冲突互证、去重候选与人工复核、W3C PROV-O 溯源、抽取探测 | 注入 / 工具调用 |
| `quality/conflicts.yaml` / `gaps.yaml` / `gate_report.yaml` | 13 项待审冲突、7 项缺口、闸门结论 | 内嵌 |
| `source/` `chunks/chunks.jsonl` | 原文与含值 chunk | **不对外** |
| `inventory.yaml` | 30 文件契约 + 扩展产物到位盘点 | ✕ |

## 二、联合处理怎么做的

1. **同一份源文本**：报告全文 + 附录A（外部核查结论层）+ 附录B（引用规范条款层）→ 一次七道工序 → 一张图。
2. **规范条款是一等节点**：附录B 按「标准号-条款号 参数名」建节点，与附录A 同概念事实自动折叠（事实单源）。
3. **依赖边显式化**：25 条 `depends_on` 边从报告节点（规则输出或关键参数）指向规范条款节点。
4. **核验状态进图谱**：条款值分「已核」（取到规范原文）与「待核」（条款存在但未取到限值原文）。
   待核条款的依赖边照样建立，但正文不得据此写成「符合规范」。当前 25 条：**已核 10 / 待核 15**。

## 三、怎么用（三种访问通道）

1. **注入**：`meta.yaml`、`outline.yaml`、`dependencies.md`、`legal_mapping.yaml`、
   `quality/gate_report.yaml`、`style/style_profile.yaml`、`index/term_index.json`、`写作输入/推演写作输入包.md`。
2. **工具调用**：`graph/nodes.yaml`、`graph/rules.yaml`、`graph/relations.yaml`、`graph/claims.yaml`、
   `evidence/evidence.yaml`、`dependencies.yaml`、`index/node_index.json`、`reasoning/*`；
   已注册的 kp-processing MCP 提供 `graph_get_node / graph_query / graph_explain / graph_impact / graph_why /
   evidence_get / corpus_get_chunk / corpus_get_skeleton / corpus_where_used / gate_check` 十个读接口。
3. **内嵌**：`quality/conflicts.yaml`、`quality/gaps.yaml`。

**安全边界**：写作 Agent 只拿 `chunks/skeletons.jsonl`；`chunks/chunks.jsonl` 与 `source/normalized.md` 不对外。
本包占位符外残留数值 = 0。

## 四、规模

| 指标 | 数值 |
| --- | --- |
| 章节（骨架）/ 语义 chunk | 268 / 1208（表格 31 块独立成块，span 可回读） |
| 事实节点（单源）/ 技术函数 / 论断 | 442 / 31 / 43 |
| 关系边（十类，含 25 条跨文件 depends_on） | 514 |
| 证据（含 16 条外部规范核查，带 URL） | 458 |
| 跨文件依赖台账 | 25 条（已核 10 / 待核 15） |
| 脱敏骨架 | 1208（占位符外残留数值 0；未绑定语义节点的数值以 X- 前缀区分，2052 个） |
| 结论 | `gate = REVIEW`：13 项冲突全部「待审」，7 项缺口显式未知 |

## 五、必须知道的三件事

1. **冲突不裁决**：13 项全部 `status: 待审`——5 项报告内部口径矛盾、6 项外部规范符合性疑点、2 项口径与人数分歧。
2. **缺口保持未知**：容积率与绿地率、总计算负荷同时系数、拆除手续闭环等不估值；15 条「待核」规范条款不得据此写「符合规范」。
3. **附录A / 附录B 非原报告内容**：系本次处理依据公开来源补充，已在 `meta.yaml` 的 `scope_note` 声明，来源链接随证据落盘。

## 六、契约到位情况

- **基础契约 28/30**：缺 `source/original.docx`、`source/assets/*`（资料库仅提供文本视图，无 docx 二进制）。
  `chunks/embeddings.parquet` 已生成（1208 chunk × 384 维，paraphrase-multilingual-MiniLM-L12-v2），`corpus_search` 可用。
- **扩展产物 19/19**：`legal_mapping.yaml`、`dependencies.yaml`、`dependencies.md`、
  `写作输入/推演写作输入包.md`、`写作输入/fact-brief.yaml`、`写作输入/章节提示词/`（19 个文件 / 144 节）、
  `写作输入/章节提示词索引.md`、`写作输入/section-prompts.yaml`、
  `写作输入/节点索引表.md`、`写作输入/node-index.tsv`、`写作输入/写作会话启动包.md`、
  `外部核验/SEMANTICA-INTEGRATION.md`、`外部核验/实体归一-人工判断清单.md`、`外部核验/*.tsv`、`外部核验/*.yaml`、`外部核验/provenance/prov.db`、
  `inventory.yaml`、`README.md`。
- 完整盘点见 `inventory.yaml`；扩展产物同时在 `manifest.yaml` 的 `extensions` 段登记。
