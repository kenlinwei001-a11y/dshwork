# ev-N-6c22c3de1e15

来源 chunk: c-fb86005df9a3

```
- 建筑结构的安全等级：二级。
```
