# ev-N-4ed8fa51b2f4

来源 chunk: c-08568da1fd3e

```
因此，项目年总耗电量为72万千瓦时。
```
