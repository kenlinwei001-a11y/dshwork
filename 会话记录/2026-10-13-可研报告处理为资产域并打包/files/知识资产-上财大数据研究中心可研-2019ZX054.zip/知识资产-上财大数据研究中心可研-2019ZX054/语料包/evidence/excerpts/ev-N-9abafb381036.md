# ev-N-9abafb381036

来源 chunk: c-fb86005df9a3

```
- 建筑结构的安全等级：二级。
```
